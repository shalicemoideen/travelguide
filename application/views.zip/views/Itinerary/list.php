<style>
    .modal-lg {
    max-width: 80%;
}
</style>
<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
				<button type="button" id="btn" class="btn btn-rounded btn-primary btn-md"><i class="fas fa-filter"></i> Filter</button><br><br>
				<!-- <div class="row page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Table</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Datatable</a></li>
					</ol>
                </div> -->
                <!-- row --><input type="hidden" id="counter_edit2" value="">
                <form id="exampleValidation" method="POST" action="" enctype="multipart/form-data">
                                    <div class="card-header" id="Create" style="display:none">
                                        <div class="d-flex align-items-center">
                                            <div class="row row-demo-grid hdr-filter-dd-fullwd">
                                                <div class="col-sm-6 col-md-5">
                                                    <div class="card">
                                                        <div class="input-group">
                                                            <select data-validation="required"  data-pms-required="true" class="form-control input-lg lst-flt-select2" id="itineraries_id" name="itineraries_id" required>  
                            
                                                                    <option value="">Please Select itinerary</option>
                                                                    <?php

                                                                    foreach($itineraries as $row)
                                                                    {
                                                                        
                                                                        echo '<option value="'.$row->itineraries_id.'" '.$sel.'>'.$row->itineraries_name.'</option>';

                                                                    }

                                                                    ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-5">
                                                    <div class="card">
                                                        <div class="input-group">
                                                            <select data-validation="required"  data-pms-required="true" class="form-control input-lg lst-flt-select2" id="itinerary_category_id" name="itinerary_category_id" required>  
                            
                                                                    <option value="">Please Select itinerary</option>
                                                                    <?php

                                                                    foreach($itineraries as $row)
                                                                    {
                                                                        
                                                                        echo '<option value="'.$row->itinerary_category_id.'" '.$sel.'>'.$row->itinerary_category_name.'</option>';

                                                                    }

                                                                    ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-5">
                                                    <div class="card">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" name="itineraries_duration_nights" id="itineraries_duration_nights" placeholder="Enter duration in nights" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-5">
                                                    <div class="card">
                                                        <div class="input-group">
                                                            <select data-validation="required"  data-pms-required="true" class="form-control input-lg lst-flt-select2" id="itineraries_days_destination_id_fk" name="itineraries_days_destination_id_fk" required>  
                            
                                                                    <option value="">Please Select destination</option>
                                                                    <?php

                                                                    foreach($itineraries as $row)
                                                                    {
                                                                        
                                                                        echo '<option value="'.$row->itinerary_category_id.'" '.$sel.'>'.$row->itinerary_category_name.'</option>';

                                                                    }

                                                                    ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>   
                                                <div class="col-sm-6 col-md-5 staff-do-not-show">
                                                    <div class="card">
                                                        <div class="input-group">
                                                            <select name="itineraries_createdby_user_id" id="itineraries_createdby_user_id" class="form-control input-lg lst-flt-select2" required>                                     
                                                                <option value="">Please Select Created by</option>                            
                                                                <?php foreach($staff as $row) {
                                                                        // $sel = ($records->state==$row->state_id)?'selected':'';
                                                                        echo '<option value="'.$row->user_id.'">'.$row->admin_name.'</option>';
                                                                    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2 col-md-3">
                                                    <div class="card">
                                                        <button type="button" class="btn btn-warning btn-md" id="search">
                                                            <span class="btn-label">
                                                                <i class="fas fa-search"></i>
                                                            </span>
                                                            Search
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2 col-md-3">
                                                    <div class="card">
                                                        <a href="<?php echo base_url();?>Itinerary">
                                                        <button type="button" class="btn btn-secondary btn-md" id="search">
                                                            <span class="btn-label">
                                                                <i class="icon-refresh"></i>
                                                            </span>
                                                            Refresh
                                                        </button>
                                                        </a>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        
                                        </div>
                                    </div>
                                    </form>

                <div class="row">
                    
                    
					<div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Itinerary Details</h4>
                                <a onclick="add_Itinerary()"  data-bs-target="#ItineraryModal" class="btn btn-rounded btn-secondary btn-md">+ New Itinerary</a> 
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="Itinerary_table" class="display" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>Sl.no</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>Duration nights</th>
                                                <th>Description</th>
                                                <th>Created by</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!-- Modal -->
        <!-- Modal -->
<div class="modal fade" id="ItineraryModal" tabindex="-1"  aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false"> 
<!-- <div class="modal fade" id="ItineraryModal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false"> -->
  <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="ItineraryModalTitle">Itinerary</h5>
        <button type="button" class="btn-close" onclick="Itinerarymodalclose()" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form class="needs-validation sl-cust-validation" action="#" id="form" novalidate>
          <input type="hidden" value="" name="id" id="id">
          <input type="hidden" name="removed_cancellation_policies_id" id="removed_cancellation_policies_id" value="">

          <!-- Top Fields -->
          <div class="row g-3">
            <div class="col-md-3">
              <label class="form-label"><b>Name</b> <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="itineraries_name" id="itineraries_name" placeholder="Enter itinerary name" required>
              <span class="help-block" style="color:red"></span>
            </div>

            <div class="col-md-3" id="returnRequest">
              <label class="form-label"><b>Duration in nights</b> <span class="text-danger">*</span></label>
              <input type="number" min="1" class="form-control" name="itineraries_duration_nights" id="itineraries_duration_nights1" placeholder="Enter Duration in nights" required>
              <span class="help-block" style="color:red"></span>
            </div>

            <div class="col-md-3">
              <label class="form-label"><b>Category</b> <span class="text-danger">*</span></label>
              <select name="itineraries_category_id_fk" id="itineraries_category_id_fk" class="form-control input-lg lst-flt-select2" required>
                <option value="">Please Select Category</option>
                <?php foreach($itinerary_category as $row) { ?>
                  <option value="<?= $row->itinerary_category_id; ?>"><?= $row->itinerary_category_name; ?></option>
                <?php } ?>
              </select>
              <span class="help-block" style="color:red"></span>
            </div>

            <div class="col-md-3">
              <label class="form-label"><b>Description</b> <span class="text-danger">*</span></label>
              <textarea class="form-control" name="itineraries_description" id="itineraries_description" rows="3" placeholder="Enter Description" required></textarea>
              <span class="help-block" style="color:red"></span>
            </div>
          </div>

          <!-- Day Blocks Container -->
          <div class="mt-3">
            <div class="card">
              <div class="card-header py-2">
                <h6 class="m-0">Days Plan</h6>
              </div>

              <div class="card-body">
                <!-- IMPORTANT: wrapper must be inside modal body card -->
                <div id="productRowWrapper" class="row gy-2"></div>
              </div>
            </div>
          </div>

          <!-- Template for Day Row -->
          <!-- <template id="dayRowTemplate">
            <div class="col-12 day-row" data-day="">
              <div class="card border mb-0">
                <div class="card-body p-3">

                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="m-0 day-label">Day X</h6>
                    <span class="badge bg-secondary travel-badge" style="display:none;">Travel Back</span>
                  </div>

                                   
                  <input type="hidden" name="itineraries_days_day[]" class="itineraries_days_day" value="">
                  <input type="hidden" name="itineraries_days_travel_back[]" class="itineraries_days_travel_back" value="">


                  <div class="row g-2">
                    <div class="col-md-4">
                      <label class="form-label"><b>Destination</b></label>
                      <select name="itineraries_days_destination_id_fk[]"
                            class="form-control destination_select select2-destination"
                            required>
                        <option value="">Please Select Destination</option>
                    </select>

                    </div>

                    <div class="col-md-4">
                      <label class="form-label"><b>Title</b></label>
                      <input type="text" name="itineraries_days_title[]" class="form-control itineraries_days_title" placeholder="Enter title" required>
                    </div>

                    <div class="col-md-4">
                      <label class="form-label"><b>Description</b></label>
                      <textarea name="itineraries_days_description[]" class="form-control itineraries_days_description" rows="2" placeholder="Enter description" required></textarea>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </template> -->
          
          <template id="dayRowTemplate">
  <div class="col-12 day-row">
    <div class="card mb-2">
      <div class="card-body p-3">

        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="day-label fw-bold">Day 1</div>
          <span class="badge bg-secondary travel-badge" style="display:none;">Travel Back</span>
        </div>

        <input type="hidden" name="itineraries_days_id[]" class="itineraries_days_id" value="">
        <input type="hidden" name="itineraries_days_day[]" class="itineraries_days_day" value="">
        <input type="hidden" name="itineraries_days_travel_back[]" class="itineraries_days_travel_back" value="">
        <input type="hidden" name="removed_itineraries_days_ids" id="removed_itineraries_days_ids" value="">

        <div class="row g-2">
          <div class="col-md-4">
            <label class="form-label mb-1"><b>Destination</b></label>
            <select name="itineraries_days_destination_id_fk[]"
                    class="form-control destination_select select2-destination"
                    required>
              <option value="">Please Select Destination</option>
            </select>
          </div>

          <div class="col-md-4">
            <label class="form-label mb-1"><b>Title</b></label>
            <input type="text" name="itineraries_days_title[]" class="form-control" required>
          </div>

          <div class="col-md-4">
            <label class="form-label mb-1"><b>Description</b></label>
            <textarea name="itineraries_days_description[]" class="form-control" rows="2" required></textarea>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-danger light" onclick="Itinerarymodalclose()" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="btnSave" onclick="save()">Save</button>
      </div>

    </div>
  </div>
</div>



<!-- Modal -->
<div class="modal fade" id="deleterowModal" role="dialog" data-backdrop="static"  data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title1"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                
                <form class="needs-validation" action="#" id="form1" >
                    <input type="hidden" value="" name="id" id="id1"/> 
                    <input type="hidden" value="" name="itineraries_name" id="itineraries_name1"/>
                    
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" onclick="Itinerarymodalclose()" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btnSave1" onclick="delete_itineraries__action()" >Delete</button>
            </div>
        </div>
    </div>
</div>