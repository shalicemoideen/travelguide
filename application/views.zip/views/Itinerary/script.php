<script>
// https://www.snagoff.com/blog/blog-post/add-remove-multiple-input-fields-dynamically-with-jquery-and-php/
////***Filter button hide and show*****///

$(document).ready(function () {
    $("#btn").click(function () {
        $("#Create").toggle();
    });
});


////***Filter button hide and show*****///


////***searching button*****///

$('#search').click(function () {
        
        $table.ajax.reload();
    });

// $( "#b2b_partner_person_name1" ).keypress(function() {
//             $table.ajax.reload();
// });

////***searching button*****///

////***Latest Jquery form validation for adding form*****///
   
    ////***Listing table*****///

var save_method; //for save method string
var table;
  $(document).ready(function() {
    
    
    $table = $('#Itinerary_table').DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        dom: 'lBfrtip',
            buttons: [
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5]
                    }
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5]
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: [0 ,1, 2, 3, 4, 5]
                    }
                },
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Itinerary/get/",
            "type": "POST",
            "data" : function (d) {
                        d.itineraries_id = $("#itineraries_id").val();
                        d.itinerary_category_id = $("#itinerary_category_id").val();
                        d.itineraries_duration_nights = $("#itineraries_duration_nights").val();
                        d.itineraries_days_destination_id_fk = $("#itineraries_days_destination_id_fk").val();
                        d.itineraries_createdby_user_id = $("#itineraries_createdby_user_id").val();

           }            
        },
        // "ajax": {
            // "url": "<?php echo site_url('States/get')?>",
            // "type": "POST"
        // },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table.column(0).nodes().each(function(node,index,dt){
            $table.cell(node).data(index+1);
            });
            
            

            // $('td', row).eq(5).html('<div class="form-button-action"><a  data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task" href="javascript:void(0)" onclick="edit_role('+data['roles_id']+')"><i class="fa fa-edit"></i></a><button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove" href="javascript:void(0)" onclick="return delete_role('+data['roles_id']+')"><i class="fa fa-times"></i></button></div>');

            $('td', row).eq(6).html('<div class="d-flex"><a href="javascript:void(0)" onclick="edit_itinerary('+data['itineraries_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_itinerary('+data['itineraries_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a></div>');
            
           
            
           },

           "drawCallback": function( settings ) {
                // displaySelectByUserType();
            },

        "columns": [
            { "data": "itineraries_status", "orderable": false },
            { "data": "itineraries_name", "orderable": false },
            { "data": "itinerary_category_name", "orderable": false },
            { "data": "itineraries_duration_nights", "orderable": false },
            { "data": "itineraries_description", "orderable": false },
            { "data": "itineraries_created_by_user_name", "orderable": false },
            { "data": "itineraries_id", "orderable": false },
            
            
            
        ]
        
    });
    
    
    ////***Latest Jquery form validation for adding form*****///
            
    $("#form").validate({

        validClass: "success",
        rules: {
            'input, select, textarea': {
                required: function(element) {
                    return $(element).is(':visible');
                }
            }
                // booking_work_order_end_date: { greaterThan: "#booking_work_order_date" }
            
        },
        messages: {
            
        },
        
        highlight: function(element) {
            $(element).closest('.form-group').removeClass('input-success-o').addClass('input-warning-o');
        },
        success: function(element) {
            $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
        },

        errorClass: 'input-error', // Optional, customize error class
        errorElement: 'div'

    });

  });
    
 
////***Listing table*****///

////***For close the modal *****///
  $('#ItineraryModal').on('hidden.bs.modal', function() {
  var waitForClose = window.setInterval(function() {
    if ($('body').hasClass('modal-open') == false) {
      $('.user').find('#name').trigger('focus');
      window.clearInterval(waitForClose)
    }
  }, 100);
  $(".product-item").remove();
});
function Itinerarymodalclose()
{

    $('#ItineraryModal').modal('hide');
   
    //$( "div" ).remove( ".modal-backdrop" );
    $('#itinerary_category_name').val('');
    $(".product-item").remove();
    $(".product-item1").remove();
    $('#category_name_alert').hide();
    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.itinerary_category_name').removeClass('input-success-o');
    $('.itinerary_category_name').removeClass('input-warning-o');
    $(".product-item").remove();
    $(".product-item1").remove();

    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#ItineraryModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    $('#itinerary_category_name').focus();
initSelect2Destination(this);
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.itinerary_category_name').removeClass('input-success-o');
    $('.itinerary_category_name').removeClass('input-warning-o');

})
////***For open the modal *****///
    
////***For open modal of Itinerary adding form  *****///
    
function add_Itinerary()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#ItineraryModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Itinerary Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
    $(".product-item").remove();
    $(".product-item1").remove();
    counter = 0;
}

////***For open modal of Itinerary adding form  *****///

////***For editing Itinerary details from adding modal form  *****///

// function renderDayRowsFromDB(days)
// {
//   let $wrap = $('#productRowWrapper');
//   let tpl = document.getElementById('dayRowTemplate');

//   $wrap.empty();

//   if (!Array.isArray(days)) days = [];

//   for (let i = 0; i < days.length; i++) {
//     let d = days[i];

//     let node = tpl.content.cloneNode(true);
//     $wrap.append(node);

//     let $row = $wrap.find('.day-row').last();

//     // day label saved like "Day 1" in DB
//     let dayText = d.itineraries_days_day ? d.itineraries_days_day : ('Day ' + (i+1));
//     $row.find('.day-label').text(dayText);

//     // store hidden fields
//     // if you want numeric in hidden, extract number
//     let dayNo = dayText.replace('Day','').trim();
//     $row.find('.itineraries_days_day').val(dayNo);

//     let tb = d.itineraries_days_travel_back ? d.itineraries_days_travel_back : '';
//     $row.find('.itineraries_days_travel_back').val(tb);

//     if (tb === 'TB') $row.find('.travel-badge').show();
//     else $row.find('.travel-badge').hide();

//     // destination options
//     let $sel = $row.find('select[name="itineraries_days_destination_id_fk[]"]');
//     $sel.html(DEST_OPTIONS_HTML);

//     // title/desc
//     $row.find('input[name="itineraries_days_title[]"]').val(d.itineraries_days_title);
//     $row.find('textarea[name="itineraries_days_description[]"]').val(d.itineraries_days_description);

//     // init select2 inside modal
//     if (!$sel.hasClass("select2-hidden-accessible")) {
//       initSelect2Destination($row);
//     }

//     // set selected destination (after select2 init)
//     $sel.val(d.itineraries_days_destination_id_fk).trigger('change');
//   }
// }
function renderDayRowsFromDB(days)
{
  var $wrap = $('#productRowWrapper');
  var tpl = document.getElementById('dayRowTemplate');

  $wrap.empty();

  if (!Array.isArray(days)) days = [];

  for (var i = 0; i < days.length; i++) {
    var d = days[i];

    // append new row
    var node = tpl.content.cloneNode(true);
    $wrap.append(node);

    var $row = $wrap.find('.day-row').last();

    // ✅ Day text from DB (ex: "Day 1")
    var dayText = d.itineraries_days_day ? d.itineraries_days_day : ('Day ' + (i + 1));
    $row.find('.day-label').text(dayText);

    // hidden numeric day (extract number)
    var dayNo = String(dayText).replace('Day', '').trim();
    $row.find('.itineraries_days_day').val(dayNo);

    // travel back
    var tb = d.itineraries_days_travel_back ? d.itineraries_days_travel_back : '';
    $row.find('.itineraries_days_travel_back').val(tb);
    if (tb === 'TB') $row.find('.travel-badge').show();

    // destination options + select2
    var $sel = $row.find('select[name="itineraries_days_destination_id_fk[]"]');
    $sel.html(DEST_OPTIONS_HTML);

    // init select2 inside modal
    if (!$sel.hasClass("select2-hidden-accessible")) {
      $sel.select2({
        width: '100%',
        placeholder: "Search Destination",
        allowClear: true,
        dropdownParent: $('#ItineraryModal')
      });
    }

    // set values
    $sel.val(d.itineraries_days_destination_id_fk).trigger('change');
    $row.find('input[name="itineraries_days_title[]"]').val(d.itineraries_days_title);
    $row.find('textarea[name="itineraries_days_description[]"]').val(d.itineraries_days_description);
    $row.find('.itineraries_days_id').val(d.itineraries_days_id);

  }
}

// function addRemovedDayIdsFromRemovedRows($rows) {
//   var removed = $('#removed_itineraries_days_ids').val();
//   var arr = removed ? removed.split(',') : [];

//   $rows.each(function(){
//     var id = $(this).find('.itineraries_days_id').val();
//     if (id && arr.indexOf(String(id)) === -1) arr.push(String(id));
//   });

//   $('#removed_itineraries_days_ids').val(arr.join(','));
// }

function addRemovedDayIdsFromRemovedRows($rows) {

    var removed = $('#removed_itineraries_days_ids').val();
    var arr = removed ? removed.split(',') : [];

    $rows.each(function(){
        var id = $(this).find('.itineraries_days_id').val();

        if (id && arr.indexOf(String(id)) === -1) {
            arr.push(String(id));
        }
    });

    $('#removed_itineraries_days_ids').val(arr.join(','));
}




function edit_itinerary(id)
{
  save_method = 'update';
  $('#form')[0].reset();
  $('.input-warning-o').removeClass('input-warning-o');
  $('.help-block').text('');

  // clear old dynamic rows
  $('#productRowWrapper').empty();

  $.ajax({
    url : "<?= base_url('index.php/Itinerary/ajax_edit/'); ?>" + id,
    type: "GET",
    dataType: "JSON",
    success: function(master)
    {
      // ✅ set primary id
      $('#id').val(master.itineraries_id);

      $('[name="itineraries_name"]').val(master.itineraries_name);
      $('[name="itineraries_category_id_fk"]').val(master.itineraries_category_id_fk).trigger('change');
      $('[name="itineraries_duration_nights"]').val(master.itineraries_duration_nights);
      $('[name="itineraries_description"]').val(master.itineraries_description);

      // open modal
      $('#ItineraryModal').modal('show');
      $('.modal-title').text('Edit Itinerary Details');
      $('#btnSave').text('update');

      // fetch days by itinerary id (NOT category id)
      $.ajax({
        url: "<?= base_url('index.php/Itinerary/fetch_itineraries_days'); ?>",
        type: "POST",
        dataType: "JSON",
        data: { itineraries_id: master.itineraries_id },
        success: function(days)
        {
          // build rows based on DB
          renderDayRowsFromDB(days);
        }
      });
    },
    error: function () {
      alert('Error get data from ajax');
    }
  });
}


////***For editing Itinerary details from adding modal form  *****///

////***For reload the datatable  *****///

function reload_table()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        // swal("Itinerary details updated successfully", "", "success")
        var ff = 0;
        
        ff = "Itinerary details updated successfully";

         $("#vehicle_update").val(ff);
        
         
         var options = {

        'title': '',

        'style': 'success',

        'message': ff,

        // 'success': 'warning',
        'icon': 'fas fa-check',

        };
        
        var n1 = new notify(options); 

        n1.show(); 

        setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        // swal("Itinerary details added successfully", "", "success")

        var ff = 0;
        
        ff = "Itinerary details added successfully";

         $("#vehicle_add").val(ff);
        
         
         var options = {

        'title': '',

        'style': 'success',

        'message': ff,

        // 'success': 'warning',
        'icon': 'fas fa-check',

        };
        
        var n1 = new notify(options); 

        n1.show(); 

        setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

////***For reload the datatable  *****///

///***For save the Itinerary details from adding modal form *****///

function clearValidationUI() {
  $('.input-warning-o').removeClass('input-warning-o');
  $('.help-block').text('');
}

function showFieldError($field, message) {
  // your UI style
  $field.closest('.form-group, .col-md-3, .col-md-4, .col-12').addClass('input-warning-o');

  // if you have help-block span under field
  let $hb = $field.parent().find('.help-block');
  if ($hb.length) $hb.text(message);
  else {
    // create if not exists
    if (!$field.next('.help-block').length) $field.after('<span class="help-block" style="color:red"></span>');
    $field.next('.help-block').text(message);
  }
}

function validateBeforeSave() {
  clearValidationUI();

  let ok = true;

  // main fields
  const requiredMain = [
    { sel: '#itineraries_name', msg: 'Itinerary name is required' },
    { sel: '#itineraries_duration_nights1', msg: 'Duration in nights is required' },
    { sel: '#itineraries_category_id_fk', msg: 'Category is required' },
    { sel: '#itineraries_description', msg: 'Description is required' }
  ];

  requiredMain.forEach(r => {
    let $f = $(r.sel);
    if ($.trim($f.val()) === '') {
      showFieldError($f, r.msg);
      ok = false;
    }
  });

  // dynamic day rows
  $('#productRowWrapper .day-row').each(function () {
    let $row = $(this);

    // Select2: use .val() directly, works
    let $dest = $row.find('select[name="itineraries_days_destination_id_fk[]"]');
    let $title = $row.find('input[name="itineraries_days_title[]"]');
    let $desc  = $row.find('textarea[name="itineraries_days_description[]"]');

    if (!$dest.val()) { showFieldError($dest, 'Destination is required'); ok = false; }
    if ($.trim($title.val()) === '') { showFieldError($title, 'Title is required'); ok = false; }
    if ($.trim($desc.val()) === '') { showFieldError($desc, 'Description is required'); ok = false; }
  });

  // If using Select2, errors should highlight the select2 container too
  if (!ok) {
    // focus first invalid field
    let $first = $('.input-warning-o').find('input,select,textarea').first();
    if ($first.length) $first.focus();
  }

  return ok;
}

function save()
{
     
    if (!validateBeforeSave()) {
        return; // stop AJAX
    }
    var url;

    if(save_method == 'add') {
        $("#id").val('');
        $('#btnSave').text('saving...'); //change button text
        $('#btnSave').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Itinerary/ajax_add/";
    } 
    else {

        $('#btnSave').text('updating...'); //change button text
        $('#btnSave').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Itinerary/ajax_update/";
    }
    
    var fd = new FormData();
    
    var form = document.getElementById('form');
    var data = new FormData(form);
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: data, //$('#form').serialize(),
        dataType: "JSON",
        //cache : false,
        processData: false,
        enctype: 'multipart/form-data',
        contentType: false,
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {

                $('#ItineraryModal').modal('hide');
                // $('body').removeClass('modal-open');
                // $('.modal-backdrop').remove();
                $(".product-item").remove();
    $(".product-item1").remove();

                reload_table();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('input-warning-o'); //select parent twice to select div form-group class and add has-error class
                    if($('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').length) {
                        $('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').text(data.error_string[i]); //select span help-block class set text error string
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                    }
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            $('.help-block').val('hide');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

///***For save the Itinerary details from adding modal form *****///

////***For reload the datatable for delete *****///

function reload_table_delete()
{
    $table.ajax.reload(null,false); //reload datatable ajax
    
    // swal("Itinerary details deleted successfully", "", "success")
        var ff = 0;
        
        ff = "Itinerary details deleted successfully";

         $("#roles_delete").val(ff);
        
         
         var options = {

        'title': '',

        'style': 'success',

        'message': ff,

        // 'success': 'warning',
        'icon': 'fas fa-check',

        };
        var n1 = new notify(options); 

        n1.show(); 

        setTimeout(function(){ n1.hide(); }, 10000);
        
}

////***For reload the datatable for delete *****///
    
////***For reload the Itinerary datatable for delete *****///

function delete_cancellation_policies(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Cancellation_policies/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.terms_condition_id);
            $('[name="cancellation_policies_name"]').val(data.cancellation_policies_name);
            $('#deleterowModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title1').text('Do you want to delete this record?'); // Set title to Bootstrap modal title
            $('#btnSave1').text('delete');
            $('#btnSave1').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}

function delete_cancellation_policies_action()
{
    $('#btnSave1').text('deleting...'); //change button text
    $('#btnSave1').attr('disabled',true); //set button disable 
    var url;

        url = "<?php echo base_url();?>index.php/Cancellation_policies/delete/";
        
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form1').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $("#id").val('');
                $('#deleterowModal').modal('hide');
                reload_table_delete();
                // ('body').removeClass('modal-open');
                //$('.modal-backdrop').remove();
                
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    if($('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').length) {
                        $('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').text(data.error_string[i]); //select span help-block class set text error string
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                    }
                }
            }

            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 

        }
    });
}

////***For delete the Itinerary details from  database *****///

////***Dynamic text box details saving into database*****////

// $(document).ready(function() {



//     var counter_edit = $("#counter_edit").val();



//     if(counter_edit >0){



//       counter = counter_edit-1;



//     }



//   });

var counter = 1;

var n1 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit = $("#counter_edit1").val();



if(counter_edit >0){
    counter = counter_edit-1;
}
    //alert(counter);




function addMore() {
 var n1 = $("#counter_edit").val();
                 // alert(n1);
// var user_id_fk = $('#user_id_fk').val();
// var currentLoggedInUserType = $('#currentLoggedInUserType').val();

// if(user_id_fk == '' && currentLoggedInUserType == 'A'){

// var ff = 0;
        
//         var ff = 0;
  
//   ff = "Company is required first";

//   $("#validation_dynamic").val(ff);
  
 
//      var options = {

//     'title': '',

//     'style': 'error',

//     'message': ff,

//     // 'success': 'warning',
//     'icon': 'warning',

//     };

//    var n1 = new notify(options); 

//    n1.show(); 

//    setTimeout(function(){ n1.hide(); }, 10000);
//    $('.user_id_fk').addClass('has-error');
//    $('#campaign_agency_commission').focus();
//    $('.user_id_fk').addClass('has-error');
//    return false; 
// }
// else{

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

     var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="cancellation_policies_id_fk['+counter+']" id="cancellation_policies_id_fk_'+counter+'"/><textarea class="form-control" name="cancellation_policies_item_name['+counter+']" id="cancellation_policies_item_name_'+counter+'"  rows="5" placeholder="Enter Cancellation and policies" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
    $("#product1").append(htmlVal);   
        
    
  });   
counter++;  

}
////***Dynamic text box details saving into database*****////

////***Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow(counter) {

    var item_id = $('#cancellation_policies_item_id_'+counter).val();
    removed_item_ids.push(item_id);
    $('#removed_cancellation_policies_id').val(removed_item_ids);

    console.log(counter,"counter");
    $("#product-item_"+counter).remove();
    $("#product-item1_"+counter).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}

////***Delete dynamic table rows*****///

//  if ($('#returnRequest').length) {
//     var counter1 = 1;
//         function emptyRow() {
//             this.obj = $('<div class="return-row control-group row"></div>');
//             this.obj.append(
//               '<div class="mb-3 col-md-3"> <input type="hidden" name="itineraries_days_day['+counter1+']" id="itineraries_days_day_'+counter1+'" value="Day&nbsp;' +counter1+'"/>Day&nbsp;' +counter1+'</div>' +
//               '<div class="mb-3 col-md-8"><input type="hidden" name="itineraries_id_fk['+counter1+']" id="itineraries_id_fk_'+counter1+'"/><select name="itineraries_days_destination_id_fk['+counter1+']" id="itineraries_days_destination_id_fk_'+counter1+'" class="form-control input-lg lst-flt-select2 destination" required></select></div>');

//             $.ajax({
            
//                 type: "POST",
//                 url: "<?php echo base_url()?>index.php/Itinerary/Destination_details",
//                 success: function(cities)
//                 { 
//                     counter2 = counter1-1;
//                     //alert(counter2);
//                     $('.destination').append('<option value="">Please Select Destination</option>');

//                     $.each(cities,function(id,city) {

//                       var opt = $('<option />');
//                       opt.val(id);
//                       opt.text(city);

//                     $('.destination').append(opt);
//                     $('.destination').select2();

//                     });
//                 }
//             })

//             counter1++;
//         }

//         function refresh(count) {
//             if (count > 0) {
//                 $("#noa_header").show();
//             } else {
//                 $("#noa_header").hide();
//             }
            
//             var wrapper = $('#productRowWrapper');
            
//             while (wrapper.children().length > count)
//                 wrapper.children().last().remove();
                
//             while (wrapper.children().length < count)
//                 wrapper.append((new emptyRow()).obj);
//         }

//         $('#itineraries_duration_nights1').change(function () {
//             refresh(parseInt($(this).val()));
//         });

         
//     }

function initSelect2Destination(scope = document) {

    $(scope).find('.select2-destination').select2({
        width: '100%',
        placeholder: "Search Destination",
        allowClear: true,
        dropdownParent: $('#ItineraryModal') // REQUIRED for modal
    });

}

let DEST_OPTIONS_HTML = '<option value="">Please Select Destination</option>';

function loadDestinationsOnce() {
  return $.ajax({
    url: "<?= base_url('index.php/Itinerary/Destination_details'); ?>",
    type: "GET",
    dataType: "json"
  }).then(function(list){
    let html = '<option value="">Please Select Destination</option>';
    if (Array.isArray(list)) {
      list.forEach(function(item){
        html += `<option value="${item.id}">${item.name}</option>`;
      });
    }
    DEST_OPTIONS_HTML = html;
  });
}

function totalDaysFromNights(nights){
  nights = parseInt(nights, 10);
  if (isNaN(nights) || nights < 0) nights = 0;

  // Rule: total days = nights + 1 (travel back day is the last one)
  return nights + 1;
}

// function renderDayRows(nights){
//   let totalDays = totalDaysFromNights(nights);
//   let $wrap = $('#productRowWrapper');
//   let $tpl = document.getElementById('dayRowTemplate');

//   // current rows
//   let current = $wrap.find('.day-row').length;

//   // remove extra rows if decreasing
//   if (current > totalDays) {
//     // $wrap.find('.day-row:gt(' + (totalDays - 1) + ')').remove();
//     let $toRemove = $wrap.find('.day-row:gt(' + (totalDays - 1) + ')');

//         addRemovedDayIdsFromRemovedRows($toRemove);   // ⭐ ADD THIS
//         $toRemove.remove();                           // ⭐ KEEP THIS
//     current = $wrap.find('.day-row').length;
//   }

//   // add missing rows if increasing
//   for (let i = current + 1; i <= totalDays; i++) {
//     let node = $tpl.content.cloneNode(true);
//     $wrap.append(node);
//   }

//   // update labels + hidden fields + travel back marker
//   $wrap.find('.day-row').each(function(index){
//     let dayNo = index + 1;
//     let isTravelBack = (dayNo === totalDays);

//     $(this).attr('data-day', dayNo);
//     $(this).find('.day-label').text('Day ' + dayNo);

//     // $(this).find('.itinerary_day').val(dayNo);
//     $(this).find('.itineraries_days_travel_back').val(isTravelBack ? 'TB' : '');
// $(this).find('.itineraries_days_day').val(dayNo);


//     if (isTravelBack) {
//       $(this).find('.travel-badge').show();
//       $(this).find('.itineraries_days_travel_back').val('TB'); // store TB for last day
//     } else {
//       $(this).find('.travel-badge').hide();
//       $(this).find('.itineraries_days_travel_back').val('');
//     }

//     // ensure destination options exist
//     let $sel = $(this).find('.destination_select');

//     if ($sel.children().length <= 1) {
//         $sel.html(DEST_OPTIONS_HTML);
//     }

//     // Initialize Select2 ONLY if not already initialized
//     if (!$sel.hasClass("select2-hidden-accessible")) {
//         initSelect2Destination(this);
//     }

//   });

//   // show/hide header section if you want
//   $('#noa_header').show();
// }

function renderDayRows(nights) {

  let totalDays = totalDaysFromNights(nights);
  let $wrap = $('#productRowWrapper');
  let tpl = document.getElementById('dayRowTemplate');

  let current = $wrap.find('.day-row').length;

  // remove extra rows if decreasing
  if (current > totalDays) {

    let $toRemove = $wrap.find('.day-row:gt(' + (totalDays - 1) + ')');

    addRemovedDayIdsFromRemovedRows($toRemove); // collect ids for soft-disable
    $toRemove.remove();

    current = $wrap.find('.day-row').length;
  }

  // add missing rows if increasing
  for (let i = current + 1; i <= totalDays; i++) {
    let node = tpl.content.cloneNode(true);
    $wrap.append(node);
  }

  // update labels + hidden fields + travel back marker
  $wrap.find('.day-row').each(function(index){

    let dayNo = index + 1;
    let isTravelBack = (dayNo === totalDays);

    $(this).attr('data-day', dayNo);
    $(this).find('.day-label').text('Day ' + dayNo);

    // ✅ hidden values for save
    $(this).find('.itineraries_days_day').val(dayNo);
    $(this).find('.itineraries_days_travel_back').val(isTravelBack ? 'TB' : '');

    // badge
    if (isTravelBack) $(this).find('.travel-badge').show();
    else $(this).find('.travel-badge').hide();

    // destination select
    let $sel = $(this).find('.destination_select');

    // preserve current selection (important for edit)
    let currentVal = $sel.val();

    if ($sel.children().length <= 1) {
      $sel.html(DEST_OPTIONS_HTML);
      if (currentVal) $sel.val(currentVal);
    }

    // init select2 only once
    if (!$sel.hasClass("select2-hidden-accessible")) {
      $sel.select2({
        width: '100%',
        placeholder: "Search Destination",
        allowClear: true,
        dropdownParent: $('#ItineraryModal')
      });
    }

  });

  $('#noa_header').show();
}

$(document).ready(function(){
  loadDestinationsOnce().then(function(){
    // initial render if value already exists
    renderDayRows($('#itineraries_duration_nights1').val());
  });

  // on input change
  $('#itineraries_duration_nights1').on('input change', function(){
    let v = parseInt($(this).val(), 10);
    if (isNaN(v) || v < 0) {
      v = 0;
      $(this).val(0);
    }
    renderDayRows(v);
  });
});


// $(document).on("click",'.category',function(){


//     var accounts_id = $(this).val();

//     var counterId = $(this).attr("id");

//     var counter = counterId.split("_").pop(-1);

//     console.log(counter,"counter");

//     alert(counter);
//     $.ajax({
            
//                 type: "POST",
//                 url: "<?php echo base_url()?>index.php/Itinerary/Destination_details",
//                 success: function(cities)
//                 {
//                     $('itineraries_category_id_fk_'+counter+'').append('<option value="">Please Select Destination</option>');

//                     $.each(cities,function(id,city) {

//                       var opt = $('<option />');
//                       opt.val(id);
//                       opt.text(city);

//                       $('itineraries_category_id_fk_'+counter+'').append(opt);
//                        $('itineraries_category_id_fk_'+counter+'').select2();

//                     });
//                 }
//             })


// });  
</script>