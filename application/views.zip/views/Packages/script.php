
<script type="text/javascript">

////***Filter button hide and show*****///

$(document).ready(function () {
    $("#btn").click(function () {
        $("#Create").toggle();
    });
});

$(document).ready(function () {
    $("#btn1").click(function () {
        $("#Create1").toggle();
    });
});

$(document).ready(function () {
    $("#btn2").click(function () {
        $("#Create2").toggle();
    });
});


////***Filter button hide and show*****///

////***searching button*****///

$('#search').click(function () {
        
        $table.ajax.reload();
    });

$('#search1').click(function () {
        
        $table1.ajax.reload();
    });

$('#search2').click(function () {
        
        $table2.ajax.reload();
    });

$( "#packages_duration_in_nights_filter" ).keypress(function() {
            $table.ajax.reload();
});

////***searching button*****///

////***Listing table*****///

var save_method; //for save method string
var table;
  $(document).ready(function() {
    
    
    $table = $('#Package_registration').DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        dom: 'lBfrtip',
            buttons: [
                
                                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5]
                                    }
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5]
                                    }
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0 ,1, 2, 3, 4, 5]
                                    }
                                },
                               
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Packages/get/",
            "type": "POST",
            "data" : function (d) {
                        d.packages_title_filter = $("#packages_title_filter").val();
                        d.packages_category_id_filter = $("#packages_category_id_filter").val();
                        d.packages_itinerary_category_id_filter = $("#packages_itinerary_category_id_filter").val();
                        d.packages_itinerary_id_filter = $("#packages_itinerary_id_filter").val();
                        d.packages_duration_in_nights_filter = $("#packages_duration_in_nights_filter").val();
                        d.packages_createdby_user_id = $("#packages_createdby_user_id").val();
           }            
        },
        // "ajax": {
            // "url": "<?php echo site_url('States/get')?>",
            // "type": "POST"
        // },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table.column(0).nodes().each(function(node,index,dt){
            $table.cell(node).data(index+1);
            });
            
            
            $('td', row).eq(7).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_package('+data['packages_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="edit_package('+data['packages_id']+', \'duplicate\')">Duplicate</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Packages/preview_direct/'+data['packages_id']+'" >Preview</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_package('+data['packages_id']+')">Delete</a></div></div>');

            
            
           },

           "drawCallback": function( settings ) {
                // displaySelectByUserType();
            },

        "columns": [
            { "data": "packages_status", "orderable": false },
            { "data": "packages_title", "orderable": false },
            { "data": "package_category_name", "orderable": false },
            { "data": "packages_duration_in_nights", "orderable": false },
            { "data": "itinerary_category_name", "orderable": false },
            { "data": "itineraries_name", "orderable": false },
            { "data": "packages_createdby_user_name", "orderable": false },                      
            { "data": "packages_id", "orderable": false }
            
            
        ]
        
    });
    
  

  });
    
 
////***Listing table*****///

////***For open modal of room tariff adding form  *****///
    
function add_packages()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#PackagesModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Create Package Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
}

////***For open modal of room tariff adding form  *****///

////***For reset package modal  *****///

function resetPackageModal() {

  // reset form
  $('#form')[0].reset();

  // clear select2
  $('#packages_category_id_fk, #packages_itinerary_category_id_fk, #packages_itinerary_id_fk')
    .val('').trigger('change');

  // clear itinerary table + hidden inputs
  $('#itinerary').html('');

  // uncheck all feature checkboxes
  $('#packages_inclusion_exclusion_checked_type').prop('checked', false).trigger('change');
  $('#packages_optional_add_on_checked_type').prop('checked', false).trigger('change');
  $('#packages_special_requirment_checked_type').prop('checked', false).trigger('change');
  $('#packages_payment_policies_checked_type').prop('checked', false).trigger('change');
  $('#packages_terms_conditions_checked_type').prop('checked', false).trigger('change');
  $('#packages_cancellation_policy_checked_type').prop('checked', false).trigger('change');
  $('#packages_notes_checked_type').prop('checked', false).trigger('change');
  // $('#packages_property_checked_type').prop('checked', false).trigger('change');
  $('#packages_property_type').prop('checked', false).trigger('change');

  // clear dynamic blocks
  $('#inclusion').html('');
  $('#exclusion').html('');
  $('#optional-addon').find('.optional-addon-row').remove();
  $('#special-requirments').find('.special-row').remove();
  $('#payment-policies').find('.payment-row').remove();
  $('#terms-conditions').find('.terms-row').remove();
  $('#cancellation-policy').find('.cancellation-row').remove();
  $('#add_notes').find('.note-row').remove();
  $('#property').html('');
}

// when modal opens fresh for add
$('#PackagesModal').on('show.bs.modal', function () {
  if (window.save_method === 'add') resetPackageModal();
});

// optional: always reset when closing
$('#PackagesModal').on('hidden.bs.modal', function () {
  resetPackageModal();
});

////***For reset package modal  *****///

////***For open modal for edit  *****///


// function edit_package(id) {

//   window.save_method = 'update';
//   // resetPackageModal();

//   $.ajax({
//     url: "<?php echo base_url(); ?>index.php/Packages/ajax_edit/" + id,
//     type: "GET",
//     dataType: "json",
//     success: function(res) {

//       if (!res.status) {
//         alert(res.message || 'Failed to load package');
//         return;
//       }

//       const p = res.package;

//       // hidden id for update
//       $('#packages_id').val(p.packages_id);

//       // master fields
//       $('#packages_title').val(p.packages_title);
//       $('#packages_duration_in_nights').val(p.packages_duration_in_nights);

//       $('#packages_category_id_fk').val(p.packages_category_id_fk).trigger('change');
//       $('#packages_itinerary_category_id_fk').val(p.packages_itinerary_category_id_fk).trigger('change');

//       // IMPORTANT: load itinerary dropdown based on category+duration, then select value
//       // Use your existing "loadItineraries" logic by triggering input change:
//       setTimeout(function(){
//         $('#packages_itinerary_id_fk').val(p.packages_itinerary_id_fk).trigger('change');
//       }, 500);

//       // ===========================
//       // A) ITINERARY DAYS TABLE
//       // ===========================
//       // If your itinerary change AJAX rebuilds rows, you need to overwrite descriptions after the rows are created.
//       // So wait a bit after itinerary dropdown triggers change:
//       setTimeout(function(){

//         // res.itinerary_days contains saved packages_itinerary_days rows
//         // map by day index/order and inject into hidden textarea
//         if (res.itinerary_days && res.itinerary_days.length) {

//           // after your table rows are built, fill saved description for each row
//           $('#itinerary tr').each(function(i){
//             const saved = res.itinerary_days[i];
//             if (!saved) return;

//             $(this).find('.day-content-display').html(saved.packages_itineraries_days_description || '');
//             $(this).find('.hidden-day-description').val(saved.packages_itineraries_days_description || '');

//             // also set hidden inputs if you use them in backend
//             // Example if you have hidden inputs:
//             // $(this).find('input[name="itineraries_days_id_fk[]"]').val(saved.itineraries_days_id_fk);
//           });
//         }

//       }, 1200);

//       // ===========================
//       // B) INCLUSION / EXCLUSION
//       // ===========================
//       if (p.packages_inclusion_exclusion_checked_type === 'Y') {

//         $('#packages_inclusion_exclusion_checked_type').prop('checked', true).trigger('change');

//         // set dropdown title
//         $('#packages_inclusion_exclusion_common_id_fk')
//           .val(p.packages_inclusion_exclusion_common_id_fk)
//           .trigger('change');

//         // now fill textareas manually (overrides loaded)
//         setTimeout(function(){

//           $('#inclusion').html('');
//           $('#exclusion').html('');

//           (res.inclusions || []).forEach(function(row){
//             $('#inclusion').append(`
//               <div class="d-flex gap-2 mb-2 inclusion-row align-items-start">
//                 <textarea class="form-control" name="packages_inclusions_details[]" rows="3">${row.packages_inclusions_details || ''}</textarea>
//                 <button type="button" class="btn btn-sm btn-danger remove-row"><b>X</b></button>
//               </div>
//             `);
//           });

//           (res.exclusions || []).forEach(function(row){
//             $('#exclusion').append(`
//               <div class="d-flex gap-2 mb-2 exclusion-row align-items-start">
//                 <textarea class="form-control" name="packages_exclusions_details[]" rows="3">${row.packages_exclusions_details || ''}</textarea>
//                 <button type="button" class="btn btn-sm btn-danger remove-row"><b>X</b></button>
//               </div>
//             `);
//           });

//           // hide +add buttons because now it’s loaded mode
//           $('.add1, .add2').hide();

//         }, 600);
//       }

//       // ===========================
//       // C) OPTIONAL ADDONS
//       // ===========================
//       if (p.packages_optional_add_on_checked_type === 'Y') {

//         $('#packages_optional_add_on_checked_type').prop('checked', true).trigger('change');

//         // clear + load saved
//         const $box = $('#optional-addon');
//         $box.find('.optional-addon-row').remove();

//         (res.optional_addons || []).forEach(function(r){
//           $box.find('.mb-3.col-md-6').first().before(`
//             <div class="d-flex gap-2 mb-2 optional-addon-row align-items-start">
//               <textarea name="packages_optional_add_on_details[]" class="form-control" rows="3">${r.packages_optional_add_on_details || ''}</textarea>
//               <button type="button" class="btn btn-sm btn-danger remove-optional-addon"><b>X</b></button>
//             </div>
//           `);
//         });
//       }

//       // ===========================
//       // D) SPECIAL REQUIREMENTS
//       // ===========================
//       if (p.packages_special_requirment_checked_type === 'Y') {

//         $('#packages_special_requirment_checked_type').prop('checked', true).trigger('change');

//         // remove existing
//         $('#special-requirments').find('.special-row').remove();

//         // add each saved row
//         (res.special_requirements || []).forEach(function(r){
//           addMore4(); // your global add row function (creates select + amount)
//           const $last = $('#special-requirments').find('.special-row').last();
//           $last.find('.special-select').val(r.special_requirements_id_fk).trigger('change');
//           $last.find('.special-amount').val(r.packages_special_requirements_cost || '');
//         });
//       }

//       // ===========================
//       // E) PAYMENT POLICIES
//       // ===========================
//       if (p.packages_payment_policies_checked_type === 'Y') {

//         $('#packages_payment_policies_checked_type').prop('checked', true).trigger('change');

//         $('#payment_policies_id_fk').val(p.payment_policies_id_fk).trigger('change');

//         setTimeout(function(){
//           $('#payment-policies').find('.payment-row').remove();

//           (res.payment_policies || []).forEach(function(r){
//             $('#payment-policies').find('.payment_add').first().before(`
//               <div class="d-flex gap-2 mb-2 payment-row align-items-start">
//                 <textarea class="form-control" name="packages_payment_policies_details[]" rows="3">${r.packages_payment_policies_details || ''}</textarea>
//                 <button type="button" class="btn btn-sm btn-danger remove-payment"><b>X</b></button>
//               </div>
//             `);
//           });

//           $('.payment_add').hide();
//         }, 600);
//       }

//       // ===========================
//       // F) TERMS
//       // ===========================
//       if (p.packages_terms_conditions_checked_type === 'Y') {

//         $('#packages_terms_conditions_checked_type').prop('checked', true).trigger('change');

//         $('#terms_condition_id_fk').val(p.terms_condition_id_fk).trigger('change');

//         setTimeout(function(){
//           $('#terms-conditions').find('.terms-row').remove();

//           (res.terms || []).forEach(function(r){
//             $('#terms-conditions').find('.terms_add').first().before(`
//               <div class="d-flex gap-2 mb-2 terms-row align-items-start">
//                 <textarea class="form-control" name="packages_terms_condition_details[]" rows="3">${r.packages_terms_condition_details || ''}</textarea>
//                 <button type="button" class="btn btn-sm btn-danger remove-terms"><b>X</b></button>
//               </div>
//             `);
//           });

//           $('.terms_add').hide();
//         }, 600);
//       }

//       // ===========================
//       // G) CANCELLATION
//       // ===========================
//       if (p.packages_cancellation_policy_checked_type === 'Y') {

//         $('#packages_cancellation_policy_checked_type').prop('checked', true).trigger('change');

//         $('#cancellation_policies_id_fk').val(p.cancellation_policies_id_fk).trigger('change');

//         setTimeout(function(){
//           $('#cancellation-policy').find('.cancellation-row').remove();

//           (res.cancellation || []).forEach(function(r){
//             $('#cancellation-policy').find('.terms_add').first().before(`
//               <div class="d-flex gap-2 mb-2 cancellation-row align-items-start">
//                 <textarea class="form-control" name="packages_cancellation_policies_details[]" rows="3">${r.packages_cancellation_policies_details || ''}</textarea>
//                 <button type="button" class="btn btn-sm btn-danger remove-cancellation"><b>X</b></button>
//               </div>
//             `);
//           });

//           $('.terms_add').hide();
//         }, 600);
//       }

//       // ===========================
//       // H) NOTES
//       // ===========================
//       // if (p.packages_notes_checked_type === 'Y') {

//       //   $('#packages_notes_checked_type').prop('checked', true).trigger('change');

//       //   $('#add_notes').find('.note-row').remove();

//       //   (res.notes || []).forEach(function(r){
//       //     $('#add_notes').find('.mb-3.col-md-6').first().before(`
//       //       <div class="d-flex gap-2 mb-2 note-row align-items-start">
//       //         <textarea class="form-control" name="packages_notes_details[]" rows="3">${r.packages_notes_details || ''}</textarea>
//       //         <button type="button" class="btn btn-sm btn-danger remove-note"><b>X</b></button>
//       //       </div>
//       //     `);
//       //   });
//       // }

//       // ===========================
//       // H) NOTES (EDIT LOAD)
//       // ===========================
//       if (p.packages_notes_checked_type === 'Y') {

//         $('#packages_notes_checked_type')
//           .prop('checked', true)
//           .trigger('change');

//         // clear old
//         $('#add_notes').find('.note-row').remove();

//         (res.notes || []).forEach(function (r) {

//           $('#add_notes').find('.mb-3.col-md-6').first().before(`
//             <div class="d-flex gap-2 mb-2 note-row align-items-start">
//               <textarea class="form-control"
//                         name="packages_notes_details[]"
//                         rows="3">${r.packages_notes_details || ''}</textarea>
//               <button type="button" class="btn btn-sm btn-danger remove-note"><b>X</b></button>
//             </div>
//           `);

//         });
//       }

//       // ===========================
//       // I) PROPERTIES
//       // ===========================
//       if (p.packages_property_checked_type === 'Y') {

//         $('#packages_property_type').prop('checked', true).trigger('change');

//         // after your property UI creates the first block automatically,
//         // we rebuild exactly from res.properties
//         setTimeout(function(){

//           $('#property').html(''); // clear existing
//           // we also need your property JS to allow "create section" programmatically:
//           // easiest: call addMore10() for each category, then fill values
// // console.log(res.properties);
//           (res.properties || []).forEach(function(sec){

//             addMore10(); // create new section UI
//             const $section = $('#property').find('.property-section').last();
// // console.log(sec.packages_properties_common_category_name);
//             // set category name
//             // $section.find('input[name="property_category_name[]"]').val(sec.packages_properties_common_category_name);

//             $section
//   .find('input[name^="property_category_name"]')
//   .val(sec.packages_properties_common_category_name);

//             // now fill each day -> properties -> rooms
//             // NOTE: your dynamic rowKey differs; easiest is:
//             // - for each day, use the FIRST assignment row, set property, then set rooms
//             (sec.days || []).forEach(function(dayObj){

//               const dayIndex = dayObj.day_index;
//               const $dayRow = $section.find(`tr.day-row[data-day-index="${dayIndex}"]`);
//               if (!$dayRow.length) return;

//               // update destination hidden if needed
//               $dayRow.find('input[name^="property_destination_id"]').val(dayObj.destination_id);

//               // remove existing assignment rows and rebuild
//               $dayRow.find('.assignment-row').remove();

//               // rebuild each property row
//               (dayObj.properties || []).forEach(function(prop, idx){

//                 // first row: addAssignmentRow(..., true) to show +Add
//                 // additional: addAssignmentRow(..., false) to show X
//                 const destId = dayObj.destination_id;
//                 const isFirst = (idx === 0);

//                 // you must have access to addAssignmentRow function (make it global or move it)
//                 // easiest: click add-assignment then set values. We'll do manual creation by triggering +Add:
//                 addAssignmentRow($dayRow, $section.data('section'), dayIndex, destId, isFirst);

//                 const $lastAssign = $dayRow.find('.assignment-row').last();

//                 // set property (wait options load)
//                 setTimeout(function(){
//                   $lastAssign.find('.property-select').val(prop.property_id).trigger('change');

//                   // wait rooms load
//                   setTimeout(function(){
//                     $lastAssign.find('.rooms-select').val(prop.rooms).trigger('change');
//                   }, 600);

//                 }, 600);
//               });
//             });

//           });

//         }, 1200);
//         // buildPropertiesFromEdit(res.properties);
//       }

//       // finally open modal
//       $('#PackagesModal').modal('show');
//       $('#btnSave').text('Update');

//     },
//     error: function() {
//       alert('Failed to load edit data');
//     }
//   });
// }

function edit_package(id, mode) {

  // window.save_method = 'update';
  mode = mode || 'update';
  window.save_method = (mode === 'duplicate') ? 'add' : 'update';

  // IMPORTANT: reset modal ONLY for duplicate, not for update
  // (optional) if you want fresh dynamic UI
  if (mode === 'duplicate') {
    resetPackageModal();
  }

  // (Recommended) reset then keep update mode
  // resetPackageModal();  // uncomment if you want clean start before fill

  $.ajax({
    url: "<?php echo base_url(); ?>index.php/Packages/ajax_edit/" + id,
    type: "GET",
    dataType: "json",
    success: function (res) {

      if (!res.status) {
        alert(res.message || 'Failed to load package');
        return;
      }

      const p = res.package;

      // ✅ Open modal first (so select2 + DOM exist)
      $('#PackagesModal').modal('show');
       // ✅ Set ID only for UPDATE
      if (mode === 'update') {
        $('#packages_id').val(p.packages_id);
        $('#btnSave').text('Update');
        $('#PackagesModal .modal-title').text('Edit Package');
      } else {
        // ✅ DUPLICATE: clear ID so it inserts new
        $('#packages_id').val('');
        $('#btnSave').text('Save');
        $('#PackagesModal .modal-title').text('Duplicate Package');
      }

      // master fields
      $('#packages_title').val(p.packages_title);
      $('#packages_duration_in_nights').val(p.packages_duration_in_nights);

      // select2 dropdowns
      $('#packages_category_id_fk').val(p.packages_category_id_fk).trigger('change');
      $('#packages_itinerary_category_id_fk').val(p.packages_itinerary_category_id_fk).trigger('change');

      /* ==========================================================
         1) Load itineraries dropdown first (category + duration)
         then set itinerary id
         ========================================================== */

      // call your existing loader
      if (typeof loadItinerariesByCategoryDuration === 'function') {
        loadItinerariesByCategoryDuration();
      } else {
        // fallback: trigger change to load options
        $('#packages_itinerary_category_id_fk').trigger('change');
      }

      // wait a bit until itinerary options arrive
      setTimeout(function () {

        $('#packages_itinerary_id_fk')
          .val(p.packages_itinerary_id_fk)
          .trigger('change'); // this triggers itinerary table AJAX

      }, 500);

      /* ==========================================================
         2) After itinerary table built -> fill saved days description
         ========================================================== */
      setTimeout(function () {

        if (res.itinerary_days && res.itinerary_days.length) {

          $('#itinerary tr').each(function (i) {

            const saved = res.itinerary_days[i];
            if (!saved) return;

            $(this).find('.day-content-display')
              .html(saved.packages_itineraries_days_description || '');

            $(this).find('.hidden-day-description')
              .val(saved.packages_itineraries_days_description || '');
          });
        }

      }, 1400);

      /* ==========================================================
         3) INCLUSION / EXCLUSION
         ========================================================== */
      if (p.packages_inclusion_exclusion_checked_type === 'Y') {

        $('#packages_inclusion_exclusion_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#packages_inclusion_exclusion_common_id_fk')
          .val(p.packages_inclusion_exclusion_common_id_fk)
          .trigger('change');

        setTimeout(function () {

          $('#inclusion').empty();
          $('#exclusion').empty();

          (res.inclusions || []).forEach(function (row) {
            $('#inclusion').append(`
              <div class="d-flex gap-2 mb-2 inclusion-row align-items-start">
                <textarea class="form-control" name="packages_inclusions_details[]" rows="3">${row.packages_inclusions_details || ''}</textarea>
                <button type="button" class="btn btn-sm btn-danger remove-row"><b>X</b></button>
              </div>
            `);
          });

          (res.exclusions || []).forEach(function (row) {
            $('#exclusion').append(`
              <div class="d-flex gap-2 mb-2 exclusion-row align-items-start">
                <textarea class="form-control" name="packages_exclusions_details[]" rows="3">${row.packages_exclusions_details || ''}</textarea>
                <button type="button" class="btn btn-sm btn-danger remove-row"><b>X</b></button>
              </div>
            `);
          });

        }, 600);
      }

      /* ==========================================================
         4) OPTIONAL ADDONS
         ========================================================== */
      if (p.packages_optional_add_on_checked_type === 'Y') {

        $('#packages_optional_add_on_checked_type')
          .prop('checked', true)
          .trigger('change');

        const $box = $('#optional-addon');
        $box.find('.optional-addon-row').remove();

        (res.optional_addons || []).forEach(function (r) {
          $box.find('.mb-3.col-md-6').first().before(`
            <div class="d-flex gap-2 mb-2 optional-addon-row align-items-start">
              <textarea name="packages_optional_add_on_details[]" class="form-control" rows="3">${r.packages_optional_add_on_details || ''}</textarea>
              <button type="button" class="btn btn-sm btn-danger remove-optional-addon"><b>X</b></button>
            </div>
          `);
        });
      }

      /* ==========================================================
         5) SPECIAL REQUIREMENTS
         ========================================================== */
      if (p.packages_special_requirment_checked_type === 'Y') {

        $('#packages_special_requirment_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#special-requirments').find('.special-row').remove();

        (res.special_requirements || []).forEach(function (r) {
          addMore4();
          const $last = $('#special-requirments').find('.special-row').last();
          $last.find('.special-select').val(r.special_requirements_id_fk).trigger('change');
          $last.find('.special-amount').val(r.packages_special_requirements_cost || '');
        });
      }

      /* ==========================================================
         6) PAYMENT POLICIES
         ========================================================== */
      if (p.packages_payment_policies_checked_type === 'Y') {

        $('#packages_payment_policies_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#payment_policies_id_fk').val(p.payment_policies_id_fk).trigger('change');

        setTimeout(function () {

          $('#payment-policies').find('.payment-row').remove();

          (res.payment_policies || []).forEach(function (r) {
            $('#payment-policies').find('.payment_add').first().before(`
              <div class="d-flex gap-2 mb-2 payment-row align-items-start">
                <textarea class="form-control" name="packages_payment_policies_details[]" rows="3">${r.packages_payment_policies_details || ''}</textarea>
                <button type="button" class="btn btn-sm btn-danger remove-payment"><b>X</b></button>
              </div>
            `);
          });

        }, 600);
      }

      /* ==========================================================
         7) TERMS
         ========================================================== */
      if (p.packages_terms_conditions_checked_type === 'Y') {

        $('#packages_terms_conditions_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#terms_condition_id_fk').val(p.terms_condition_id_fk).trigger('change');

        setTimeout(function () {

          $('#terms-conditions').find('.terms-row').remove();

          (res.terms || []).forEach(function (r) {
            $('#terms-conditions').find('.terms_add').first().before(`
              <div class="d-flex gap-2 mb-2 terms-row align-items-start">
                <textarea class="form-control" name="packages_terms_condition_details[]" rows="3">${r.packages_terms_condition_details || ''}</textarea>
                <button type="button" class="btn btn-sm btn-danger remove-terms"><b>X</b></button>
              </div>
            `);
          });

        }, 600);
      }

      /* ==========================================================
         8) CANCELLATION
         ========================================================== */
      if (p.packages_cancellation_policy_checked_type === 'Y') {

        $('#packages_cancellation_policy_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#cancellation_policies_id_fk').val(p.cancellation_policies_id_fk).trigger('change');

        setTimeout(function () {

          $('#cancellation-policy').find('.cancellation-row').remove();

          (res.cancellation || []).forEach(function (r) {
            $('#cancellation-policy').find('.terms_add').first().before(`
              <div class="d-flex gap-2 mb-2 cancellation-row align-items-start">
                <textarea class="form-control" name="packages_cancellation_policies_details[]" rows="3">${r.packages_cancellation_policies_details || ''}</textarea>
                <button type="button" class="btn btn-sm btn-danger remove-cancellation"><b>X</b></button>
              </div>
            `);
          });

        }, 600);
      }

      /* ==========================================================
         9) NOTES
         ========================================================== */
      if (p.packages_notes_checked_type === 'Y') {

        $('#packages_notes_checked_type')
          .prop('checked', true)
          .trigger('change');

        $('#add_notes').find('.note-row').remove();

        (res.notes || []).forEach(function (r) {

          $('#add_notes').find('.mb-3.col-md-6').first().before(`
            <div class="d-flex gap-2 mb-2 note-row align-items-start">
              <textarea class="form-control" name="packages_notes_details[]" rows="3">${r.packages_notes_details || ''}</textarea>
              <button type="button" class="btn btn-sm btn-danger remove-note"><b>X</b></button>
            </div>
          `);

        });
      }

      /* ==========================================================
         10) PROPERTIES (FIXED)
         - wait for itinerary table
         - trigger checkbox AFTER table built
         - create sections
         - set category name correctly (name^ selector)
         - wait for property options and room options before selecting
         ========================================================== */

      if (p.packages_property_checked_type === 'Y') {

        $('#packages_property_type').prop('checked', true);

        // ✅ trigger change AFTER itinerary rows exist
        // setTimeout(function () {
        //   $('#packages_property_type').trigger('change');
        // }, 1600);

        $('#packages_property_type').prop('checked', true).trigger('change');


        // build data after checkbox creates base UI
        setTimeout(function () {

          $('#property').empty(); // clear existing created blocks
          window.sectionCount = 0; // (optional) depends on your code

          (res.properties || []).forEach(function (sec) {

            // create new section UI
            addMore10();

            const $section = $('#property').find('.property-section').last();

            // ✅ FIX CATEGORY NAME SELECTOR
            $section
              .find('input[name^="property_category_name"]')
              .val(sec.packages_properties_common_category_name || '');

            // fill each day
            (sec.days || []).forEach(function (dayObj) {

              const dayIndex = dayObj.day_index;
              const destId   = dayObj.destination_id;

              const $dayRow = $section.find(`tr.day-row[data-day-index="${dayIndex}"]`);
              if (!$dayRow.length) return;

              // update destination hidden if needed
              $dayRow.find('input[name^="property_destination_id"]').val(destId);
              $dayRow.find('.assignments').attr('data-dest-id', destId);

              // remove default assignment rows
              $dayRow.find('.assignment-row').remove();

              // rebuild properties rows
              (dayObj.properties || []).forEach(function (prop, idx) {

                const isFirst = (idx === 0);

                // ✅ create assignment row
                addAssignmentRow($dayRow, $section.data('section'), dayIndex, destId, isFirst);

                const $lastAssign = $dayRow.find('.assignment-row').last();
                const $propSel = $lastAssign.find('.property-select');
                const $roomSel = $lastAssign.find('.rooms-select');

                // ✅ WAIT for properties options then set value
                // const waitProperty = setInterval(function () {

                //   if ($propSel.find('option').length > 1) {
                //     clearInterval(waitProperty);

                //     $propSel.val(prop.property_id).trigger('change');

                //     // ✅ WAIT for rooms options then set selected rooms
                //     const waitRooms = setInterval(function () {

                //       if (
                //         !$roomSel.prop('disabled') &&
                //         $roomSel.find('option').length > 0
                //       ) {
                //         clearInterval(waitRooms);

                //         $roomSel.val(prop.rooms || []).trigger('change');
                //       }

                //     }, 200);
                //   }

                // }, 200);

                // ✅ load+select
              setPropertyAndRoomsFromSaved(
                destId,
                $propSel,
                $roomSel,
                prop.property_id,
                prop.rooms // must be array of room ids
              );

              });
            });

          });

        }, 2200); // enough delay for itinerary + checkbox UI build
      }

    },
    error: function () {
      alert('Failed to load edit data');
    }
  });
}

////***For open modal for edit  *****///


///***For save the package details from adding modal form *****///

/* ==========================================================
   SIMPLE BOOTSTRAP STYLE ERROR HELPERS
   ========================================================== */
function clearValidationErrors() {
  $('.is-invalid').removeClass('is-invalid');
  $('.js-err').remove();
}

function setInvalid($el, msg) {
  $el.addClass('is-invalid');

  // put message after input/select/textarea
  const $msg = $('<div class="text-danger small js-err mt-1"></div>').text(msg);

  // if element already has a message, replace it
  if ($el.next('.js-err').length) {
    $el.next('.js-err').replaceWith($msg);
  } else {
    $el.after($msg);
  }
}

function scrollToFirstError() {
  const $first = $('.is-invalid').first();
  if ($first.length) {
    $('html, body').animate({ scrollTop: $first.offset().top - 120 }, 300);
  }
}

function isEmpty(val) {
  return val === null || val === undefined || String(val).trim() === '';
}

/* ==========================================================
   VALIDATION MAIN FUNCTION
   return true => OK submit
   return false => stop submit
   ========================================================== */
function validatePackageForm() {

  clearValidationErrors();
  let ok = true;

  /* ==========================================================
     1) MAIN REQUIRED FIELDS
     ========================================================== */
  const $pkgTitle   = $('[name="packages_title"]');
  const $duration   = $('[name="packages_duration_in_nights"]');
  const $pkgCat     = $('[name="packages_category_id_fk"]');
  const $itCat      = $('[name="packages_itinerary_category_id_fk"]');
  const $itinerary  = $('[name="packages_itinerary_id_fk"]');

  if (isEmpty($pkgTitle.val())) { ok = false; setInvalid($pkgTitle, 'Package title is required'); }
  if (isEmpty($duration.val())) { ok = false; setInvalid($duration, 'Duration (nights) is required'); }
  if (isEmpty($pkgCat.val()))   { ok = false; setInvalid($pkgCat, 'Package category is required'); }
  if (isEmpty($itCat.val()))    { ok = false; setInvalid($itCat, 'Itinerary category is required'); }
  if (isEmpty($itinerary.val())){ ok = false; setInvalid($itinerary, 'Itinerary is required'); }

  /* ==========================================================
     2-3) INCLUSIONS / EXCLUSIONS
     checkbox checked -> must have at least 1 textarea in each
     and none can be empty
     ========================================================== */
  const $incChk = $('#packages_inclusion_exclusion_checked_type');
  if ($incChk.is(':checked')) {

    const $incAreas = $('#inclusion textarea');
    const $excAreas = $('#exclusion textarea');

    // Must open at least one in each OR loaded from dropdown
    if ($incAreas.length === 0) {
      ok = false;
      setInvalid($('#packages_inclusion_exclusion_common_id_fk'), 'Add at least one Inclusion (use +Add new or select a title)');
    }
    if ($excAreas.length === 0) {
      ok = false;
      setInvalid($('#packages_inclusion_exclusion_common_id_fk'), 'Add at least one Exclusion (use +Add new or select a title)');
    }

    // Required: any textarea empty => invalid
    $incAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Inclusion cannot be empty'); }
    });
    $excAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Exclusion cannot be empty'); }
    });
  }

  /* ==========================================================
     4-5) OPTIONAL ADD ON
     checkbox checked -> must have at least 1 textarea
     and none can be empty
     ========================================================== */
  const $optChk = $('#packages_optional_add_on_checked_type');
  if ($optChk.is(':checked')) {

    // change selector below if your container id differs
    const $optAreas = $('#optional-addon textarea[name="packages_optional_add_on_details[]"], #optional-addon textarea');

    if ($optAreas.length === 0) {
      ok = false;
      setInvalid($optChk, 'Add at least one Optional add on');
    }

    $optAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Optional add on cannot be empty'); }
    });
  }

  /* ==========================================================
     6-7) SPECIAL REQUIREMENT
     checkbox checked -> must have at least 1 row
     validate select + amount (both required)
     ========================================================== */
  const $spChk = $('#packages_special_requirment_checked_type');
  if ($spChk.is(':checked')) {

    const $spRows = $('#special-requirments .special-row');
    if ($spRows.length === 0) {
      ok = false;
      setInvalid($spChk, 'Add at least one Special requirement');
    }

    // validate each row
    $spRows.each(function () {
      const $sel = $(this).find('select[name="special_requirements_id_fk[]"]');
      const $amt = $(this).find('input[name="packages_special_requirements_cost[]"]');

      if ($sel.length && isEmpty($sel.val())) { ok = false; setInvalid($sel, 'Select a special requirement'); }
      if ($amt.length && isEmpty($amt.val())) { ok = false; setInvalid($amt, 'Amount is required'); }
    });
  }

  /* ==========================================================
     8-9) PAYMENT POLICIES
     checkbox checked -> must have at least 1 textarea
     and none empty
     ========================================================== */
  const $payChk = $('#packages_payment_policies_checked_type');
  if ($payChk.is(':checked')) {

    // container: #payment-policies
    const $payAreas = $('#payment-policies textarea');

    if ($payAreas.length === 0) {
      ok = false;
      setInvalid($('#payment_policies_id_fk'), 'Add at least one Payment policy item (+Add new or select a title)');
    }

    $payAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Payment policy cannot be empty'); }
    });
  }

  /* ==========================================================
     10-11) TERMS & CONDITIONS
     checkbox checked -> must have at least 1 textarea
     and none empty
     ========================================================== */
  const $tcChk = $('#packages_terms_conditions_checked_type');
  if ($tcChk.is(':checked')) {

    const $tcAreas = $('#terms-conditions textarea');

    if ($tcAreas.length === 0) {
      ok = false;
      setInvalid($('#terms_condition_id_fk'), 'Add at least one Terms & condition item (+Add new or select a title)');
    }

    $tcAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Terms & condition cannot be empty'); }
    });
  }

  /* ==========================================================
     12-13) CANCELLATION POLICY
     checkbox checked -> must have at least 1 textarea
     and none empty
     ========================================================== */
  const $canChk = $('#packages_cancellation_policy_checked_type');
  if ($canChk.is(':checked')) {

    const $canAreas = $('#cancellation-policy textarea');

    if ($canAreas.length === 0) {
      ok = false;
      setInvalid($('#cancellation_policies_id_fk'), 'Add at least one Cancellation policy item (+Add new or select a title)');
    }

    $canAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Cancellation policy cannot be empty'); }
    });
  }

  /* ==========================================================
     14-15) NOTES
     checkbox checked -> must have at least 1 textarea
     and none empty
     ========================================================== */
  const $notesChk = $('#packages_notes_checked_type');
  if ($notesChk.is(':checked')) {

    const $noteAreas = $('#add_notes textarea');

    if ($noteAreas.length === 0) {
      ok = false;
      setInvalid($notesChk, 'Add at least one Note');
    }

    $noteAreas.each(function () {
      if (isEmpty($(this).val())) { ok = false; setInvalid($(this), 'Note cannot be empty'); }
    });
  }

  /* ==========================================================
     16) PROPERTIES (dynamic)
     checkbox checked -> validate:
       - at least one section exists
       - category name required
       - each assignment row: property required
       - each assignment row: rooms must have at least 1 selected
     ========================================================== */
  const $propChk = $('#packages_property_type');
  if ($propChk.is(':checked')) {

    const $sections = $('#property .property-section');

    if ($sections.length === 0) {
      ok = false;
      setInvalid($propChk, 'Add at least one Property section');
    }

    $sections.each(function () {

      const $sec = $(this);

      // category name (your input name: property_category_name[sectionId])
      const $cat = $sec.find('input[name^="property_category_name"]');
      if ($cat.length && isEmpty($cat.val())) { ok = false; setInvalid($cat, 'Category name is required'); }

      // assignment rows
      $sec.find('.assignment-row').each(function () {

        const $row = $(this);

        const $propSel = $row.find('select.property-select');
        const $roomsSel = $row.find('select.rooms-select');

        if ($propSel.length && isEmpty($propSel.val())) {
          ok = false;
          setInvalid($propSel, 'Select a property');
        }

        // rooms multi-select must have at least 1
        const roomsVal = $roomsSel.val(); // array or null
        if ($roomsSel.length && (!roomsVal || roomsVal.length === 0)) {
          ok = false;
          setInvalid($roomsSel, 'Select at least one room');
        }
      });
    });
  }

  if (!ok) scrollToFirstError();
  return ok;
}

// $('#PackagesModal').on('shown.bs.modal', function () {
//   resetPackageModal();
// });

function save() {

  //   // ✅ stop submit if invalid
  if (!validatePackageForm()) {
    return;
  }
  let url = "";

  if (save_method === 'add') {
    url = "<?php echo base_url();?>index.php/Packages/ajax_add/";
    $('#btnSave').text('Saving...');
  } else {
    url = "<?php echo base_url();?>index.php/Packages/ajax_update/";
    $('#btnSave').text('Updating...');
  }

  $('#btnSave').attr('disabled', true);

  var form = document.getElementById('form');
  var data = new FormData(form);

  $.ajax({
    url: url,
    type: "POST",
    data: data,
    dataType: "JSON",
    processData: false,
    contentType: false,
    success: function(res) {

      if (res.status) {

        $('#PackagesModal').modal('hide');
        resetPackageModal();
        reload_table();

      } else {
        alert(res.message || 'Validation failed');
      }

      $('#btnSave').text('Save');
      $('#btnSave').attr('disabled', false);
    },
    error: function() {
      alert('Error saving data');
      $('#btnSave').text('Save');
      $('#btnSave').attr('disabled', false);
    }
  });
}

///***For save the package details from adding modal form *****///

////***For reload the datatable  *****///

function reload_table()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

          swal("Package details updated successfully", "", "success")
      
    }
    else{
      
          swal("Package details added successfully", "", "success")

    }
	
    
}

////***For reload the datatable  *****///

$(document).ready(function() {
    $('#packages_itinerary_category_id_fk').change(function() {
    //alert("oo");
        var packages_itinerary_category_id_fk = $('#packages_itinerary_category_id_fk').val();
        var packages_duration_in_nights = $('#packages_duration_in_nights').val();

    
        if(packages_itinerary_category_id_fk != '') {
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/fetch_itinerary_under_category",
            method: "POST",
            data: {
                packages_itinerary_category_id_fk: packages_itinerary_category_id_fk,packages_duration_in_nights:packages_duration_in_nights
            },
            success: function(data) {
                $('#packages_itinerary_id_fk').html(data);
                // $('#city').html('<option value="">Select City</option>');
            }
        });
        } else {
            $('#packages_itinerary_id_fk').html('<option value="0">Please Select Lead</option>');
            // $('#city').html('<option value="">Select City</option>');
        }

    });
});

$(document).ready(function () {

  const $duration  = $('#packages_duration_in_nights');
  const $cat       = $('#packages_itinerary_category_id_fk');
  const $itinerary = $('#packages_itinerary_id_fk');

  // If using select2 for itinerary dropdown
  if ($itinerary.length) {
    $itinerary.select2({ width: '100%' });
  }

  /* ==========================================
     Load itineraries based on Category + Nights
     ========================================== */
  function loadItinerariesByCategoryDuration() {

    const nights = $.trim($duration.val());
    const catId  = $.trim($cat.val());

    // Clear current itineraries
    $itinerary.html('<option value="">Please Select itinerary</option>');

    // Must have BOTH values
    if (!catId || !nights) {
      // Refresh select2 UI
      if ($itinerary.hasClass('select2-hidden-accessible')) {
        $itinerary.trigger('change.select2');
      }
      return;
    }

    // Show loading
    $itinerary.html('<option value="">Loading...</option>');
    if ($itinerary.hasClass('select2-hidden-accessible')) {
      $itinerary.trigger('change.select2');
    }

    $.ajax({
      url: '<?php echo base_url(); ?>index.php/Packages/ajax_fetch_itinerary_under_category',
      type: 'POST',
      data: {
        itineraries_category_id: catId,
        itineraries_duration_nights: nights
      },
      success: function (html) {

        // Replace options from backend (HTML <option> list)
        $itinerary.html(html);

        // Reset selected value after reload
        $itinerary.val('');

        // Refresh select2 UI
        if ($itinerary.hasClass('select2-hidden-accessible')) {
          $itinerary.trigger('change.select2');
        } else {
          $itinerary.trigger('change');
        }
      },
      error: function () {
        $itinerary.html('<option value="">Please Select itinerary</option>');
        if ($itinerary.hasClass('select2-hidden-accessible')) {
          $itinerary.trigger('change.select2');
        }
        alert('Failed to load itineraries');
      }
    });
  }

  /* ==========================================
     Trigger on changes
     - When category changes: load
     - When nights changes: load (only if category selected)
     ========================================== */

  // Category change
  $cat.on('change', function () {
    loadItinerariesByCategoryDuration();
  });

  // Nights change (keyup + change for manual typing)
  let t = null;
  $duration.on('keyup change', function () {

    // Debounce: wait typing stop (prevents too many ajax calls)
    clearTimeout(t);
    t = setTimeout(function () {

      // only load if category selected
      if ($cat.val()) {
        loadItinerariesByCategoryDuration();
      } else {
        // if no category, just clear itinerary dropdown
        $itinerary.html('<option value="">Please Select itinerary</option>');
        if ($itinerary.hasClass('select2-hidden-accessible')) {
          $itinerary.trigger('change.select2');
        }
      }

    }, 300);
  });

});

////***Ajax dropdown for add*****///

////***For reset modal again *****///

function resetPackageModal() {

  const $modal = $('#PackagesModal');
  const $form  = $('#form');

  /* ===============================
     1️⃣ Reset FORM FIELDS
     =============================== */
  $form[0].reset();

  /* ===============================
     2️⃣ Reset SELECT2 (VERY IMPORTANT)
     =============================== */
  $modal.find('select').each(function () {
    if ($(this).hasClass('select2-hidden-accessible')) {
      $(this).val(null).trigger('change');
    }
  });

  /* ===============================
     3️⃣ Uncheck ALL checkboxes
     =============================== */
  $modal.find('input[type="checkbox"]').prop('checked', false);

  /* ===============================
     4️⃣ Clear dynamic containers
     =============================== */

  // Itinerary table
  $('#itinerary').empty();

  // Inclusion / exclusion
  $('#inclusion, #exclusion').empty();
  $('#inclusionExclusionWrapper').hide();
  $('#myDiv2, #myDiv3').hide();

  // Optional add on
  $('#optional-addon').find('.optional-addon-row').remove();
  $('#optional-addon').closest('.col-xl-10').hide();

  // Special requirements
  $('#special-requirments').find('.special-row').remove();
  $('#special-requirments').closest('.col-xl-10').hide();

  // Payment policies
  $('#payment-policies').find('.payment-row').remove();
  $('#myDiv4, #myDiv5').hide();

  // Terms & conditions
  $('#terms-conditions').find('.terms-row').remove();
  $('#myDiv6, #myDiv7').hide();

  // Cancellation policy
  $('#cancellation-policy').find('.cancellation-row').remove();
  $('#myDiv8, #myDiv9').hide();

  // Notes
  $('#add_notes').find('.note-row').remove();
  // $('#add_notes').closest('.col-xl-10').hide();

  // Properties
  $('#property').empty().hide();
  $('[onClick="addMore10();"]').closest('.terms_add, .mb-3').hide();

  /* ===============================
     5️⃣ Remove validation states
     =============================== */
  $modal.find('.is-invalid, .has-error').removeClass('is-invalid has-error');
  $modal.find('.help-block').text('');

}

////***For reset modal again *****///


////***For select2 change destination *****///

$(document).on('change', '.change_destination', function () {

  const $row = $(this).closest('tr');

  const newDestId   = $(this).val();
  const newDestName = $(this).find('option:selected').text();

  if (!newDestId) return;

  // ✅ update ACTIVE destination for this day
  $row.find('.active-destination-id').val(newDestId);
  $row.find('.active-destination-name').val(newDestName);

});

////***For select2 change destination *****///

////***For set destination id and name if selected another destination from dropdown under change destination *****///

$(document).on('change', '.change_destination', function () {

  const $row = $(this).closest('tr');

  const newDestId   = $(this).val();
  const newDestName = $(this).find('option:selected').text();

  if (!newDestId) return;

  /* ===============================
     1️⃣ UPDATE ACTIVE DESTINATION (UI + PROPERTY BLOCK)
     =============================== */
  $row.find('.active-destination-id').val(newDestId);
  $row.find('.active-destination-name').val(newDestName);

  /* ===============================
     2️⃣ 🔥 UPDATE POST FIELD (BACKEND)
     THIS WAS MISSING
     =============================== */
  $row.find('.pkg-day-destination-id').val(newDestId);

});

////***For set destination id and name if selected another destination from dropdown under change destination *****///

////***For loading itiniraries in dropdown under duration nights and load days based on itineray and display details in tooltip *****///

$(document).ready(function () {

    /* ==========================================================
       1. Package itinerary change → Load table rows
    ========================================================== */
    $('#packages_itinerary_id_fk').on('change', function () {

    let itineraryId = $(this).val();
    let tbody = $('#itinerary');
    tbody.empty();

    if (!itineraryId) return;

    tbody.append(`
        <tr>
            <td colspan="5" class="text-center text-muted">
                Loading itinerary days...
            </td>
        </tr>
    `);

    $.ajax({
        url: "<?php echo base_url(); ?>index.php/Packages/itinerary_array_list/" + itineraryId,
        type: 'GET',
        dataType: 'json',
        success: function (res) {

            tbody.empty();

            if (!res.length) {
                tbody.append(`
                    <tr>
                        <td colspan="5" class="text-center text-danger">
                            No itinerary days found
                        </td>
                    </tr>
                `);
                return;
            }

            $.each(res, function (i, item) {

                let rowNum = i + 1;

                tbody.append(`
                    <tr>
                        <td>
                            ${item.itineraries_days_day} | ${item.itineraries_days_title}
                        </td>

                        <td>
                            ${item.state_name}
                           <input type="hidden" name="packages_itineraries_days_destination_id_fk[]"
                                    class="active-destination-id"
                                    value="${item.itineraries_days_destination_id_fk}">

                              <input type="hidden"
                                    class="active-destination-name"
                                    value="${item.state_name}">

                        </td>

                        <td>
                            <div class="day-content-display">
                                ${item.itineraries_days_description}
                            </div>

                            <!-- 🔹 Hidden textarea for backend -->
                            <textarea name="packages_itineraries_days_description[]"
                                      class="hidden-day-description"
                                      style="display:none;">${item.itineraries_days_description}</textarea>
                            <input type="hidden" name="itineraries_days_id_fk[]" value="${item.itineraries_days_id}"/>
                            <input type="hidden" name="packages_itineraries_days_day[]" value="${item.itineraries_days_day}"/>
                            <input type="hidden" name="packages_itineraries_days_title[]" value="${item.itineraries_days_title}"/>
                        </td>

                        <td>
                            <select class="form-control change_destination">
                                <option value="">Please Select Destination</option>
                            </select>
                        </td>

                        <td class="position-relative">
                            <select class="form-control change_itinerary mb-2"
                                    data-row-num="${rowNum}">
                                <option value="">Please Select Itinerary</option>
                            </select>
                            
                            <select class="form-control change_itinerary_day" data-row-num="${rowNum}">
                                <option value="">Please Select Days</option>
                            </select>

                            <div class="day-description-tooltip" id="tooltip_${rowNum}">
                                <div class="tooltip-content"></div>
                            </div>
                        </td>

                        
                    </tr>
                `);
            });

            // 🔹 INIT SELECT2 AFTER DOM INSERT
            $('.change_destination').select2({ width: '100%' });
            $('.change_itinerary').select2({ width: '100%' });
            $('.change_itinerary_day').select2({
                width: '100%',
                placeholder: 'Please Select Days',
                templateResult: function (data) {
                    if (!data.id) return data.text;

                    let desc = $(data.element).attr('data-desc');
                    let $span = $('<span>').text(data.text);

                    if (desc) {
                        $span.attr('data-preview-desc', desc);
                    }
                    return $span;
                }
            });

            loadChangeDestinations();
            loadRowWiseItineraries();
        }
    });
});

////***For loading itinerary details on change itinerary dropdown *****///

////***For loading select2 change detination dropdown*****///

    /* ==========================================================
       2. Load Change Destination dropdown (once per row)
    ========================================================== */
    function loadChangeDestinations() {

        $('.change_destination').each(function () {

            let select = $(this);
            if (select.children().length > 1) return;

            $.getJSON('<?php echo base_url(); ?>index.php/Packages/gettdestination_details', function (res) {

                $.each(res, function (i, row) {
                    select.append(
                        `<option value="${row.state_id}">${row.state_name}</option>`
                    );
                });
            });
        });
    }

    ////***For loading select2 change detination dropdown*****///

    ////***For loading itiniraries in dropdown under duration nights*****///

    /* ==========================================================
       3. Auto-load itinerary dropdown using STAY destination
    ========================================================== */
    
    function loadRowWiseItineraries() {

      let duration = $('#packages_duration_in_nights').val();
      if (!duration) {
          alert('Please enter duration in nights first');
          return;
      }

      $('.change_itinerary').each(function () {

          let itinerarySelect = $(this);

          // 🚫 STOP if already loaded
          if (itinerarySelect.data('loaded') === 1) {
              return;
          }

          let row = itinerarySelect.closest('tr');
          let stayDestinationId = row.find('.stay_destination_id').val();

          if (!stayDestinationId) return;

          itinerarySelect
              .html('<option value="">Please Select Itinerary</option>')
              .data('loaded', 1); // ✅ mark as loaded

          $.ajax({
              url: '<?php echo base_url(); ?>index.php/Packages/fetch_itinerary',
              type: 'POST',
              dataType: 'json',
              data: {
                  itineraries_duration_nights: duration,
                  itineraries_days_destination_id_fk: stayDestinationId
              },
              success: function (res) {

                  $.each(res, function (i, rowData) {
                      itinerarySelect.append(`
                          <option value="${rowData.itineraries_id}">
                              ${rowData.itineraries_name}
                          </option>
                      `);
                  });
              }
          });
      });
  }

   
  /* ==========================================================
       4. Itinerary change → Load itinerary days
    ========================================================== */
  

    function initDaySelect2(el) {
    el.select2({
        width: '100%',
        placeholder: 'Please Select Days',
        allowClear: true,
        dropdownAutoWidth: true,
        templateResult: function (data) {

            if (!data.id) return data.text;

            var description = $(data.element).attr('data-desc');

            var $span = $('<span>').text(data.text);

            if (description) {
                $span.attr('data-preview-desc', description);
            }

            return $span;
        }
    });
}

  /* ==========================================================
       5. Itinerary description in block on mouse over itinerary days
    ========================================================== */

    $(document).on('change', '.change_itinerary', function () {

    let row = $(this).closest('tr');
    let itineraryId = $(this).val();
    let daySelect = row.find('.change_itinerary_day');

    // 🔥 Destroy existing Select2 instance
    if (daySelect.hasClass('select2-hidden-accessible')) {
        daySelect.select2('destroy');
    }

    daySelect.empty().append('<option value="">Please Select Days</option>');

    if (!itineraryId) {
        initDaySelect2(daySelect);
        return;
    }

    $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>index.php/Packages/fetch_days_under_itinerary",
        data: { itineraries_id_fk: itineraryId },
        dataType: "json",
        success: function (days) {

            $.each(days, function (i, day) {

                daySelect.append(
                    `<option value="${day.itineraries_days_id}"
                        data-desc="${day.itineraries_days_description}">
                         ${day.itineraries_days_day} | ${day.itineraries_days_title}
                    </option>`
                );
            });

            // ✅ Re-initialize Select2 AFTER options added
            initDaySelect2(daySelect);
        }
    });
});



var activeRowId = null;
var isMenuOpening = false;

$(document).on('select2:open', '.change_itinerary_day', function() {
    activeRowId = $(this).data('row-num');
    isMenuOpening = true;
    setTimeout(() => isMenuOpening = false, 200);
});

$(document).on('mouseenter', '.select2-results__option', function() {

    if (!activeRowId || isMenuOpening) return;

    var description = $(this).find('[data-preview-desc]').attr('data-preview-desc');
    var tooltip = $('#tooltip_' + activeRowId);

    if (description) {
        tooltip.html(description).fadeIn(100);
        $tooltip.css({ opacity: 1, transform: 'translateY(0)' }).show();

    }
});

$(document).on('select2:close', '.change_itinerary_day', function() {
    $('.day-description-tooltip').hide();
    activeRowId = null;
});



$(document).on('select2:select', '.change_itinerary_day', function (e) {

    let $select = $(this);
    let row = $select.closest('tr');

    let data = e.params.data;
    let description = $(data.element).attr('data-desc');

    if (!description) return;

    // 🔹 Update visible content
    row.find('.day-content-display').html(description);

    // 🔹 Update hidden textarea (for backend)
    row.find('.hidden-day-description').val(description);

    // 🔹 Hide tooltip
    // row.find('.day-description-tooltip').hide();

    // row.find('.hidden-day-description').show();

    // ClassicEditor.create(row.find('.hidden-day-description')[0]);

    // row.find('.day-content-display').hide();


});



});

////***For loading itiniraries in dropdown under duration nights and load days based on itineray and display details in tooltip *****///

    

////***For loading or dynamically add the inclusion and exclusion*****///

$(document).ready(function () {

  /* ==========================
     SELECTORS
     ========================== */
  const $wrapper = $('#inclusionExclusionWrapper');
  const $chk     = $('#packages_inclusion_exclusion_checked_type');
  const $ddl     = $('#packages_inclusion_exclusion_common_id_fk');

  const $incBox  = $('#inclusion');
  const $excBox  = $('#exclusion');

  // Button wrappers (your buttons are inside these)
  const $btnIncWrap = $('.add1');
  const $btnExcWrap = $('.add2');

  // Cards (heading + body + buttons)
  const $cardInc = $('#myDiv2');
  const $cardExc = $('#myDiv3');

  /* ==========================
     INITIAL STATE
     ========================== */
  $wrapper.hide();
  $cardInc.hide();
  $cardExc.hide();
  $btnIncWrap.hide();
  $btnExcWrap.hide();

  /* ==========================
     HELPERS
     ========================== */

  function clearTextareas() {
    $incBox.html('');
    $excBox.html('');
  }

  function showManualUI() {
    // Manual mode = checkbox checked + dropdown empty
    $cardInc.show();
    $cardExc.show();
    $btnIncWrap.show();
    $btnExcWrap.show();
  }

  function hideAllUI() {
    $cardInc.hide();
    $cardExc.hide();
    $btnIncWrap.hide();
    $btnExcWrap.hide();
  }

  function appendRow(type, value = '') {
    const isInc = type === 'inclusion';
    const name  = isInc ? 'packages_inclusions_details[]' : 'packages_exclusions_details[]';
    const cls   = isInc ? 'inclusion-row' : 'exclusion-row';

    const html = `
      <div class="d-flex gap-2 mb-2 ${cls} align-items-start">
        <textarea class="form-control" name="${name}" rows="3">${value}</textarea>
        <button type="button" class="btn btn-sm btn-danger remove-row"><b>X</b></button>
      </div>
    `;

    (isInc ? $incBox : $excBox).append(html);
  }

  function loadFromBackend(commonId) {
    $.ajax({
      url: '<?php echo base_url(); ?>index.php/Packages/get_inclusion_exclusion_details',
      type: 'POST',
      dataType: 'json',
      data: { common_id: commonId },
      success: function (res) {
        clearTextareas();

        // Show cards when loading (content visible)
        $cardInc.show();
        $cardExc.show();

        // Hide add buttons in load mode
        $btnIncWrap.hide();
        $btnExcWrap.hide();

        if (res.inclusions && res.inclusions.length) {
          $.each(res.inclusions, function (i, row) {
            appendRow('inclusion', row.inclusions_details || '');
          });
        }

        if (res.exclusions && res.exclusions.length) {
          $.each(res.exclusions, function (i, row) {
            appendRow('exclusion', row.exclusions_details || '');
          });
        }
      }
    });
  }

  function isManualMode() {
    return $chk.is(':checked') && !$ddl.val();
  }

  /* ==========================
     CHECKBOX TOGGLE
     ========================== */
  $chk.on('change', function () {

    if ($(this).is(':checked')) {

      // Show whole module
      $wrapper.slideDown();

      // Reset everything
      $ddl.val('');
      clearTextareas();

      // ✅ IMPORTANT: show cards + add buttons now
      showManualUI();

    } else {

      // Hide whole module
      $wrapper.slideUp();

      // Reset/clear
      $ddl.val('');
      clearTextareas();

      // Hide cards + buttons
      hideAllUI();
    }
  });

  /* ==========================
     DROPDOWN CHANGE
     ========================== */
  $ddl.on('change', function () {

    const commonId = $(this).val();
    clearTextareas();

    // If checkbox not checked, nothing should show
    if (!$chk.is(':checked')) {
      hideAllUI();
      return;
    }

    // Reset to manual mode (dropdown empty)
    if (!commonId) {
      showManualUI();
      return;
    }

    // Load mode (dropdown selected)
    loadFromBackend(commonId);
  });

  /* ==========================
     ADD MANUAL ROWS
     ========================== */
  $(document).on('click', '.add-inclusion', function () {
    if (!isManualMode()) return;
    $cardInc.show();
    appendRow('inclusion', '');
  });

  $(document).on('click', '.add-exclusion', function () {
    if (!isManualMode()) return;
    $cardExc.show();
    appendRow('exclusion', '');
  });

  /* ==========================
     REMOVE ROW
     ========================== */
  $(document).on('click', '.remove-row', function () {
    $(this).closest('.inclusion-row, .exclusion-row').remove();
  });

});


////***For loading or dynamically add the inclusion and exclusion*****///


////***For dynamically add the optional addon*****///

$(document).ready(function () {

    // Checkbox
    const $optChk = $('#packages_optional_add_on_checked_type');

    // Main container where rows are appended
    const $optBox = $('#optional-addon');

    // Keep a reference to the add button block so we don't remove it
    const $optAddBtnBlock = $optBox.find('.mb-3.col-md-6').first();

    // Hide Optional Add-on section initially if checkbox is not checked
    toggleOptionalAddonUI($optChk.is(':checked'));

    /* ==========================================
       CHECKBOX TOGGLE (SHOW/HIDE + CLEAR)
       ========================================== */
    $optChk.on('change', function () {
        const isChecked = $(this).is(':checked');

        // Show/hide UI
        toggleOptionalAddonUI(isChecked);

        // When toggling, clear all added rows
        clearOptionalAddonRows();
    });

    /* ==========================================
       ADD NEW OPTIONAL ADDON ROW
       ========================================== */
    $(document).on('click', '.add-optional-addon', function () {

        // Allow add only if checkbox checked
        if (!$optChk.is(':checked')) return;

        // Append a new row BEFORE the Add button block
        $optAddBtnBlock.before(`
            <div class="d-flex gap-2 mb-2 optional-addon-row align-items-start">
                <textarea name="packages_optional_add_on_details[]"
                          class="form-control"
                          rows="3"
                          placeholder="Enter optional add on"></textarea>

                <button type="button"
                        class="btn btn-sm btn-danger remove-optional-addon">
                    <b>X</b>
                </button>
            </div>
        `);
    });

    /* ==========================================
       REMOVE OPTIONAL ADDON ROW
       ========================================== */
    $(document).on('click', '.remove-optional-addon', function () {
        $(this).closest('.optional-addon-row').remove();
    });

    /* ==========================================
       HELPERS
       ========================================== */
    function toggleOptionalAddonUI(show) {
        // Hide/show the whole card column for optional-addon
        // (closest col-xl-10 col-lg-10 holds card)
        const $section = $optBox.closest('.col-xl-10.col-lg-10');

        if (show) {
            $section.slideDown();
        } else {
            $section.slideUp();
        }
    }

    function clearOptionalAddonRows() {
        // Remove only dynamically added rows, keep add button block
        $optBox.find('.optional-addon-row').remove();
    }

});

////***For dynamically add the optional addon*****///

////***For dynamically add the special requirments *****///

$(document).ready(function () {

    const $chk = $('#packages_special_requirment_checked_type');
    const $box = $('#special-requirments');
    const $cardCol = $box.closest('.col-xl-10.col-lg-10');

    // ✅ cache options so every row can reuse them
    let specialOptionsCache = null;

    // Hide section initially if unchecked
    if (!$chk.is(':checked')) $cardCol.hide();

    $chk.on('change', function () {
        if ($(this).is(':checked')) {
            $cardCol.slideDown();
            $box.find('.special-row').remove();
        } else {
            $cardCol.slideUp();
            $box.find('.special-row').remove();
        }
    });

    /* ==========================================================
       GET OPTIONS (CACHED)
       ========================================================== */
    function getSpecialOptions(callback) {

        // If already fetched once, reuse
        if (specialOptionsCache) {
            callback(specialOptionsCache);
            return;
        }

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/get_special_requirements",
            type: "GET",
            dataType: "json",
            success: function (res) {
                specialOptionsCache = res || [];
                callback(specialOptionsCache);
            }
        });
    }

    /* ==========================================================
       POPULATE A SELECT
       ========================================================== */
    function fillSelect($select, options) {

        $select.empty().append('<option value="">Please Select</option>');

        $.each(options, function (i, item) {
            $select.append(`<option value="${item.id}">${item.text}</option>`);
        });
    }

    /* ==========================================================
       GLOBAL FUNCTION used by onClick="addMore4();"
       ========================================================== */
    window.addMore4 = function () {

        if (!$chk.is(':checked')) return;

        const $btnBlock = $box.find('.mb-3.col-md-6').first();

        // ✅ create jQuery element so we can grab the select from THIS row
        const $row = $(`
            <div class="row special-row align-items-end mb-2">

                <div class="col-md-3">
                    <select name="special_requirements_id_fk[]"
                            class="form-control special-select"
                            required>
                        <option value="">Loading...</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <input type="text"
                           class="form-control special-amount"
                           name="packages_special_requirements_cost[]"
                           placeholder="Enter amount"
                           required>
                </div>

                <div class="col-md-1">
                    <button type="button" class="btn btn-sm btn-danger remove-special">
                        <b>X</b>
                    </button>
                </div>

            </div>
        `);

        // Insert before button block
        $btnBlock.before($row);

        // ✅ now target select inside THIS inserted row (not first row)
        const $select = $row.find('.special-select');

        // Load options (cached) and fill
        getSpecialOptions(function (options) {
            fillSelect($select, options);
        });
    };

    /* ==========================================================
       REMOVE ROW
       ========================================================== */
    $(document).on('click', '.remove-special', function () {
        $(this).closest('.special-row').remove();
    });

    /* ==========================================================
       ON CHANGE SELECT → LOAD AMOUNT
       ========================================================== */
    $(document).on('change', '.special-select', function () {

        const specialId = $(this).val();
        const $row = $(this).closest('.special-row');
        const $amount = $row.find('.special-amount');

        $amount.val('');

        if (!specialId) return;

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/get_special_requirement_amount",
            type: "POST",
            dataType: "json",
            data: { special_requirements_id: specialId },
            success: function (res) {
                $amount.val(res.amount || '');
            }
        });
    });

});

////***For dynamically add the special requirments *****///

////***For load or dynamically add the payment policies *****///

$(document).ready(function () {

    const $chk   = $('#packages_payment_policies_checked_type');
    const $ddl   = $('#payment_policies_id_fk');
    const $box   = $('#payment-policies');
    const $card  = $('#myDiv5');
    const $ddRow = $('#myDiv4');

    // Initial hide
    $ddRow.hide();
    $card.hide();

    /* ===============================
       CHECKBOX TOGGLE
       =============================== */
    $chk.on('change', function () {

        if ($(this).is(':checked')) {

            $ddRow.slideDown();
            $card.slideDown();

            resetPaymentPolicies(true);

        } else {

            $ddRow.slideUp();
            $card.slideUp();

            resetPaymentPolicies(false);
        }
    });

    /* ===============================
       DROPDOWN CHANGE
       =============================== */
    $ddl.on('change', function () {

        const id = $(this).val();

        clearRows();

        if (!id) {
            // Manual mode
            $('.payment_add').show();
            return;
        }

        // Load mode
        $('.payment_add').hide();

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/get_payment_policies_items",
            type: "POST",
            dataType: "json",
            data: { payment_policies_id: id },
            success: function (res) {

                $.each(res, function (i, row) {
                    appendRow(row.description || '');
                });
            }
        });
    });

    /* ===============================
       GLOBAL ADD FUNCTION (button)
       =============================== */
    window.addMore5 = function () {

        // Only allow manual add
        if (!$chk.is(':checked')) return;
        if ($ddl.val()) return;

        appendRow('');
    };

    /* ===============================
       APPEND TEXTAREA ROW
       =============================== */
    function appendRow(value) {

        const $btnBlock = $box.find('.payment_add').first();

        $btnBlock.before(`
            <div class="d-flex gap-2 mb-2 payment-row align-items-start">
                <textarea class="form-control"
                          name="packages_payment_policies_details[]"
                          rows="3">${value}</textarea>

                <button type="button"
                        class="btn btn-sm btn-danger remove-payment">
                    <b>X</b>
                </button>
            </div>
        `);
    }

    /* ===============================
       CLEAR ROWS
       =============================== */
    function clearRows() {
        $box.find('.payment-row').remove();
    }

    /* ===============================
       RESET FUNCTION
       =============================== */
    function resetPaymentPolicies(showAdd) {

        $ddl.val('');
        clearRows();

        if (showAdd) {
            $('.payment_add').show();
        } else {
            $('.payment_add').hide();
        }
    }

    /* ===============================
       REMOVE ROW
       =============================== */
    $(document).on('click', '.remove-payment', function () {
        $(this).closest('.payment-row').remove();
    });

});

////***For load or dynamically add the payment policies *****///

////***For load or dynamically add the terms and condition *****///

$(document).ready(function () {

    const $chk   = $('#packages_terms_conditions_checked_type');
    const $ddl   = $('#terms_condition_id_fk');
    const $box   = $('#terms-conditions');

    const $ddRow = $('#myDiv6');  // dropdown row
    const $card  = $('#myDiv7');  // card

    // Initial hide
    $ddRow.hide();
    $card.hide();

    /* ===============================
       CHECKBOX TOGGLE
       =============================== */
    $chk.on('change', function () {

        if ($(this).is(':checked')) {
            $ddRow.slideDown();
            $card.slideDown();
            resetTerms(true);
        } else {
            $ddRow.slideUp();
            $card.slideUp();
            resetTerms(false);
        }
    });

    /* ===============================
       DROPDOWN CHANGE
       =============================== */
    $ddl.on('change', function () {

        const id = $(this).val();

        clearTermsRows();

        // Manual mode
        if (!id) {
            $('.terms_add').show();
            return;
        }

        // Load mode
        $('.terms_add').hide();

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/get_terms_conditions_items",
            type: "POST",
            dataType: "json",
            data: { terms_condition_id: id },
            success: function (res) {
                $.each(res, function (i, row) {
                    appendTermsRow(row.description || '');
                });
            }
        });
    });

    /* ===============================
       GLOBAL ADD FUNCTION (button)
       =============================== */
    window.addMore6 = function () {

        // Only allow manual add
        if (!$chk.is(':checked')) return;
        if ($ddl.val()) return;

        appendTermsRow('');
    };

    /* ===============================
       APPEND TEXTAREA ROW
       =============================== */
    function appendTermsRow(value) {

        const $btnBlock = $box.find('.terms_add').first();

        $btnBlock.before(`
            <div class="d-flex gap-2 mb-2 terms-row align-items-start">
                <textarea class="form-control"
                          name="packages_terms_condition_details[]"
                          rows="3">${value}</textarea>

                <button type="button"
                        class="btn btn-sm btn-danger remove-terms">
                    <b>X</b>
                </button>
            </div>
        `);
    }

    /* ===============================
       CLEAR ROWS
       =============================== */
    function clearTermsRows() {
        $box.find('.terms-row').remove();
    }

    /* ===============================
       RESET
       =============================== */
    function resetTerms(showAdd) {

        $ddl.val('');
        clearTermsRows();

        if (showAdd) {
            $('.terms_add').show();
        } else {
            $('.terms_add').hide();
        }
    }

    /* ===============================
       REMOVE ROW
       =============================== */
    $(document).on('click', '.remove-terms', function () {
        $(this).closest('.terms-row').remove();
    });

});

////***For load or dynamically add the terms and condition *****///

////***For load or dynamically add the cancellation policy *****///

$(document).ready(function () {

    const $chk   = $('#packages_cancellation_policy_checked_type');
    const $ddl   = $('#cancellation_policies_id_fk');
    const $box   = $('#cancellation-policy');

    const $ddRow = $('#myDiv8');  // dropdown row
    const $card  = $('#myDiv9');  // card

    // Initial hide
    $ddRow.hide();
    $card.hide();

    /* ===============================
       CHECKBOX TOGGLE
       =============================== */
    $chk.on('change', function () {

        if ($(this).is(':checked')) {
            $ddRow.slideDown();
            $card.slideDown();
            resetCancellation(true);
        } else {
            $ddRow.slideUp();
            $card.slideUp();
            resetCancellation(false);
        }
    });

    /* ===============================
       DROPDOWN CHANGE
       =============================== */
    $ddl.on('change', function () {

        const id = $(this).val();

        clearCancellationRows();

        // Manual mode
        if (!id) {
            $('.terms_add').show(); // your add button wrapper is terms_add
            return;
        }

        // Load mode
        $('.terms_add').hide();

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/get_cancellation_policy_items",
            type: "POST",
            dataType: "json",
            data: { cancellation_policies_id: id },
            success: function (res) {
                $.each(res, function (i, row) {
                    appendCancellationRow(row.description || '');
                });
            }
        });
    });

    /* ===============================
       GLOBAL ADD FUNCTION (button)
       =============================== */
    window.addMore7 = function () {

        // Only allow manual add
        if (!$chk.is(':checked')) return;
        if ($ddl.val()) return;

        appendCancellationRow('');
    };

    /* ===============================
       APPEND TEXTAREA ROW
       =============================== */
    function appendCancellationRow(value) {

        const $btnBlock = $box.find('.terms_add').first();

        $btnBlock.before(`
            <div class="d-flex gap-2 mb-2 cancellation-row align-items-start">
                <textarea class="form-control"
                          name="packages_cancellation_policies_details[]"
                          rows="3">${value}</textarea>

                <button type="button"
                        class="btn btn-sm btn-danger remove-cancellation">
                    <b>X</b>
                </button>
            </div>
        `);
    }

    /* ===============================
       CLEAR ROWS
       =============================== */
    function clearCancellationRows() {
        $box.find('.cancellation-row').remove();
    }

    /* ===============================
       RESET
       =============================== */
    function resetCancellation(showAdd) {

        $ddl.val('');
        clearCancellationRows();

        if (showAdd) {
            $('.terms_add').show();
        } else {
            $('.terms_add').hide();
        }
    }

    /* ===============================
       REMOVE ROW
       =============================== */
    $(document).on('click', '.remove-cancellation', function () {
        $(this).closest('.cancellation-row').remove();
    });

});

////***For load or dynamically add the cancellation policy *****///

////***For dynamically add the notes *****///

$(document).ready(function () {

    const $chk = $('#packages_notes_checked_type');
    const $box = $('#add_notes');

    // Hide/show the whole Notes card column (col-xl-10 col-lg-10)
    const $cardCol = $box.closest('.col-xl-10.col-lg-10');

    // The add button block (we keep it, and insert rows before it)
    const $btnBlock = $box.find('.mb-3.col-md-6').first();

    /* ===============================
       INITIAL STATE
       =============================== */
    if (!$chk.is(':checked')) {
        $btnBlock.hide();
    }

    /* ===============================
       CHECKBOX TOGGLE
       =============================== */
    $chk.on('change', function () {

        if ($(this).is(':checked')) {
            $btnBlock.slideDown();
            clearNoteRows();
        } else {
            $btnBlock.slideUp();
            clearNoteRows();
        }
    });

    /* ===============================
       GLOBAL FUNCTION (button onClick)
       =============================== */
    window.addMore8 = function () {

        // Add only if checkbox checked
        if (!$chk.is(':checked')) return;

        // Insert a new textarea row before button block
        $btnBlock.before(`
            <div class="d-flex gap-2 mb-2 note-row align-items-start">
                <textarea class="form-control"
                          name="packages_notes_details[]"
                          rows="3"
                          placeholder="Enter note"
                          required></textarea>

                <button type="button"
                        class="btn btn-sm btn-danger remove-note">
                    <b>X</b>
                </button>
            </div>
        `);
    };

    /* ===============================
       REMOVE ROW
       =============================== */
    $(document).on('click', '.remove-note', function () {
        $(this).closest('.note-row').remove();
    });

    /* ===============================
       CLEAR ONLY DYNAMIC ROWS
       =============================== */
    function clearNoteRows() {
        $box.find('.note-row').remove();
    }

});

////***For dynamically add the notes *****///

////***For dynamically add the properties *****///

$(document).ready(function () {

  const $chk  = $('#packages_property_type');
  const $wrap = $('#property');

  // ✅ create hidden field for controller (if not exists)
  if ($('input[name="packages_property_checked_type"]').length === 0) {
    $('<input>', {
      type: 'hidden',
      name: 'packages_property_checked_type',
      value: ''
    }).appendTo('form'); // or $('#form') if your form id is form
  }

  const $hiddenFlag = $('input[name="packages_property_checked_type"]');

  // ✅ Global "+ Add new" button
  const $globalAddBtnBlock = $('[onClick="addMore10();"]').closest('.terms_add, .mb-3');

  let sectionCount = 0;

  $wrap.hide();
  $globalAddBtnBlock.hide();

  /* ===============================
     CHECKBOX TOGGLE
     =============================== */
  $chk.on('change', function () {

    if ($(this).is(':checked')) {

      // ✅ IMPORTANT for controller
      $hiddenFlag.val('Y');

      $wrap.slideDown();
      $globalAddBtnBlock.show();

      $wrap.empty();
      sectionCount = 0;

      // default first block open
      addMore10();

    } else {

      // ✅ IMPORTANT for controller
      $hiddenFlag.val('');

      $wrap.slideUp();
      $globalAddBtnBlock.hide();

      $wrap.empty();
      sectionCount = 0;
    }
  });

  /* ===============================
     READ DAYS FROM ITINERARY TABLE
     =============================== */
  // function getDaysFromItinerary() {
  //   const days = [];

  //   $('#itinerary tr').each(function () {
  //     const $tr = $(this);

  //     const dayText = $tr.find('td').eq(0).text().trim();
  //     const destName = $tr.find('td').eq(1).clone().children().remove().end().text().trim();
  //     const destId = $tr.find('.stay_destination_id').val();

  //     if (dayText && destName && destId) {
  //       days.push({ dayText, destName, destId });
  //     }
  //   });

  //   return days;
  // }

  function getDaysFromItinerary() {

  const days = [];

  $('#itinerary tr').each(function () {

    const $tr = $(this);

    const dayText = $tr.find('td').eq(0).text().trim();

    // ✅ ALWAYS read ACTIVE destination
    const destId   = $tr.find('.active-destination-id').val();
    const destName = $tr.find('.active-destination-name').val();

    if (dayText && destId && destName) {
      days.push({
        dayText: dayText,
        destId: destId,
        destName: destName
      });
    }
  });

  return days;
}


  // /* ===============================
  //    LOAD PROPERTIES
  //    =============================== */
  // function loadProperties(destId, $select) {

  //   if ($select.hasClass('select2-hidden-accessible')) {
  //     $select.select2('destroy');
  //   }

  //   $select.html('<option value="">Loading...</option>');

  //   $.ajax({
  //     url: '<?php echo base_url(); ?>index.php/Packages/get_properties_by_destination',
  //     type: 'POST',
  //     dataType: 'json',
  //     data: { destination_id: destId },
  //     success: function (res) {

  //       $select.empty().append('<option value="">Please Select Properties</option>');

  //       $.each(res, function (i, row) {
  //         $select.append(`<option value="${row.properties_id}">${row.properties_name}</option>`);
  //       });

  //       $select.select2({
  //         width: '100%',
  //         placeholder: 'Please Select Properties',
  //         allowClear: true
  //       });
  //     }
  //   });
  // }

  // /* ===============================
  //    LOAD ROOMS
  //    =============================== */
  // function loadRooms(propertyId, $roomsSelect) {

  //   // ✅ destroy previous select2 safely
  //   if ($roomsSelect.hasClass('select2-hidden-accessible')) {
  //     $roomsSelect.select2('destroy');
  //   }

  //   $roomsSelect.prop('disabled', true).empty();

  //   $.ajax({
  //     url: '<?php echo base_url(); ?>index.php/Packages/get_rooms_by_property',
  //     type: 'POST',
  //     dataType: 'json',
  //     data: { property_id: propertyId },
  //     success: function (res) {

  //       $roomsSelect.empty();

  //       $.each(res, function (i, r) {
  //         $roomsSelect.append(`<option value="${r.properties_room_category_id}">${r.properties_room_category_name}</option>`);
  //       });

  //       $roomsSelect.prop('disabled', false);

  //       $roomsSelect.select2({
  //         width: '100%',
  //         placeholder: 'Please Select Rooms'
  //       });
  //     }
  //   });
  // }

  /* ===============================
   LOAD PROPERTIES (with callback)
   =============================== */
  function loadProperties(destId, $select, done) {

    if ($select.hasClass('select2-hidden-accessible')) {
      $select.select2('destroy');
    }

    $select.html('<option value="">Loading...</option>');

    $.ajax({
      url: '<?php echo base_url(); ?>index.php/Packages/get_properties_by_destination',
      type: 'POST',
      dataType: 'json',
      data: { destination_id: destId },
      success: function (res) {

        $select.empty().append('<option value="">Please Select Properties</option>');

        $.each(res, function (i, row) {
          $select.append(`<option value="${row.properties_id}">${row.properties_name}</option>`);
        });

        $select.select2({ width:'100%', placeholder:'Please Select Properties', allowClear:true });

        if (typeof done === 'function') done(res);
      },
      error: function () {
        $select.empty().append('<option value="">Please Select Properties</option>');
        if (typeof done === 'function') done([]);
      }
    });
  }



  /* ===============================
    LOAD ROOMS (with callback)
    =============================== */
  function loadRooms(propertyId, $roomsSelect, done) {

    if ($roomsSelect.hasClass('select2-hidden-accessible')) {
      $roomsSelect.select2('destroy');
    }

    $roomsSelect.prop('disabled', true).empty();

    $.ajax({
      url: '<?php echo base_url(); ?>index.php/Packages/get_rooms_by_property',
      type: 'POST',
      dataType: 'json',
      data: { property_id: propertyId },
      success: function (res) {

        $roomsSelect.empty();

        $.each(res, function (i, r) {
          $roomsSelect.append(
            `<option value="${r.properties_room_category_id}">${r.properties_room_category_name}</option>`
          );
        });

        $roomsSelect.prop('disabled', false);

        $roomsSelect.select2({ width:'100%', placeholder:'Please Select Rooms' });

        if (typeof done === 'function') done(res);
      },
      error: function () {
        $roomsSelect.prop('disabled', false);
        if (typeof done === 'function') done([]);
      }
    });
  }

  

  function normalizeRoomIds(v) {
    if (!v) return [];
    if (Array.isArray(v)) return v.map(String);

    // if backend sends "1,2,3"
    if (typeof v === 'string') {
      return v.split(',').map(s => s.trim()).filter(Boolean).map(String);
    }

    // if backend sends number
    return [String(v)];
  }

  function setPropertyAndRoomsFromSaved(destId, $propSel, $roomsSel, savedPropertyId, savedRoomIds) {

    savedPropertyId = savedPropertyId ? String(savedPropertyId) : '';
    const roomVals = normalizeRoomIds(savedRoomIds);

    // 1) load properties for destination
    loadProperties(destId, $propSel, function () {

      // 2) select saved property AFTER options exist
      $propSel.val(savedPropertyId).trigger('change');     // ✅ triggers your handler
      if ($propSel.hasClass('select2-hidden-accessible')) {
        $propSel.trigger('change.select2');               // ✅ refresh UI
      }

      // if no property saved, stop
      if (!savedPropertyId) return;

      // 3) load rooms for property
      loadRooms(savedPropertyId, $roomsSel, function () {

        // 4) select saved rooms AFTER options exist
        $roomsSel.val(roomVals).trigger('change');
        if ($roomsSel.hasClass('select2-hidden-accessible')) {
          $roomsSel.trigger('change.select2');
        }
      });
    });
  }


  /* ===============================
     ADD SECTION (GLOBAL)
     =============================== */
  window.addMore10 = function () {

    if (!$chk.is(':checked')) return;

    const days = getDaysFromItinerary();

    // if (!days.length) {
    //   alert('Please select itinerary first (days not found).');
    //   return;
    // }

    sectionCount++;
    const sectionId = sectionCount;

    const $section = $(`
      <div class="property-section border rounded p-3 mb-4" data-section="${sectionId}">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div style="width: 420px;">
            <label><b>Category Name</b></label>
            <input type="text"
                   name="property_category_name[${sectionId}]"
                   class="form-control"
                   placeholder="Enter category name"
                   required>
          </div>

          <button type="button" class="btn btn-danger btn-sm remove-section">
            Remove Section
          </button>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th style="width:120px;">Day</th>
                <th style="width:220px;">Stay Destination</th>
                <th style="width:320px;">Property</th>
                <th>Rooms</th>
                <th style="width:120px;"></th>
              </tr>
            </thead>
            <tbody class="property-days-body"></tbody>
          </table>
        </div>
      </div>
    `);

    const $tbody = $section.find('.property-days-body');

    $.each(days, function (idx, d) {

      const dayIndex = idx + 1;

      const $dayRow = $(`
        <tr class="day-row" data-day-index="${dayIndex}">
          <td>${escapeHtml(d.dayText)}</td>

          <td>
            ${escapeHtml(d.destName)}
            <input type="hidden"
                   name="property_destination_id[${sectionId}][${dayIndex}]"
                   value="${escapeHtml(d.destId)}">
          </td>

          <td colspan="3">
            <div class="assignments" data-dest-id="${escapeHtml(d.destId)}"></div>
          </td>
        </tr>
      `);

      $tbody.append($dayRow);

      // first assignment row per day
      addAssignmentRow($dayRow, sectionId, dayIndex, d.destId, true);
    });

    $wrap.append($section);
  };

  function addAssignmentRow($dayRow, sectionId, dayIndex, destId, isFirstRow) {

    const $assignments = $dayRow.find('.assignments');
    const rowKey = Date.now() + '_' + Math.floor(Math.random() * 1000);

    const buttonsHtml = isFirstRow
      ? `<button type="button" class="btn btn-danger btn-sm add-assignment">+ Add</button>`
      : `<button type="button" class="btn btn-danger btn-sm remove-assignment">X</button>`;

    const $a = $(`
      <div class="assignment-row d-flex gap-3 align-items-start mb-2" data-row-key="${rowKey}">
        <div style="width:320px;">
          <select class="form-control property-select" required
                  name="properties_id[${sectionId}][${dayIndex}][${rowKey}]">
            <option value="">Please Select Properties</option>
          </select>
        </div>

        <div class="flex-grow-1">
          <select class="form-control rooms-select" multiple required disabled
                  name="rooms_id[${sectionId}][${dayIndex}][${rowKey}][]"></select>
        </div>

        <div style="width:120px;">
          ${buttonsHtml}
        </div>
      </div>
    `);

    $assignments.append($a);

    loadProperties(destId, $a.find('.property-select'));
    $a.find('.rooms-select').append('<option value="">Please Select Property First</option>');
  }

  $(document).on('click', '.add-assignment', function () {
    const $dayRow = $(this).closest('tr.day-row');
    const sectionId = $(this).closest('.property-section').data('section');
    const dayIndex = $dayRow.data('day-index');
    const destId = $dayRow.find('.assignments').data('dest-id');

    addAssignmentRow($dayRow, sectionId, dayIndex, destId, false);
  });

  $(document).on('click', '.remove-assignment', function () {
    const $row = $(this).closest('.assignment-row');

    const $rooms = $row.find('.rooms-select');
    if ($rooms.hasClass('select2-hidden-accessible')) {
      $rooms.select2('destroy');
    }

    $row.remove();
  });

  $(document).on('click', '.remove-section', function () {
    $(this).closest('.property-section').find('.rooms-select.select2-hidden-accessible').each(function () {
      $(this).select2('destroy');
    });
    $(this).closest('.property-section').remove();
  });

  $(document).on('change', '.property-select', function () {

    const selectedId = $(this).val();
    const $row = $(this).closest('.assignment-row');
    const $rooms = $row.find('.rooms-select');
    const $assignments = $(this).closest('.assignments');

    if ($rooms.hasClass('select2-hidden-accessible')) {
      $rooms.select2('destroy');
    }
    $rooms.empty().prop('disabled', true);

    if (!selectedId) {
      $rooms.append('<option value="">Please Select Property First</option>');
      return;
    }

    // duplicate check within same day
    let duplicate = false;
    $assignments.find('.property-select').not(this).each(function () {
      if ($(this).val() === selectedId) {
        duplicate = true;
        return false;
      }
    });

    if (duplicate) {
      alert('This property is already selected for this day.');
      $(this).val('').trigger('change.select2');
      $rooms.append('<option value="">Please Select Property First</option>');
      return;
    }

    loadRooms(selectedId, $rooms);
  });

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

});

////***For dynamically add the properties *****///

////***For properties blocks when change destination or change itinerary *****///

// ---------- PROPERTY RESET (call this when you want to clear everything) ----------
function resetPropertiesBlock() {
  // Uncheck checkbox
  $('#packages_property_type').prop('checked', false).trigger('change');

  // If your properties JS doesn't rely on trigger('change'), also hard clear:
  $('#property').empty().hide();

  // Hide global "+ Add new" (the one calling addMore10)
  $('[onClick="addMore10();"]').closest('.terms_add, .mb-3').hide();
}

// ---------- check if properties block currently has anything to lose ----------
function isPropertiesActiveOrDirty() {
  return $('#packages_property_type').is(':checked') || $.trim($('#property').html()) !== '';
}

// ---------- store previous value for any select (works for normal + select2) ----------
function bindPrevValueTracker(selector) {
  // normal select
  $(document).on('focus', selector, function () {
    $(this).data('prev', $(this).val());
  });

  // select2 select
  $(document).on('select2:opening', selector, function () {
    $(this).data('prev', $(this).val());
  });
}

let skipItineraryChange = false;

// $(document).on('change', '#packages_itinerary_id_fk', function () {

//   // if we are reverting value, don't run reload logic
//   if (skipItineraryChange) {
//     skipItineraryChange = false;
//     return;
//   }

//   const $sel = $(this);
//   const prev = $sel.data('prev');
//   const now  = $sel.val();

//   // If user selected same, no action
//   if (prev == now) return;

//   // Only confirm if properties has data/checked
//   if (isPropertiesActiveOrDirty()) {

//     const ok = confirm('Changing itinerary will clear the Property details block. Continue?');

//     if (!ok) {
//       // revert back
//       skipItineraryChange = true;
//       $sel.val(prev);

//       // refresh select2 UI if enabled
//       if ($sel.hasClass('select2-hidden-accessible')) {
//         $sel.trigger('change.select2');
//       } else {
//         $sel.trigger('change'); // optional
//       }
//       return;
//     }

//     // YES → clear properties block
//     resetPropertiesBlock();
//   }

//   // ✅ If confirmed or no properties data, your existing itinerary reload code will run after this
// });

let skipDestinationChange = false;

$(document).on('change', '.change_destination', function () {

  if (skipDestinationChange) {
    skipDestinationChange = false;
    return;
  }

  const $sel = $(this);
  const prev = $sel.data('prev');
  const now  = $sel.val();

  if (prev == now) return;

  // Ask confirmation only if properties is active/dirty
  if (isPropertiesActiveOrDirty()) {

    const ok = confirm('Changing destination will clear the Property details block. Continue?');

    if (!ok) {
      // revert to previous value
      skipDestinationChange = true;
      $sel.val(prev);

      // refresh select2 UI if enabled
      if ($sel.hasClass('select2-hidden-accessible')) {
        $sel.trigger('change.select2');
      } else {
        $sel.trigger('change');
      }
      return;
    }

    // YES → clear properties
    resetPropertiesBlock();
  }

  // ✅ allow your existing destination change logic to continue (load itinerary list etc)
});

////***For properties blocks when change destination or change itinerary *****///

</script>

                        