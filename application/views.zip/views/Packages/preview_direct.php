<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Travel Itinerary</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
  }

  /* === HERO / COVER === */
  .hero {
    height: 100vh;
    background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1950&q=80') no-repeat center center/cover;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    text-align: center;
  }

  .hero::before {
    content: "";
    position: absolute;
    inset: 0;
    background-color: rgba(0, 0, 0, 0.55);
    z-index: 0;
  }

  .hero-content {
    position: relative;
    z-index: 1;
    padding: 20px;
  }

  .hero h1 {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 15px;
  }

  .hero p {
    font-size: 1.2rem;
    margin-bottom: 25px;
  }

  .btn-custom {
    background-color: #ffc107;
    color: #000;
    border-radius: 50px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    transition: all 0.3s ease;
    text-decoration: none;
  }

  .btn-custom:hover {
    background-color: #ffcd39;
    transform: scale(1.05);
  }

  footer {
    position: absolute;
    bottom: 15px;
    width: 100%;
    text-align: center;
    color: rgba(255, 255, 255, 0.8);
  }

  /* === ITINERARY SECTION === */
  .itinerary-section {
    padding: 80px 15px;
  }

  .itinerary-section h1 {
    text-align: center;
    font-weight: 700;
    color: #007bff;
    margin-bottom: 50px;
  }

  /* === ITINERARY CARD === */
  .itinerary-card {
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    margin-bottom: 40px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    width: 100%;
  }

  .itinerary-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
  }

  /* Image as img element */
  .itinerary-card img {
    width: 100%;
    height: auto;
    /* height: 600px; */
    display: block;
    object-fit: cover;
  }

  /* Text Content */
  .itinerary-content {
    padding: 25px;
  }

  .itinerary-content h2 {
    color: #007bff;
    font-size: 1.6rem;
    font-weight: 600;
  }

  .itinerary-content p {
    color: #555;
    margin-top: 10px;
    margin-bottom: 15px;
  }

  .info {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    color: #6c757d;
    font-size: 0.9rem;
  }

  .btn-plan {
    margin-top: 10px;
    background-color: #ffc107;
    color: #000;
    border-radius: 50px;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    display: inline-block;
  }

  .btn-plan:hover {
    background-color: #ffcd39;
  }

  /* === RESPONSIVE DESIGN === */
  @media (max-width: 480px) {
    .btn-plan {
      font-size: 0.8rem;
      padding: 0.4rem 1rem;
    }
    .itinerary-content h2 {
      font-size: 1.3rem;
    }
    .itinerary-content p {
      font-size: 0.95rem;
    }
  }
</style>
</head>
<body>

<!-- HERO -->
<section class="hero">
  <div class="hero-content">
    <!-- <h1>Explore the World</h1>
    <p>Plan your dream journey with our personalized travel itinerary builder.</p> -->
    <h1><?php echo $package->packages_title; ?></h1>
<p><?php echo $package->packages_description; ?></p>
    <!-- <a href="#itinerary" class="btn-custom">Plan Your Trip</a> -->
  </div>
  <!-- <footer>© 2025 Wanderly Travels · <a href="#" class="text-white text-decoration-underline">Contact</a></footer> -->
</section>

<!-- ITINERARY SECTION -->
<section class="itinerary-section" id="itinerary">
  <div class="container">
    <h1>Your Travel Itinerary</h1>

    <?php foreach ($itinerary as $day): ?>
    <div class="itinerary-card">
      <img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad">
      <div class="itinerary-content">
        <h2>Day <?php echo $day->packages_itineraries_days_day; ?> – <?php echo $day->packages_itineraries_days_title; ?></h2>
        <p><?php echo nl2br($day->packages_itineraries_days_description); ?></p>
        <div class="info">
          <span>📍 <?php echo $day->state_name; ?></span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>

    

    
  </div>
</section>

<style>
        /* Container for each row */
.feature-row {
    display: flex;
    gap: 30px; /* Horizontal space between columns */
    flex-wrap: wrap; /* Allows columns to wrap on smaller screens */
    margin-bottom: 50px; /* Vertical gap between rows */
}

/* Each column */
.feature-col {
    flex: 1 1 calc(33.333% - 20px); /* 3 columns per row with spacing */
    display: flex;
    gap: 15px; /* Gap between icon and content inside column */
    align-items: flex-start;
    min-width: 250px; /* Ensure responsiveness */
}

/* Icon + number */
.feature-icon {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.feature-icon img {
    width: 60px;
    height: auto;
    margin-bottom: 5px;
}

.feature-number {
    color: #0E4DA4;
    margin: 0;
}

/* Content inside column */
.feature-content h2 {
    margin-top: 0;
    margin-bottom: 10px;
}

.feature-content ul {
    padding-left: 20px;
    margin: 0;
}

    </style>
    <style>
    

    /* === INCLUSION / EXCLUSION SECTION === */
.inclusion-exclusion-section {
  background: #f1f8ff;
}

.inclusion-exclusion-section .section-title {
  color: #007bff;
  font-weight: 700;
  margin-bottom: 10px;
}

.inclusion-exclusion-section .section-title span {
  color: #ffc107;
}

.inclusion-exclusion-section .section-subtitle {
  color: #555;
  font-size: 1.1rem;
  margin-bottom: 30px;
}

.inclusion-box, .exclusion-box {
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  background: #fff;
}

.inclusion-box:hover, .exclusion-box:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}

.inclusion-box h3, .exclusion-box h3 {
  font-weight: 600;
  margin-bottom: 15px;
}

.inclusion-box {
  border-left: 5px solid #28a745;
}

.exclusion-box {
  border-left: 5px solid #dc3545;
}

.inclusion-box ul, .exclusion-box ul {
  list-style: none;
  padding-left: 0;
  margin: 0;
}

.inclusion-box li, .exclusion-box li {
  position: relative;
  padding-left: 28px;
  margin-bottom: 10px;
  color: #555;
  font-size: 1rem;
}

.inclusion-box li::before {
  content: "✔";
  position: absolute;
  left: 0;
  color: #28a745;
  font-weight: bold;
}

.exclusion-box li::before {
  content: "✖";
  position: absolute;
  left: 0;
  color: #dc3545;
  font-weight: bold;
}

/* Responsive */
@media (max-width: 768px) {
  .inclusion-exclusion-section .section-title {
    font-size: 1.8rem;
  }
  .inclusion-box li, .exclusion-box li {
    font-size: 0.95rem;
  }
}

</style>

<?php if (!empty($inclusions) || !empty($exclusions)): ?>
    <section class="inclusion-exclusion-section py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="section-title">Inclusions & <span>Exclusions</span></h1>
      <p class="section-subtitle">Here’s what’s covered in your travel package—and what’s not.</p>
    </div>
<?php if (!empty($inclusions)): ?>
    <div class="row g-4">
      <!-- Inclusions -->
      <div class="col-md-6">
        <div class="inclusion-box p-4 h-100">
          <h3>✅ Inclusions</h3>
          <ul>
            <ul>
            <?php foreach ($inclusions as $i): ?>
            <li><?php echo $i->packages_inclusions_details; ?></li>
            <?php endforeach; ?>
            </ul>

          </ul>
        </div>
      </div>
<?php endif; ?>
<?php if (!empty($exclusions)): ?>
      <!-- Exclusions -->
      <div class="col-md-6">
        <div class="exclusion-box p-4 h-100">
          <h3>❌ Exclusions</h3>
          <ul>
            <ul>
            <?php foreach ($exclusions as $i): ?>
            <li><?php echo $i->packages_exclusions_details; ?></li>
            <?php endforeach; ?>
            </ul>

          </ul>
        </div>
      </div><?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>
<style>
  /* === OPTIONAL ADD-ONS LIST SECTION === */
.optional-addons-list {
  background: linear-gradient(135deg, #f9fbff 0%, #ffffff 100%);
}

.optional-addons-list .section-title {
  color: #007bff;
  font-weight: 700;
  margin-bottom: 10px;
}

.optional-addons-list .section-title span {
  color: #ffc107;
}

.optional-addons-list .section-subtitle {
  color: #555;
  font-size: 1.05rem;
  max-width: 650px;
  margin: 0 auto 40px;
}

/* Add-On List Styling */
.addon-list {
  list-style: none;
  margin: 0;
  padding: 0;
}

.addon-list li {
  display: flex;
  align-items: flex-start;
  background: #fff;
  border-radius: 10px;
  padding: 18px 24px;
  margin-bottom: 16px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
  transition: all 0.3s ease;
}

.addon-list li:hover {
  transform: translateX(8px);
  box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}

.addon-list .arrow {
  font-size: 1.4rem;
  color: #ffc107;
  margin-right: 18px;
  line-height: 1.2;
  flex-shrink: 0;
}

.addon-list div p {
  color: #444;
  margin: 0;
  line-height: 1.6;
  font-size: 0.98rem;
}

/* Responsive */
@media (max-width: 768px) {
  .addon-list li {
    flex-direction: column;
    align-items: flex-start;
  }

  .addon-list .arrow {
    margin-bottom: 8px;
  }

  .addon-list div p {
    font-size: 0.95rem;
  }
}

</style>
<?php if (!empty($optional_addons)): ?>
<!-- OPTIONAL ADD-ONS SECTION -->
<section class="optional-addons-list py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="section-title">✨ Optional <span>Add-Ons</span></h1>
      <p class="section-subtitle">Enhance your travel experience with premium upgrades and exclusive activities.</p>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <ul class="addon-list">
        <?php foreach ($optional_addons as $o): ?>
        <li><span class="arrow">➤</span><div><p><?php echo $o->packages_optional_add_on_details; ?></p></div></li>
        <?php endforeach; ?>
        </ul>

      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<style>
  /* === SPECIAL REQUIREMENTS SECTION === */
.special-req-section {
  background: linear-gradient(135deg, #f7fbff 0%, #ffffff 100%);
}

.special-req-section .section-title {
  color: #007bff;
  font-weight: 700;
  margin-bottom: 10px;
}

.special-req-section .section-title span {
  color: #ff7b00;
}

.special-req-section .section-subtitle {
  color: #555;
  font-size: 1.05rem;
  max-width: 650px;
  margin: 0 auto 40px;
}

/* Requirement Card */
.req-item {
  background: #fff;
  border-radius: 12px;
  padding: 18px 25px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 4px 20px rgba(0,0,0,0.05);
  transition: all 0.3s ease;
}

.req-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}

/* Left side (icon + name) */
.req-left {
  display: flex;
  align-items: center;
  gap: 15px;
}

.req-icon {
  font-size: 1.8rem;
  width: 50px;
  height: 50px;
  background: rgba(255, 123, 0, 0.1);
  color: #ff7b00;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.req-info p {
  margin: 0;
  font-size: 1rem;
  color: #333;
  font-weight: 500;
}

/* Right side (amount) */
.req-amount {
  font-size: 1rem;
  color: #007bff;
  font-weight: 600;
  white-space: nowrap;
}

/* Responsive Design */
@media (max-width: 768px) {
  .req-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }

  .req-amount {
    font-size: 0.95rem;
  }

  .req-icon {
    width: 42px;
    height: 42px;
    font-size: 1.5rem;
  }
}

</style>

<!-- SPECIAL REQUIREMENTS SECTION -->
<?php if (!empty($special_req)): ?>
<section class="special-req-section py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="section-title">📝 Special <span>Requirements</span></h1>
      <p class="section-subtitle">Customize your trip with additional services designed for your comfort and convenience.</p>
    </div>

    <div class="row g-4 justify-content-center">

      <!-- Requirement Item -->
      <div class="col-md-5 col-sm-12">
        <?php foreach ($special_req as $s): ?>
      <div class="req-item">
        <div class="req-info"><p class="req-name"><?php echo $s->special_requirements_name; ?></p></div>
        <div class="req-amount"><?php echo $s->packages_special_requirements_cost; ?></div>
      </div>
      <?php endforeach; ?>

      </div>

    </div>
  </div>
</section>
<?php endif; ?>

<style>
  /* PAYMENT POLICIES BOX */
.payment-policies-box {
  background-color: #f9faff;
  border: 2px solid #007bff;
  border-radius: 12px;
  padding: 0;
  overflow: hidden;
}

/* BOX TITLE WITH SEPARATE BACKGROUND */
.box-title-wrapper {
  background-color: #007bff; /* Title background */
  padding: 15px 20px;
}

.box-title {
  color: #fff; /* Title text color */
  font-weight: 700;
  font-size: 1.5rem;
  margin: 0;
  text-align: center;
}

/* LIST WITH ARROW ICONS */
.policies-list {
  list-style: none; /* remove default bullets */
  padding: 20px;
  margin: 0;
}

.policies-list li {
  position: relative;
  padding-left: 25px;
  margin-bottom: 12px;
  color: #555;
  font-size: 0.95rem;
  line-height: 1.5;
}

/* Arrow icon using CSS pseudo-element */
.policies-list li::before {
  content: '➤'; /* Arrow icon */
  position: absolute;
  left: 0;
  color: #007bff;
  font-size: 1rem;
  top: 0;
}

</style>
<!-- PAYMENT POLICIES SECTION AS LIST WITH ARROW ICON -->
<?php if (!empty($payment)): ?>
<section class="payment-policies-section py-4">
  <div class="container">
    <div class="payment-policies-box">
      <div class="box-title-wrapper">
        <h1 class="box-title">Payment Policies</h1>
      </div>

      <ul class="policies-list">
        <?php foreach ($payment as $p): ?>
          <?php if (!empty($p->packages_payment_policies_details)): ?>
            <li><?php echo nl2br(htmlspecialchars($p->packages_payment_policies_details)); ?></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>

    </div>
  </div>
</section>
<?php endif; ?>


<style>
/* TERMS & CONDITIONS CARD STYLE */
.terms-card {
  background-color: #ffffff; /* White card */
  border-radius: 15px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.08); /* Soft shadow */
  overflow: hidden;
  transition: transform 0.2s;
}

.terms-card:hover {
  transform: translateY(-3px);
}

/* HEADER BAR */
.terms-card-header {
  background-color: #007bff; /* Blue header */
  color: #fff;
  font-weight: 600;
  font-size: 1.4rem;
  padding: 18px 20px;
  text-align: center;
}

/* LIST WITH ARROW ICON */
.terms-card-list {
  list-style: none;
  padding: 20px;
  margin: 0;
}

.terms-card-list li {
  position: relative;
  padding-left: 28px;
  margin-bottom: 14px;
  font-size: 0.95rem;
  line-height: 1.5;
  color: #333;
}

.terms-card-list li::before {
  content: '➔'; /* Arrow icon */
  position: absolute;
  left: 0;
  color: #007bff; /* Match header */
  font-size: 1rem;
  top: 0;
}

</style>

<!-- TERMS & CONDITIONS SECTION - CARD STYLE -->
<?php if (!empty($terms)): ?>
<section class="terms-card-section py-4">
  <div class="container">
    <div class="terms-card">
      <div class="terms-card-header">
        Terms & Conditions
      </div>

      <ul class="terms-card-list">
        <?php foreach ($terms as $t): ?>
          <?php if (!empty($t->packages_terms_condition_details)): ?>
            <li><?php echo nl2br(htmlspecialchars($t->packages_terms_condition_details)); ?></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>

    </div>
  </div>
</section>
<?php endif; ?>


<style>
/* CANCELLATION POLICY CARD STYLE */
.cancellation-card {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.08);
  overflow: hidden;
  transition: transform 0.2s;
}

.cancellation-card:hover {
  transform: translateY(-3px);
}

/* HEADER BAR */
.cancellation-card-header {
  background-color: #28a745; /* Green header */
  color: #fff;
  font-weight: 600;
  font-size: 1.4rem;
  padding: 18px 20px;
  text-align: center;
}

/* LIST WITH ARROW ICON */
.cancellation-card-list {
  list-style: none;
  padding: 20px;
  margin: 0;
}

.cancellation-card-list li {
  position: relative;
  padding-left: 28px;
  margin-bottom: 14px;
  font-size: 0.95rem;
  line-height: 1.5;
  color: #333;
}

.cancellation-card-list li::before {
  content: '➔'; /* Arrow icon */
  position: absolute;
  left: 0;
  color: #28a745; /* Match header color */
  font-size: 1rem;
  top: 0;
}

</style>
<!-- CANCELLATION POLICY SECTION - CARD STYLE -->
<?php if (!empty($cancel)): ?>
<section class="cancellation-card-section py-4">
  <div class="container">
    <div class="cancellation-card">
      <div class="cancellation-card-header">
        Cancellation Policy
      </div>

      <ul class="cancellation-card-list">
        <?php foreach ($cancel as $c): ?>
          <?php if (!empty($c->packages_cancellation_policies_details)): ?>
            <li><?php echo nl2br(htmlspecialchars($c->packages_cancellation_policies_details)); ?></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>

    </div>
  </div>
</section>
<?php endif; ?>


<style>
  /* Notes Section Heading - Minimal Style */
.notes-header-alt h2 {
  font-size: 2rem;
  font-weight: 700;
  color: #333;
  border-bottom: 3px solid #ff6b6b; /* Underline accent */
  display: inline-block;
  padding-bottom: 5px;
  margin-bottom: 20px;
}

/* Notes Box - Minimal Card */
.notes-box-alt {
  background-color: #fff3e6; /* Soft cream background */
  border-left: 5px solid #ff6b6b; /* Accent border on left */
  padding: 20px 25px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

/* Notes List */
.notes-box-alt ul {
  list-style: none; /* Remove default bullets */
  padding-left: 0;
  margin: 0;
}

.notes-box-alt ul li {
  position: relative;
  padding-left: 20px;
  margin-bottom: 12px;
  font-size: 1rem;
  color: #444;
  line-height: 1.5;
}

/* Minimal arrow icon before each list item */
.notes-box-alt ul li::before {
  content: "→";
  position: absolute;
  left: 0;
  color: #ff6b6b; /* Accent color */
  font-weight: bold;
  top: 0;
}

</style>
<!-- NOTES SECTION -->
<?php if (!empty($notes)): ?>
<section class="notes-section-alt py-5">
  <div class="container">
    <div class="notes-header-alt">
      <h2>Notes</h2>
    </div>

    <div class="notes-box-alt">
      <ul>
        <?php foreach ($notes as $n): ?>
          <?php if (!empty($n->packages_notes_details)): ?>
            <li><?php echo nl2br(htmlspecialchars($n->packages_notes_details)); ?></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>
    </div>

  </div>
</section>
<?php endif; ?>


<!-------- 01 model ---------->
<style>
  .property-category-section {
  background-color: #f8f9fa;
}

.main-title {
  font-size: 2rem;
  color: #2c3e50;
  border-left: 6px solid #004aad;
  padding-left: 12px;
  font-weight: 700;
  margin-bottom: 1.5rem;
}

.category-header {
  background-color: #004aad;
  color: #fff;
  padding: 10px 20px;
  border-radius: 8px 8px 0 0;
}

.category-header h3 {
  font-size: 1.4rem;
  font-weight: 600;
  margin: 0;
}

.table-header-custom {
  background-color: #004aad;
  color: #fff;
}

.table {
  background-color: #fff;
  border-radius: 0 0 8px 8px;
  overflow: hidden;
}

.table th,
.table td {
  padding: 14px;
  vertical-align: middle;
}

.table tbody tr:hover {
  background-color: #f1f6ff;
  transition: background-color 0.3s ease;
}

.table td strong {
  color: #004aad;
}

/* .table td:first-child {
  text-align: center;
  font-weight: 600;
} */

@media (max-width: 768px) {
  .table th,
  .table td {
    font-size: 0.9rem;
  }
}
.day-cell {
  text-align: center;
  font-weight: 700;
  vertical-align: middle;
  color: #004aad;
}

.table td {
  text-align: left;
  font-weight: normal;
}

</style>

<section class="property-category-section py-5">
  <div class="container">
    <h2 class="main-title mb-4">Property Details</h2>

    <?php if (!empty($properties)): ?>
      <?php foreach ($properties as $cat): ?>

        <div class="category-block mb-5">
          <div class="category-header">
            <h3><?php echo htmlspecialchars($cat->packages_properties_common_category_name); ?></h3>
          </div>

          <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle shadow-sm">
              <thead class="table-header-custom">
                <tr>
                  <th style="width:10%">Day</th>
                  <th style="width:45%">Property Name</th>
                  <th style="width:45%">Room Type</th>
                </tr>
              </thead>

              <tbody>
                <?php foreach ($cat->days as $day): ?>

                  <?php
                    $totalRows = 0;
                    foreach ($day->rows as $r) {
                      $totalRows += count($r->rooms);
                    }
                    $dayPrinted = false;
                  ?>

                  <?php foreach ($day->rows as $prop): ?>
                    <?php foreach ($prop->rooms as $roomIndex => $room): ?>
                      <tr>
                        <!-- DAY COLUMN -->
                        <?php if (!$dayPrinted): ?>
                          <td rowspan="<?php echo $totalRows; ?>" class="day-cell">
                            <strong>Day <?php echo $day->day_no; ?></strong>
                          </td>
                          <?php $dayPrinted = true; ?>
                        <?php endif; ?>

                        <!-- PROPERTY COLUMN -->
                        <?php if ($roomIndex === 0): ?>
                          <td rowspan="<?php echo count($prop->rooms); ?>">
                            <?php echo htmlspecialchars($prop->property_name); ?>
                          </td>
                        <?php endif; ?>

                        <!-- ROOM COLUMN -->
                        <td><?php echo htmlspecialchars($room); ?></td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endforeach; ?>

                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

      <?php endforeach; ?>
    <?php else: ?>
      <p class="text-muted">No property details available.</p>
    <?php endif; ?>

  </div>
</section>


<!-- Sticky PDF Button -->
<!-- <a href="<?php echo base_url('index.php/Packages/download_pdf/'.$package->packages_id); ?>"
   class="pdf-download-btn"
   title="Download PDF">
  📄
</a> -->

<style>
.pdf-download-btn {
  position: fixed;
  right: 25px;
  bottom: 25px;
  background: #dc3545;
  color: #fff;
  font-size: 22px;
  width: 55px;
  height: 55px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  box-shadow: 0 6px 20px rgba(0,0,0,0.25);
  z-index: 9999;
  transition: transform 0.2s ease;
}

.pdf-download-btn:hover {
  transform: scale(1.1);
  color: #fff;
}
</style>

<!-------------- 02 model ----------->



<script>
// Accordion toggle
const dayHeaders = document.querySelectorAll('.day-header');
dayHeaders.forEach(header => {
  header.addEventListener('click', () => {
    const content = header.nextElementSibling;
    const isActive = header.classList.contains('active');

    if (!isActive) {
      content.style.maxHeight = content.scrollHeight + "px";
      header.classList.add('active');
    } else {
      content.style.maxHeight = null;
      header.classList.remove('active');
    }
  });
});
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
