<script>
// https://www.geeksforgeeks.org/jquery/how-to-get-a-dialog-box-if-there-is-no-internet-connection-using-jquery/
$(document).ready(function () {        
       
    $("#properties_room_category_welcomes_child_all_ages").change(function(){
        
        if($(this).val()=="Y"){

            
            $("#properties_room_category_admission_restricted_guests_under_age").prop('disabled',true);
            $('#properties_room_category_adult_rate_applied_guest_over').val('');
            $('#properties_room_category_adult_rate_applied_guest_over_hidden').val('');
        }
        else{

            $("#properties_room_category_admission_restricted_guests_under_age").prop('disabled',false);
            $('#properties_room_category_admission_restricted_guests_under_age').val('0');


            var complimentary = $('#properties_room_category_complimentary_guest_between_type').val('N').change();
            var child_rate = $('#properties_room_category_child_rate_applied_guest_between_type').val('N').change();
            $('#properties_room_category_complimentary_guest_between_from_year').val('');
            $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('');

            $('#properties_room_category_child_rate_applied_guest_from_year').val('');
            $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val('');

            $('#properties_room_category_adult_rate_applied_guest_over').val('0');
            $('#properties_room_category_adult_rate_applied_guest_over_hidden').val('0');

        }
        $('#properties_room_category_admission_restricted_guests_under_age').val('');
        $('#properties_room_category_complimentary_guest_between_from_year').val('');
        $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('');
        $('#properties_room_category_complimentary_guest_between_to_year').val('');
        $('#properties_room_category_child_rate_applied_guest_from_year').val('');
        $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val('');
        $('#properties_room_category_child_rate_applied_guest_to_year').val('');
        // event.preventDefault();
    });

     $("#properties_room_category_complimentary_guest_between_type").change(function(){
        
        if($(this).val()=="Y"){

            var welcomes = $('#properties_room_category_welcomes_child_all_ages :selected').val();
            if(welcomes == "Y"){


                $('#properties_room_category_complimentary_guest_between_from_year').val('0');
                $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('0');
                $("#properties_room_category_complimentary_guest_between_to_year").prop('disabled',false);
                
            }
            else{

                var restricted = $('#properties_room_category_admission_restricted_guests_under_age').val();
                //alert(restricted);
                $("#properties_room_category_complimentary_guest_between_to_year").prop('disabled',false);
                $('#properties_room_category_complimentary_guest_between_from_year').val(restricted);
                $('#properties_room_category_complimentary_guest_between_from_year_hidden').val(restricted);


            }

            
        }
        else{

            $("#properties_room_category_complimentary_guest_between_to_year").prop('disabled',true);
            $('#properties_room_category_complimentary_guest_between_from_year').val('');
            $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('');
            $('#properties_room_category_complimentary_guest_between_to_year').val('');

            var admission_restricted = $('#properties_room_category_admission_restricted_guests_under_age').val();

            var complimentaryto_year = $('#properties_room_category_child_rate_applied_guest_to_year').val();
             sumcomplimentaryto_year = parseFloat(complimentaryto_year) + 1;
            var child_rate_type = $('#properties_room_category_child_rate_applied_guest_between_type :selected').val();

            if(child_rate_type == 'Y'){

                 
                $('#properties_room_category_adult_rate_applied_guest_over').val(sumcomplimentaryto_year);
                $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumcomplimentaryto_year);

            }else{

                $('#properties_room_category_adult_rate_applied_guest_over').val(admission_restricted);
                $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumcomplimentaryto_year);
            }
        }
        
        // event.preventDefault();
    });

     $("#properties_room_category_child_rate_applied_guest_between_type").change(function(){
        
        if($(this).val()=="Y"){

            $("#properties_room_category_child_rate_applied_guest_to_year").prop('disabled',false);
            var complimentary_type = $('#properties_room_category_complimentary_guest_between_type :selected').val();
            var complimentaryto_year = $('#properties_room_category_complimentary_guest_between_to_year').val();
            var restricted = $('#properties_room_category_admission_restricted_guests_under_age').val();

            if(complimentary_type == 'Y' && complimentaryto_year != ''){

                var complimentaryto_year = $('#properties_room_category_complimentary_guest_between_to_year').val();
                sumcomplimentaryto_year = parseFloat(complimentaryto_year) + 1;
                
                
                $('#properties_room_category_child_rate_applied_guest_from_year').val(sumcomplimentaryto_year);
                $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val(sumcomplimentaryto_year);
            }
            else{

                $('#properties_room_category_child_rate_applied_guest_from_year').val(restricted);
                $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val(restricted);
            }
            
        }
        else{

            $("#properties_room_category_child_rate_applied_guest_to_year").prop('disabled',true);

            $('#properties_room_category_child_rate_applied_guest_from_year').val('');
            $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val('');
            $('#properties_room_category_child_rate_applied_guest_to_year').val('');

            var admission_restricted = $('#properties_room_category_admission_restricted_guests_under_age').val();
            var complimentary_to_year = $('#properties_room_category_complimentary_guest_between_to_year').val();
            sumcomplimentaryto_year = parseFloat(complimentary_to_year) + 1;
            var complimentary_type = $('#properties_room_category_complimentary_guest_between_type :selected').val();

            if(complimentary_type == 'Y'){

                
                $('#properties_room_category_adult_rate_applied_guest_over').val(sumcomplimentaryto_year);
                $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumcomplimentaryto_year);

            }else{

                $('#properties_room_category_adult_rate_applied_guest_over').val(admission_restricted);
                $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(admission_restricted);
            }
        }
        
        // event.preventDefault();
    });

    $(document).on('change input', '#properties_room_category_admission_restricted_guests_under_age', function(e){ 

         var admission_restricted = $('#properties_room_category_admission_restricted_guests_under_age').val();
         var complimentary_type = $('#properties_room_category_complimentary_guest_between_type :selected').val();
         var child_rate_type = $('#properties_room_category_child_rate_applied_guest_between_type :selected').val();

         var complimentary_to_year = $('#properties_room_category_complimentary_guest_between_to_year').val();
            sumcomplimentaryto_year = parseFloat(complimentary_to_year) + 1;

        var child_rate_appliedto_year = $('#properties_room_category_child_rate_applied_guest_to_year').val();
             sumchild_rate_appliedto_year = parseFloat(child_rate_appliedto_year) + 1;    

         if(complimentary_type == 'Y'){

            $('#properties_room_category_complimentary_guest_between_from_year').val(admission_restricted);
            $('#properties_room_category_complimentary_guest_between_from_year_hidden').val(admission_restricted);
            $('#properties_room_category_adult_rate_applied_guest_over').val(admission_restricted);
            $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(admission_restricted);

         }else{
            $('#properties_room_category_complimentary_guest_between_from_year').val('');
            $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('');
            $('#properties_room_category_adult_rate_applied_guest_over').val(admission_restricted);
            $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(admission_restricted);
         }

            
            $('#properties_room_category_complimentary_guest_between_to_year').val('');
            $('#properties_room_category_child_rate_applied_guest_from_year').val('');
            $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val('');
            $('#properties_room_category_child_rate_applied_guest_to_year').val('');
            // if(complimentary_type == 'N' && child_rate_type == 'N'){

            //     $('#properties_room_category_adult_rate_applied_guest_over').val(admission_restricted);

            // }
            // if(complimentary_type == 'Y' && child_rate_type == 'Y'){

            //     $('#properties_room_category_adult_rate_applied_guest_over').val(sumchild_rate_appliedto_year);

            // }
            // if(complimentary_type == 'N' && child_rate_type == 'Y'){

            //     $('#properties_room_category_adult_rate_applied_guest_over').val(sumchild_rate_appliedto_year);

            // }
            // if(complimentary_type == 'Y' && child_rate_type == 'N'){

            //     $('#properties_room_category_adult_rate_applied_guest_over').val(sumcomplimentaryto_year);

            // }
             
    });

    $(document).on('change input', '#properties_room_category_complimentary_guest_between_to_year', function(e){ 

         var complimentaryto_year = $('#properties_room_category_complimentary_guest_between_to_year').val();
             sumcomplimentaryto_year = parseFloat(complimentaryto_year) + 1;
         var child_rate_type = $('#properties_room_category_child_rate_applied_guest_between_type :selected').val();

         var  complimentaryfrom_year = $('#properties_room_category_complimentary_guest_between_from_year_hidden').val();

         
            if(child_rate_type == 'Y'){

               

             $('#properties_room_category_child_rate_applied_guest_from_year').val(sumcomplimentaryto_year);
             $('#properties_room_category_child_rate_applied_guest_from_year_hidden').val(sumcomplimentaryto_year);
             $('#properties_room_category_adult_rate_applied_guest_over').val(sumcomplimentaryto_year);
             $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumcomplimentaryto_year);


            }
            else{

                $('#properties_room_category_adult_rate_applied_guest_over').val(sumcomplimentaryto_year);
                $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumcomplimentaryto_year);
             }

             complimentaryto_year_ss = parseFloat(complimentaryto_year);
             complimentaryfrom_year_ss = parseFloat(complimentaryfrom_year);
             //alert(complimentaryto_year_ss);
             //alert(complimentaryto_year_ss);

             if(complimentaryto_year_ss < complimentaryfrom_year_ss){

                //alert("dd");
                $('#properties_room_category_complimentary_guest_between_to_year').val('');
                 var data1 = "To year should be greater than from year";
                $("#greater1_alert").html(data1);
                $("#greater1_alert").show();
               }
               else{

                $("#greater1_alert").hide();
               }
    });

    $(document).on('change input', '#properties_room_category_child_rate_applied_guest_to_year', function(e){ 

         var child_rate_appliedto_year = $('#properties_room_category_child_rate_applied_guest_to_year').val();
             sumchild_rate_appliedto_year = parseFloat(child_rate_appliedto_year) + 1;
             $('#properties_room_category_adult_rate_applied_guest_over').val(sumchild_rate_appliedto_year);
             $('#properties_room_category_adult_rate_applied_guest_over_hidden').val(sumchild_rate_appliedto_year);

        var child_rate_appliedfrom_year = $('#properties_room_category_child_rate_applied_guest_from_year').val();

        child_rate_appliedto_year_ss = parseFloat(child_rate_appliedto_year);
        child_rate_appliedfrom_year_ss = parseFloat(child_rate_appliedfrom_year);
        //alert(complimentaryto_year_ss);
        //alert(complimentaryto_year_ss);

        if(child_rate_appliedto_year_ss < child_rate_appliedfrom_year_ss){

            //alert("dd");
            $('#properties_room_category_child_rate_applied_guest_to_year').val('');
             var data1 = "To year should be greater than from year";
            $("#greater2_alert").html(data1);
            $("#greater2_alert").show();
        }
        else{

            $("#greater2_alert").hide();
        }
    });
});

////***Date picker *****///

$('#upload_tariff_document_from_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });

$('#upload_tariff_document_to_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });

////***Date picker *****///

////***Filter button hide and show*****///

$(document).ready(function () {
    $("#btn").click(function () {
        $("#Create").toggle();
    });
});

$(document).ready(function () {
    $("#btn1").click(function () {
        $("#Create1").toggle();
    });
});

$(document).ready(function () {
    $("#btn2").click(function () {
        $("#Create2").toggle();
    });
});
////***Filter button hide and show*****///

////***ajax hide & show on view page*****///
$(document).ready(function() {
    $(".panel-body a").on('click', function(e) {
        e.preventDefault()
        var page = $(this).data('page');
        $("#pages .page:not('.hide')").stop().fadeOut('fast', function() {
            $(this).addClass('hide');
            $('#pages .page[data-page="'+page+'"]').fadeIn('slow').removeClass('hide');
        });
    });
});

////***ajax hide & show on view page*****///

////***Property details on view*****///  

function Property_details(id){
    // var conf = confirm("Do you want to Edit details?");
    // if(conf){
        $('#Property_details').html();
        $.ajax({
        url:"<?php echo base_url();?>index.php/Property_registration/get_data",
        type: 'POST',
        data:{id:id},
        dataType: 'json',
        success:
        function(data)
        {
             //alert(data['id']);
               document.getElementById('Id').value=data['properties_id'];
                $("#properties_name").html(data['properties_name']);
                
               
               
            
        },
        
        error:function(e){
        console.log("error");
        }
      
      });
      $('.nav-link').removeClass('active');
      $('#Property_details').addClass('active');
}

////***Property details on view*****///

////***Room category details*****///

function Room_details(id){
    // alert(id);
    //var id = document.getElementById('Id').value;
    $table1 = $('#Room_registration').DataTable( {
        "searching": false,
        "processing": true,
        "serverSide": true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "bDestroy" : true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        // aLengthMenu: [
          // [1, 2],
          // [1, 2]
        // ],
        // iDisplayLength: 1,
        "fnDrawCallback": function () {
            $('.image-popup').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        closeBtnInside: true,
        fixedContentPos: true,
        image: {
          verticalFit: true
        },
        zoom: {
          enabled: true,
          duration: 300 // don't foget to change the duration also in CSS
        },
        });
    },
        dom: 'lBfrtip',
            buttons: [
                
                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Room details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Room details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Room details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Property_registration/get_roomcategory/"+id,
            "type": "POST",
            "data" : function (d) {
                        d.properties_id = $("#properties_id").val();
                        d.room_meal_plan_id = $("#room_meal_plan_id").val();
                        d.properties_room_category_id = $("#properties_room_category_id").val();
                        d.properties_room_category_createdby_user_id = $("#properties_room_category_createdby_user_id").val();
                        
                        
           }
        },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table1.column(0).nodes().each(function(node,index,dt){
            $table1.cell(node).data(index+1);
            });
            if(data['properties_room_category_photo'] == '')
            {
                $('td',row).eq(1).html('<img style="height: 40px; width: 40px;" src="<?php echo base_url();?>assets/images/user.png" />');
            }
            else{
                $('td',row).eq(1).html('<a class="image-popup" href="<?php echo base_url();?>uploads/Property-room-category-doc/'+data['properties_room_category_photo']+'"><img style="height: 40px; width: 40px;" src="<?php echo base_url();?>uploads/Property-room-category-doc/'+data['properties_room_category_photo']+'" /></a>');
           }
           $('td', row).eq(7).html('<div class="d-flex"><a href="javascript:void(0)" id="rt" onclick="edit_room('+data['properties_room_category_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_room('+data['properties_room_category_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a></div>');

           },

        "columns": [
            { "data": "properties_room_category_status", "orderable": false },
            { "data": "properties_room_category_photo", "orderable": false },
            { "data": "properties_room_category_name", "orderable": false },
            { "data": "meal_plan_name", "orderable": false },
            { "data": "properties_room_category_inventory", "orderable": false },
            { "data": "properties_room_category_description", "orderable": false },
            { "data": "properties_room_category_createdby_user_name", "orderable": false },
            { "data": "properties_room_category_id", "orderable": false },
            
   
        ]
        
    } );
    
    $('.nav-link').removeClass('active');
    $('#Room_details').addClass('active');
    
  }
    
 
////***Room category details*****///

////***Room category details*****///

function Upload_tariff_details(id){
    // alert(id);
    //var id = document.getElementById('Id').value;
    $table2 = $('#Tariff_uploaded_registration').DataTable( {
        "searching": false,
        "processing": true,
        "serverSide": true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "bDestroy" : true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        // aLengthMenu: [
          // [1, 2],
          // [1, 2]
        // ],
        // iDisplayLength: 1,
        
        dom: 'lBfrtip',
            buttons: [
                
                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Tariff uploaded details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Tariff uploaded details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Tariff uploaded details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Property_registration/get_uploaded_tariff/"+id,
            "type": "POST",
            "data" : function (d) {
                        d.start_date = $("#start_date").val();
                        d.end_date = $("#end_date").val();
                        d.upload_tariff_document_created_by_user_id = $("#upload_tariff_document_created_by_user_id").val();
                        
                        
           }
        },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table2.column(0).nodes().each(function(node,index,dt){
            $table2.cell(node).data(index+1);
            });
            if(data['upload_tariff_document_name'] == ""){
                        $('td', row).eq(3).html('<center> </center>');  
                    }
                    else{
                        $('td', row).eq(3).html('<center> <a target="_blank" href="<?php echo base_url();?>uploads/tariff-doc/'+data['upload_tariff_document_name']+'"><i class="fas fa-file"></i></a></center>');    
                    } 
           $('td', row).eq(6).html('<div class="d-flex"><a href="javascript:void(0)" id="rt" onclick="edit_tariff_document('+data['upload_tariff_document_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_tariff_document('+data['upload_tariff_document_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a></div>');

           },

        "columns": [
            { "data": "upload_tariff_document_status", "orderable": false },
            { "data": "upload_tariff_document_from_date", "orderable": false },
            { "data": "upload_tariff_document_to_date", "orderable": false },
            { "data": "upload_tariff_document_name", "orderable": false },
            { "data": "upload_tariff_document_description", "orderable": false },
            { "data": "upload_tariff_document_created_by_user_name", "orderable": false },
            { "data": "upload_tariff_document_id", "orderable": false },
            
   
        ]
        
    } );
    
    $('.nav-link').removeClass('active');
    $('#Upload_tariff_details').addClass('active');
    
  }
    
 
////***Room category details*****///  

////***searching button*****///

$('#search').click(function () {
        
        $table.ajax.reload();
    });

$('#search1').click(function () {
        
        $table1.ajax.reload();
    });

$('#search2').click(function () {
        
        $table2.ajax.reload();
    });
// $( "#b2b_partner_person_name1" ).keypress(function() {
//             $table.ajax.reload();
// });

////***searching button*****///

////***Latest Jquery form validation for adding form*****///
        
$("#form").validate({

            validClass: "success",
            rules: {
                    
                    // booking_work_order_end_date: { greaterThan: "#booking_work_order_date" }
                
            },
            messages: {
                
            },
            
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('input-success-o').addClass('input-warning-o');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
            },

        });

$("#form1").validate({

            validClass: "success",
            rules: {
                    
                    // booking_work_order_end_date: { greaterThan: "#booking_work_order_date" }
                
            },
            messages: {
                
            },
            
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('input-success-o').addClass('input-warning-o');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
            },

        });

$("#form2").validate({

            validClass: "success",
            rules: {
                    
                    // booking_work_order_end_date: { greaterThan: "#booking_work_order_date" }
                
            },
            messages: {
                
            },
            
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('input-success-o').addClass('input-warning-o');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
            },

        });
////***Latest Jquery form validation for adding form*****///

    ////***Listing table*****///

var save_method; //for save method string
var table;
  $(document).ready(function() {
    
    
    $table = $('#Property_registration').DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "bDestroy" : true,
        dom: 'lBfrtip',
            buttons: [
                
                                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Property registration details'
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Property registration details'
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0 ,1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Property registration details'
                                },
                               
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Property_registration/get/",
            "type": "POST",
            "data" : function (d) {
                        d.properties_id = $("#properties_id").val();
                        d.property_category_id_fk = $("#property_category_id_fk2").val();
                        d.country_id_fk = $("#country_id_fk2").val();
                        d.state_id_fk = $("#state_id_fk2").val();
                        d.properties_destination_id_fk = $("#properties_destination_id_fk2").val();
                        d.properties_createdby_userid = $("#properties_createdby_userid").val();
           }            
        },
        // "ajax": {
            // "url": "<?php echo site_url('States/get')?>",
            // "type": "POST"
        // },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table.column(0).nodes().each(function(node,index,dt){
            $table.cell(node).data(index+1);
            });
            
            

            // $('td', row).eq(5).html('<div class="form-button-action"><a  data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task" href="javascript:void(0)" onclick="edit_role('+data['roles_id']+')"><i class="fa fa-edit"></i></a><button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove" href="javascript:void(0)" onclick="return delete_role('+data['roles_id']+')"><i class="fa fa-times"></i></button></div>');

           // $('td', row).eq(7).html('<div class="d-flex"><a href="javascript:void(0)" id="rt" onclick="edit_property('+data['properties_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_property('+data['properties_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a><a href="javascript:void(0)" onclick="return delete_property('+data['properties_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-eye"></i></a></div>');

           // $('td', row).eq(7).html('<div class="btn-group" role="group"><button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown">Secondary</button><div class="dropdown-menu"><a class="dropdown-item" href="javascript:void()">Dropdown link</a><a class="dropdown-item" href="javascript:void()">Dropdown link</a></div></div>');
            
           $('td', row).eq(7).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_property('+data['properties_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_property('+data['properties_id']+')">Delete</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Property_registration/View/'+data['properties_id']+'" >View Details</a></div></div>');
            
           },

           "drawCallback": function( settings ) {
                // displaySelectByUserType();
            },

        "columns": [
            { "data": "properties_status", "orderable": false },
            { "data": "properties_name", "orderable": false },
            { "data": "property_category_name", "orderable": false },
            { "data": "name", "orderable": false },
            { "data": "plname", "orderable": false },
            { "data": "rcname", "orderable": false },
            { "data": "properties_createdby_username", "orderable": false },
            { "data": "properties_id", "orderable": false },
            
            
            
        ]
        
    });
    
  

  });
    
 
////***Listing table*****///

////***For close the modal *****///

function Propertymodalclose()
{

    $('#PropertyModal').modal('hide');
   
    //$( "div" ).remove( ".modal-backdrop" );
    $('#properties_name').val('');
    $('#property_category_id_fk').val('').change();
    $('#country_id_fk').val('').change();
    $('#state_id_fk').val('').change();
    $('#properties_destination_id_fk').val('').change();
    $('#properties_house_boat_type').val('').change();
    $('#properties_check_type').val('T').change();

    $('#category_name_alert').hide();
    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_name').removeClass('input-success-o');
    $('.properties_name').removeClass('input-warning-o');

    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#PropertyModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    $('#properties_name').focus();
    var id = $("#id").val();
    if(id == '')
    {
    $('#property_category_id_fk').val('').change();
    $('#country_id_fk').val('').change();
    $('#state_id_fk').val('').change();
    $('#properties_destination_id_fk').val('').change();
    $('#properties_house_boat_type').val('').change();
    $('#properties_check_type').val('T').change();
    }
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_name').removeClass('input-success-o');
    $('.properties_name').removeClass('input-warning-o');

    var check_type = $('#properties_check_type').val();

    if(check_type == 'T'){

        $('#row1').hide();
        $('#row2').show();
    }
    else{

        $('#row1').show();
        $('#row2').hide();
    }

})
////***For open the modal *****///

////***For open modal of Property adding form  *****///
    
function add_property()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#PropertyModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add property Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
}

////***For open modal of Property adding form  *****///

////***For editing Property details from adding modal form  *****///

function edit_property(id)
{
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    //$("#product").hide();  

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            
            $('[name="id"]').val(data.properties_id);
            $('[name="properties_name"]').val(data.properties_name);
            $('[id="property_category_id_fk"]').val(data.property_category_id_fk).trigger('change.select2');
            $('[id="country_id_fk"]').val(data.country_id_fk).trigger('change.select2');
            $('[id="state_id_fk"]').val(data.state_id_fk).trigger('change.select2');
            $('[name="properties_house_boat_type"]').val(data.properties_house_boat_type).trigger('change.select2');
            $('[id="properties_destination_id_fk"]').val(data.properties_destination_id_fk).trigger('change.select2');
            $('[name="properties_hotel_url"]').val(data.properties_hotel_url);
            $('[name="properties_name"]').val(data.properties_name);
            $('[name="properties_check_type"]').val(data.properties_check_type).trigger('change.select2');
            $('[name="properties_check_in_time"]').val(data.properties_check_in_time);
            $('[name="properties_check_out_time"]').val(data.properties_check_out_time);
            $('[name="properties_sales_contact_name"]').val(data.properties_sales_contact_name);
            $('[name="properties_sales_contact_phone_number"]').val(data.properties_sales_contact_phone_number);
            $('[name="properties_sales_contact_email"]').val(data.properties_sales_contact_email);
            $('[name="properties_reservation_contact_name"]').val(data.properties_reservation_contact_name);
            $('[name="properties_reservation_contact_phone_number"]').val(data.properties_reservation_contact_phone_number);
            $('[name="properties_reservation_contact_email"]').val(data.properties_reservation_contact_email);
            $('[name="properties_google_map_location"]').val(data.properties_google_map_location);
            $('[name="properties_hotel_logo_txt"]').val(data.properties_hotel_logo);
            $('[name="properties_photos_txt"]').val(data.properties_photos);
            $('[name="properties_description"]').val(data.properties_description);

            $('[name="properties_sales_contact_name1"]').val(data.properties_sales_contact_name);
            $('[name="properties_sales_contact_phone_number1"]').val(data.properties_sales_contact_phone_number);
            $('[name="properties_sales_contact_email1"]').val(data.properties_sales_contact_email);
            $('[name="properties_reservation_contact_name1"]').val(data.properties_reservation_contact_name);
            $('[name="properties_reservation_contact_phone_number1"]').val(data.properties_reservation_contact_phone_number);
            $('[name="properties_reservation_contact_email1"]').val(data.properties_reservation_contact_email);
            $('[name="properties_google_map_location1"]').val(data.properties_google_map_location);
            $('[name="properties_hotel_logo1_txt"]').val(data.properties_hotel_logo);
            $('[name="properties_photos1_txt"]').val(data.properties_photos);
            $('[name="properties_description1"]').val(data.properties_description);

              
            $('#PropertyModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit property Details'); // Set title to Bootstrap modal title
            $('#btnSave').text('update');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

////***For editing Property details from adding modal form  *****///

////***For reload the datatable  *****///

function reload_table()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        swal("Property details updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Property details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Property details added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Property details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

////***For reload the datatable  *****///

///***For save the Property details from adding modal form *****///

function save()
{
     
    var url;

    if(save_method == 'add') {
        $("#id").val('');
        $('#btnSave').text('saving...'); //change button text
        $('#btnSave').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_add/";
    } 
    else {

        $('#btnSave').text('updating...'); //change button text
        $('#btnSave').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_update/";
    }
    
    var fd = new FormData();
    
    var form = document.getElementById('form');
    var data = new FormData(form);
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: data, //$('#form').serialize(),
        dataType: "JSON",
        //cache : false,
        processData: false,
        enctype: 'multipart/form-data',
        contentType: false,
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {

                $('#PropertyModal').modal('hide');
                // $('body').removeClass('modal-open');
                // $('.modal-backdrop').remove();


                reload_table();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('input-warning-o'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            $('.help-block').val('hide');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

///***For save the Property details from adding modal form *****///

////***For reload the datatable for delete *****///

function reload_table_delete()
{
    $table.ajax.reload(null,false); //reload datatable ajax
    
    swal("Property details deleted successfully", "", "success")
        // var ff = 0;
        
        // ff = "Property details deleted successfully";

        //  $("#roles_delete").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
        
}

////***For reload the datatable for delete *****///
    
////***For reload the Property datatable for delete *****///

function delete_property(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.properties_id);
            $('[name="properties_name"]').val(data.properties_name);
            $('#deleterowModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title1').text('Do you want to delete this record?'); // Set title to Bootstrap modal title
            $('#btnSave1').text('delete');
            $('#btnSave1').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}

function delete_property_action()
{
    $('#btnSave1').text('deleting...'); //change button text
    $('#btnSave1').attr('disabled',true); //set button disable 
    var url;

        url = "<?php echo base_url();?>index.php/Property_registration/delete/";
        
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form1').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $("#id").val('');
                $('#deleterowModal').modal('hide');
                reload_table_delete();
                // ('body').removeClass('modal-open');
                //$('.modal-backdrop').remove();
                
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }

            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 

        }
    });
}

////***For delete the Property details from  database *****///

////***For close the modal *****///

function Roommodalclose()
{

    $('#RoomModal').modal('hide');
   
    //$( "div" ).remove( ".modal-backdrop" );
    $('#properties_room_category_name').val('');
    $('#room_meal_plan_id_fk').val('').change();
    $('#properties_room_category_welcomes_child_all_ages').val('Y').change();
    $('#properties_room_category_complimentary_guest_between_type').val('Y').change();
    $('#properties_room_category_child_rate_applied_guest_between_type').val('Y').change();


    $('#category_name_alert').hide();
    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_room_category_name').removeClass('input-success-o');
    $('.properties_room_category_name').removeClass('input-warning-o');

    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#RoomModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    $('#properties_room_category_name').focus();
    var id = $("#id").val();
    if(id == '')
    {
    $('#room_meal_plan_id_fk').val('').change();
    $('#properties_room_category_welcomes_child_all_ages').val('Y').change();
    $('#properties_room_category_complimentary_guest_between_type').val('Y').change();
    $('#properties_room_category_child_rate_applied_guest_between_type').val('Y').change();
    }
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_room_category_name').removeClass('input-success-o');
    $('.properties_room_category_name').removeClass('input-warning-o');

    

})
////***For open the modal *****///

////***For open modal of Room category adding form  *****///
    
function add_room()
{ 
    save_method = 'add';
    $("#id1").val('');
    $('#form1')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#RoomModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add room Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');

    var properties_id_fk = $("#properties_id_fk_hidden").val();
    $(".modal-body #properties_id_fk").val( properties_id_fk );

    var welcomes = $('#properties_room_category_welcomes_child_all_ages :selected').val();
    if(welcomes == "Y"){

        $("#properties_room_category_admission_restricted_guests_under_age").prop('disabled',true);

        $('#properties_room_category_complimentary_guest_between_from_year').val('0');
        $('#properties_room_category_complimentary_guest_between_from_year_hidden').val('0');

        
    }
    else{

        $("#properties_room_category_admission_restricted_guests_under_age").prop('disabled',false);


    }
}

////***For open modal of Room category adding form  *****///

////***For editing Room category details from adding modal form  *****///

function edit_room(id)
{
    save_method = 'update';
    $('#form1')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    //$("#product").hide();  

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit_room_category/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id1"]').val(data.properties_room_category_id);
            $('[name="properties_room_category_name"]').val(data.properties_room_category_name);
            $('[name="room_meal_plan_id_fk"]').val(data.room_meal_plan_id_fk).trigger('change.select2');
            $('[id="properties_room_category_inventory"]').val(data.properties_room_category_inventory);
            $('[id="properties_room_category_number_of_adults_allowed"]').val(data.properties_room_category_number_of_adults_allowed);            
            $('[id="properties_room_category_children_allowed_on_bed_sharing_basis"]').val(data.properties_room_category_children_allowed_on_bed_sharing_basis);
            $('[id="properties_room_category_extra_bed_mattress_allowed_in_room"]').val(data.properties_room_category_extra_bed_mattress_allowed_in_room);
            $('[name="properties_room_category_welcomes_child_all_ages"]').val(data.properties_room_category_welcomes_child_all_ages).trigger('change.select2');
            $('[id="properties_room_category_admission_restricted_guests_under_age"]').val(data.properties_room_category_admission_restricted_guests_under_age);
            $('[name="properties_room_category_complimentary_guest_between_type"]').val(data.properties_room_category_complimentary_guest_between_type).trigger('change.select2');
            $('[name="properties_room_category_complimentary_guest_between_from_year"]').val(data.properties_room_category_complimentary_guest_between_from_year);
            $('[name="properties_room_category_complimentary_guest_between_from_year_hidden"]').val(data.properties_room_category_complimentary_guest_between_from_year);
            $('[name="properties_room_category_complimentary_guest_between_to_year"]').val(data.properties_room_category_complimentary_guest_between_to_year);
            $('[name="properties_room_category_child_rate_applied_guest_between_type"]').val(data.properties_room_category_child_rate_applied_guest_between_type).trigger('change.select2');
            $('[name="properties_room_category_child_rate_applied_guest_from_year"]').val(data.properties_room_category_child_rate_applied_guest_from_year);
            $('[name="properties_room_category_child_rate_applied_guest_from_year_hidden"]').val(data.properties_room_category_child_rate_applied_guest_from_year);
            $('[name="properties_room_category_child_rate_applied_guest_to_year"]').val(data.properties_room_category_child_rate_applied_guest_to_year);
            $('[name="properties_room_category_adult_rate_applied_guest_over"]').val(data.properties_room_category_adult_rate_applied_guest_over);
            $('[name="properties_room_category_adult_rate_applied_guest_over_hidden"]').val(data.properties_room_category_adult_rate_applied_guest_over);
            $('[name="properties_room_category_description"]').val(data.properties_room_category_description);

              
            $('#RoomModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit room Details'); // Set title to Bootstrap modal title
            $('#btnSave1').text('update');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

////***For editing Room category details from adding modal form  *****///

////***For reload the datatable  *****///

function reload_table1()
{
    $table1.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id1").val();
    if(id)
    {  

        swal("Room details updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Room details added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Room details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

////***For reload the datatable  *****///

///***For save the room category details from adding modal form *****///

function save1()
{
     
    var url;

    if(save_method == 'add') {
        $("#id1").val('');
        $('#btnSave1').text('saving...'); //change button text
        $('#btnSave1').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_add_room_category/";
    } 
    else {

        $('#btnSave1').text('updating...'); //change button text
        $('#btnSave1').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_update_room_category/";
    }
    
    var fd = new FormData();
    
    var form = document.getElementById('form1');
    var data = new FormData(form);
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: data, //$('#form').serialize(),
        dataType: "JSON",
        //cache : false,
        processData: false,
        enctype: 'multipart/form-data',
        contentType: false,
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {

                $('#RoomModal').modal('hide');
                // $('body').removeClass('modal-open');
                // $('.modal-backdrop').remove();


                reload_table1();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('input-warning-o'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 
            $('.help-block').val('hide');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 

        }
    });
}

///***For save the room category details from adding modal form *****///

////***For reload the datatable for delete *****///

function reload_table_delete1()
{
    $table1.ajax.reload(null,false); //reload datatable ajax
    
    swal("Room details deleted successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room details deleted successfully";

        //  $("#roles_delete").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
        
}

////***For reload the datatable for delete *****///
    
////***For reload the Room datatable for delete *****///

function delete_room(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit_room_category/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id2"]').val(data.properties_room_category_id);
            $('[name="properties_room_category_name"]').val(data.properties_room_category_name);
            $('#deleterow1Modal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title1').text('Do you want to delete this record?'); // Set title to Bootstrap modal title
            $('#btnSave2').text('delete');
            $('#btnSave2').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}

function delete_room_action()
{
    $('#btnSave2').text('deleting...'); //change button text
    $('#btnSave2').attr('disabled',true); //set button disable 
    var url;

        url = "<?php echo base_url();?>index.php/Property_registration/delete_room_category/";
        
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form2').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $("#id2").val('');
                $('#deleterow1Modal').modal('hide');
                reload_table_delete1();
                // ('body').removeClass('modal-open');
                //$('.modal-backdrop').remove();
                
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }

            $('#btnSave2').text('save'); //change button text
            $('#btnSave2').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave2').text('save'); //change button text
            $('#btnSave2').attr('disabled',false); //set button enable 

        }
    });
}

////***For delete the Room details from  database *****///

////***For close the modal *****///

function Tariffuploadedmodalclose()
{

    $('#Tariff_uploadedModal').modal('hide');
   
    //$( "div" ).remove( ".modal-backdrop" );
    $('#upload_tariff_document_from_date').val('');
    $('#upload_tariff_document_to_date').val('');
    $('#upload_tariff_document_description').val('');
   


    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.upload_tariff_document_from_date').removeClass('input-success-o');
    $('.upload_tariff_document_from_date').removeClass('input-warning-o');
    $('.upload_tariff_document_to_date').removeClass('input-success-o');
    $('.upload_tariff_document_to_date').removeClass('input-warning-o');

    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#Tariff_uploadedModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    $('#upload_tariff_document_from_date').focus();
    
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.upload_tariff_document_from_date').removeClass('input-success-o');
    $('.upload_tariff_document_from_date').removeClass('input-warning-o');
    $('.upload_tariff_document_to_date').removeClass('input-success-o');
    $('.upload_tariff_document_to_date').removeClass('input-warning-o');

    

})
////***For open the modal *****///

////***For open modal of Tariff uploaded adding form  *****///
    
function add_tariff_uploaded()
{ 
    save_method = 'add';
    $("#id3").val('');
    $('#form3')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#Tariff_uploadedModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Upolad room tariff Details'); // Set Title to Bootstrap modal title
    $('#btnSave3').text('save');

    var properties_id_fk = $("#properties_id_fk_hidden").val();
    $(".modal-body #properties_id_fk1").val( properties_id_fk );

    
}

////***For open modal of Tariff uploaded adding form  *****///

////***For editing Tariff uploaded details from adding modal form  *****///

function edit_tariff_document(id)
{
    save_method = 'update';
    $('#form3')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    //$("#product").hide();  

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit_uploaded_tariff/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id3"]').val(data.upload_tariff_document_id);
            $('[name="upload_tariff_document_from_date"]').val(data.upload_tariff_document_from_date);
            $('[id="upload_tariff_document_to_date"]').val(data.upload_tariff_document_to_date);
            $('[name="upload_tariff_document_name_txt"]').val(data.upload_tariff_document_name);
            $('[id="upload_tariff_document_description"]').val(data.upload_tariff_document_description);            
            

              
            $('#Tariff_uploadedModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit upoladed room tariff Details'); // Set title to Bootstrap modal title
            $('#btnSave1').text('update');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

////***For editing Tariff uploaded details from adding modal form  *****///

////***For reload the datatable  *****///

function reload_table2()
{
    $table2.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id1").val();
    if(id)
    {  

        swal("Tariff uploaded updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Tariff uploaded updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Tariff uploaded successfully", "", "success")

        // var ff = 0;
        
        // ff = "Tariff uploaded successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

////***For reload the datatable  *****///

///***For save the Tariff uploaded details from adding modal form *****///

function save2()
{
     
    var url;

    if(save_method == 'add') {
        $("#id3").val('');
        $('#btnSave3').text('saving...'); //change button text
        $('#btnSave3').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_add_uploaded_tariff/";
    } 
    else {

        $('#btnSave3').text('updating...'); //change button text
        $('#btnSave3').attr('disabled',true); //set button disable

        url = "<?php echo base_url();?>index.php/Property_registration/ajax_update_uploaded_tariff/";
    }
    
    var fd = new FormData();
    
    var form = document.getElementById('form3');
    var data = new FormData(form);
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: data, //$('#form').serialize(),
        dataType: "JSON",
        //cache : false,
        processData: false,
        enctype: 'multipart/form-data',
        contentType: false,
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {

                $('#Tariff_uploadedModal').modal('hide');
                // $('body').removeClass('modal-open');
                // $('.modal-backdrop').remove();


                reload_table2();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('input-warning-o'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave3').text('save'); //change button text
            $('#btnSave3').attr('disabled',false); //set button enable 
            $('.help-block').val('hide');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave3').text('save'); //change button text
            $('#btnSave3').attr('disabled',false); //set button enable 

        }
    });
}

///***For save the Tariff uploaded details from adding modal form *****///

////***For reload the datatable for delete *****///

function reload_table_delete2()
{
    $table2.ajax.reload(null,false); //reload datatable ajax
    
    swal("Tariff uploaded deleted successfully", "", "success")
        // var ff = 0;
        
        // ff = "Tariff uploaded deleted successfully";

        //  $("#roles_delete").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
        
}

////***For reload the datatable for delete *****///
    
////***For reload the Tariff uploaded datatable for delete *****///

function delete_tariff_document(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Property_registration/ajax_edit_uploaded_tariff/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id4"]').val(data.upload_tariff_document_id);
            $('[name="upload_tariff_document_from_date"]').val(data.upload_tariff_document_from_date);
            $('[name="upload_tariff_document_to_date"]').val(data.upload_tariff_document_to_date);
            $('#deleterow2Modal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title2').text('Do you want to delete this record?'); // Set title to Bootstrap modal title
            $('#btnSave4').text('delete');
            $('#btnSave4').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}

function delete_tariff_document_action()
{
    $('#btnSave4').text('deleting...'); //change button text
    $('#btnSave4').attr('disabled',true); //set button disable 
    var url;

        url = "<?php echo base_url();?>index.php/Property_registration/delete_uploaded_tariff/";
        
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form4').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $("#id4").val('');
                $('#deleterow2Modal').modal('hide');
                reload_table_delete2();
                // ('body').removeClass('modal-open');
                //$('.modal-backdrop').remove();
                
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }

            $('#btnSave4').text('save'); //change button text
            $('#btnSave4').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave4').text('save'); //change button text
            $('#btnSave4').attr('disabled',false); //set button enable 

        }
    });
}

////***For delete the Tariff uploaded details from  database *****///

$(document).ready(function(){
// $("select[name='related_type']").onchange(function(){
$("#properties_check_type").change(function() {

if($(this).val()=="T")
{
// alert("oo");
$('#row1').hide();
$('#row2').show();
}
else
{
$('#row1').show();
$('#row2').hide();
}
});  
});

////***Validate Selected file is jpeg,jpg and png when select board image*****///

 
$(document).on("change",'.properties_hotel_logo1',function(){
        
        // alert("kj");
        
        var fileExtension = ['jpeg', 'jpg', 'png', 'pdf'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            // alert("Only formats are allowed : "+fileExtension.join(', '));
            ff = "Selected file format is not allowed, Allowed formats are : "+fileExtension.join(', ')+"";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
            // $('.original_image').val('');
            // $(this).closest('tr').find('.booking_closing_image').val('');
            // $(this).closest('tr').find('.booking_closing_image_class').addClass('has-error');
            
            $('#properties_hotel_logo1').val('');
            $('.properties_hotel_logo1').addClass('input-warning-o');
        }
    });

    
////***Validate Selected file is jpeg,jpg and png when select board image*****///

////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

$(document).on("change",'.properties_hotel_logo1',function(){


        var fi = document.getElementById('properties_hotel_logo1'); 
        // var fi = document.getElementById('campaign_booking_closing_image_' + icnt);
        // Check if any file is selected. 
        if (fi.files.length > 0) { 
            for (var i = 0; i <= fi.files.length - 1; i++) { 
  
                var fsize = fi.files.item(i).size; 
                var file = Math.round((fsize / 1024)); 
                // The size of the file. 
                if (file >= 3096) { 
                    // alert("File too Big, please select a file less than 3mb"); 
                    ff = "Selected image size greater than 3mb, kindly choose other image.";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
                      // setTimeout(original_image(){ n1.hide(); }, 2000);
                      // $('.original_image').addClass('has-error');
                      // $('.original_image').val('');
                      
                     
                      
                      $('#properties_hotel_logo1').val('');
                      $('.properties_hotel_logo1').addClass('input-warning-o');
                } 
                // else if (file < 2048) { 
                    // alert( 
                      // "File too small, please select a file greater than 2mb"); 
                // } 
                else { 
                    // document.getElementById('size').innerHTML = '<b>'
                    // + file + '</b> KB'; 
                } 
            } 
        } 
    });


////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

////***Validate Selected file is jpeg,jpg and png when select board image*****///

 
$(document).on("change",'.properties_hotel_logo',function(){
        
        // alert("kj");
        
        var fileExtension = ['jpeg', 'jpg', 'png', 'pdf'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            // alert("Only formats are allowed : "+fileExtension.join(', '));
            ff = "Selected file format is not allowed, Allowed formats are : "+fileExtension.join(', ')+"";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
            // $('.original_image').val('');
            // $(this).closest('tr').find('.booking_closing_image').val('');
            // $(this).closest('tr').find('.booking_closing_image_class').addClass('has-error');
            
            $('#properties_hotel_logo').val('');
            $('.properties_hotel_logo').addClass('input-warning-o');
        }
    });

    
////***Validate Selected file is jpeg,jpg and png when select board image*****///

////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

$(document).on("change",'.properties_hotel_logo',function(){


        var fi = document.getElementById('properties_hotel_logo'); 
        // var fi = document.getElementById('campaign_booking_closing_image_' + icnt);
        // Check if any file is selected. 
        if (fi.files.length > 0) { 
            for (var i = 0; i <= fi.files.length - 1; i++) { 
  
                var fsize = fi.files.item(i).size; 
                var file = Math.round((fsize / 1024)); 
                // The size of the file. 
                if (file >= 3096) { 
                    // alert("File too Big, please select a file less than 3mb"); 
                    ff = "Selected image size greater than 3mb, kindly choose other image.";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
                      // setTimeout(original_image(){ n1.hide(); }, 2000);
                      // $('.original_image').addClass('has-error');
                      // $('.original_image').val('');
                      
                     
                      
                      $('#properties_hotel_logo').val('');
                      $('.properties_hotel_logo').addClass('input-warning-o');
                } 
                // else if (file < 2048) { 
                    // alert( 
                      // "File too small, please select a file greater than 2mb"); 
                // } 
                else { 
                    // document.getElementById('size').innerHTML = '<b>'
                    // + file + '</b> KB'; 
                } 
            } 
        } 
    });


////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

////***Validate Selected file is jpeg,jpg and png when select board image*****///

 
$(document).on("change",'.properties_photos1',function(){
        
        // alert("kj");
        
        var fileExtension = ['jpeg', 'jpg', 'png', 'pdf'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            // alert("Only formats are allowed : "+fileExtension.join(', '));
            ff = "Selected file format is not allowed, Allowed formats are : "+fileExtension.join(', ')+"";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
            // $('.original_image').val('');
            // $(this).closest('tr').find('.booking_closing_image').val('');
            // $(this).closest('tr').find('.booking_closing_image_class').addClass('has-error');
            
            $('#properties_photos1').val('');
            $('.properties_photos1').addClass('input-warning-o');
        }
    });

    
////***Validate Selected file is jpeg,jpg and png when select board image*****///

////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

$(document).on("change",'.properties_photos1',function(){


        var fi = document.getElementById('properties_photos1'); 
        // var fi = document.getElementById('campaign_booking_closing_image_' + icnt);
        // Check if any file is selected. 
        if (fi.files.length > 0) { 
            for (var i = 0; i <= fi.files.length - 1; i++) { 
  
                var fsize = fi.files.item(i).size; 
                var file = Math.round((fsize / 1024)); 
                // The size of the file. 
                if (file >= 3096) { 
                    // alert("File too Big, please select a file less than 3mb"); 
                    ff = "Selected image size greater than 3mb, kindly choose other image.";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
                      // setTimeout(original_image(){ n1.hide(); }, 2000);
                      // $('.original_image').addClass('has-error');
                      // $('.original_image').val('');
                      
                     
                      
                      $('#properties_photos1').val('');
                      $('.properties_photos1').addClass('input-warning-o');
                } 
                // else if (file < 2048) { 
                    // alert( 
                      // "File too small, please select a file greater than 2mb"); 
                // } 
                else { 
                    // document.getElementById('size').innerHTML = '<b>'
                    // + file + '</b> KB'; 
                } 
            } 
        } 
    });


////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

////***Validate Selected file is jpeg,jpg and png when select board image*****///

 
$(document).on("change",'.properties_photos',function(){
        
        // alert("kj");
        
        var fileExtension = ['jpeg', 'jpg', 'png', 'pdf'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            // alert("Only formats are allowed : "+fileExtension.join(', '));
            ff = "Selected file format is not allowed, Allowed formats are : "+fileExtension.join(', ')+"";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
            // $('.original_image').val('');
            // $(this).closest('tr').find('.booking_closing_image').val('');
            // $(this).closest('tr').find('.booking_closing_image_class').addClass('has-error');
            
            $('#properties_photos').val('');
            $('.properties_photos').addClass('input-warning-o');
        }
    });

    
////***Validate Selected file is jpeg,jpg and png when select board image*****///

////***Validate Selected file is jpeg,jpg and png when booking and closing*****///

$(document).on("change",'.properties_photos',function(){


        var fi = document.getElementById('properties_photos'); 
        // var fi = document.getElementById('campaign_booking_closing_image_' + icnt);
        // Check if any file is selected. 
        if (fi.files.length > 0) { 
            for (var i = 0; i <= fi.files.length - 1; i++) { 
  
                var fsize = fi.files.item(i).size; 
                var file = Math.round((fsize / 1024)); 
                // The size of the file. 
                if (file >= 3096) { 
                    // alert("File too Big, please select a file less than 3mb"); 
                    ff = "Selected image size greater than 3mb, kindly choose other image.";
                      $("#validation_dynamic_table").val(ff);
                      var options = {
                        'title': '',
                        'style': 'error',
                        'message': ff,
                        'icon': 'warning',
                      };
                      var n1 = new notify(options); 
                      n1.show(); 
                      setTimeout(function(){ n1.hide(); }, 3000);
                      // setTimeout(original_image(){ n1.hide(); }, 2000);
                      // $('.original_image').addClass('has-error');
                      // $('.original_image').val('');
                      
                     
                      
                      $('#properties_photos').val('');
                      $('.properties_photos').addClass('input-warning-o');
                } 
                // else if (file < 2048) { 
                    // alert( 
                      // "File too small, please select a file greater than 2mb"); 
                // } 
                else { 
                    // document.getElementById('size').innerHTML = '<b>'
                    // + file + '</b> KB'; 
                } 
            } 
        } 
    });


////***Validate Selected file is jpeg,jpg and png when booking and closing*****///
</script>