
<script type="text/javascript">

////***Select2 option *****///

$("#quotation_number_filter").select2({
  // dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});

$("#leads_id_filter").select2({
  // dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});

$("#package_id_filter").select2({
  // dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#quotation_created_by_userid").select2({
  // dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#quotation_current_status_filter").select2({
  // dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
////***Select2 option *****///

////***Date picker *****///

////***Date picker *****///

$('#quotation_date').bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: 'DD/MM/YYYY'
}).bootstrapMaterialDatePicker('setDate', moment());

$('#start_date').bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: 'DD/MM/YYYY'
})

$('#end_date').bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: 'DD/MM/YYYY'
})
 
////***Date picker *****///

////***Filter button hide and show*****///

$(document).ready(function () {
    $("#btn").click(function () {
        $("#Create").toggle();
    });
});

$(document).ready(function () {
    $("#btn1").click(function () {
        $("#Create1").toggle();
    });
});

$(document).ready(function () {
    $("#btn2").click(function () {
        $("#Create2").toggle();
    });
});


////***Filter button hide and show*****///

////***searching button*****///

$('#search').click(function () {
        
        $table.ajax.reload();
    });

$('#search1').click(function () {
        
        $table1.ajax.reload();
    });

$('#search2').click(function () {
        
        $table2.ajax.reload();
    });

$( "#arriving_destination_filter" ).keypress(function() {
            $table.ajax.reload();
});
$( "#departuring_destination_filter" ).keypress(function() {
            $table.ajax.reload();
});
////***searching button*****///

////***Listing table*****///

var save_method; //for save method string
var table;
  $(document).ready(function() {
    
    
    $table = $('#Quotation_registration').DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        dom: 'lBfrtip',
            buttons: [
                
                                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6, 7]
                                    }
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6, 7]
                                    }
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0 ,1, 2, 3, 4, 5, 6, 7]
                                    }
                                },
                               
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Quotation/get/",
            "type": "POST",
            "data" : function (d) {
                        d.quotation_number_filter = $("#quotation_number_filter").val();
                        d.leads_id_filter = $("#leads_id_filter").val();
                        d.package_id_filter = $("#package_id_filter").val();
                        d.arriving_destination_filter = $("#arriving_destination_filter").val();
                        d.departuring_destination_filter = $("#departuring_destination_filter").val();
                        d.quotation_current_status_filter = $("#quotation_current_status_filter").val();
                        d.quotation_created_by_userid = $("#quotation_created_by_userid").val();
                        d.start_date = $("#start_date").val();
                        d.end_date = $("#end_date").val();
                        
                       
           }            
        },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table.column(0).nodes().each(function(node,index,dt){
            $table.cell(node).data(index+1);
            });
            
            
            $('td', row).eq(8).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="change_status('+data['quotation_id']+')">Change status</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Quotation/preview_quotation/'+data['quotation_id']+'" >Preview</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_package('+data['quotation_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_quotation('+data['quotation_id']+')">Delete</a></div></div>');

            if(data['quotation_current_status'] == 1){
              $('td', row).eq(6).html('<span class="badge badge-secondary">Generated</span>');

            }
            else if(data['quotation_current_status'] == 2){
              $('td', row).eq(6).html('<span class="badge badge-light">Draft</span>');
            }
            else if(data['quotation_current_status'] == 3){
              $('td', row).eq(6).html('<span class="badge badge-info">Sent</span>');
            }
            else if(data['quotation_current_status'] == 4){
              $('td', row).eq(6).html('<span class="badge badge-danger">Rejected</span>');
            }
            else if(data['quotation_current_status'] == 5){
              $('td', row).eq(6).html('<span class="badge badge-success">Accepted</span>');
            }
            
           },

           "drawCallback": function( settings ) {
                // displaySelectByUserType();
            },

        "columns": [
            { "data": "quotation_status", "orderable": false },
            { "data": "quotation_number", "orderable": false },
            { "data": "leads_number", "orderable": false },
            { "data": "packages_title", "orderable": false },
            { "data": "quotation_date", "orderable": false },
            { "data": "quotation_remarks", "orderable": false },
            { "data": "quotation_current_status", "orderable": false },
            { "data": "quotation_created_by_username", "orderable": false },                      
            { "data": "quotation_id", "orderable": false }
            
            
        ]
        
    });
    
  

  });
    
 
////***Listing table*****///

    ////***For open modal of room tariff adding form  *****///
    
function add_packages()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#PackagesModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Create Quotation Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
}

////***For open modal of room tariff adding form  *****///

////***Ajax dropdown for add*****///


$(document).ready(function() {
    $('#packages_itinerary_category_id_fk').change(function() {
    //alert("oo");
        var packages_itinerary_category_id_fk = $('#packages_itinerary_category_id_fk').val();
        var packages_duration_in_nights = $('#packages_duration_in_nights').val();

    
        if(packages_itinerary_category_id_fk != '') {
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/fetch_itinerary_under_category",
            method: "POST",
            data: {
                packages_itinerary_category_id_fk: packages_itinerary_category_id_fk,packages_duration_in_nights:packages_duration_in_nights
            },
            success: function(data) {
                $('#packages_itinerary_id_fk').html(data);
                // $('#city').html('<option value="">Select City</option>');
            }
        });
        } else {
            $('#packages_itinerary_id_fk').html('<option value="0">Please Select Lead</option>');
            // $('#city').html('<option value="">Select City</option>');
        }

    });
});
////***Ajax dropdown for add*****///

$(document).ready(function() {

    $('#myDiv1').hide();
    $('#myDiv2').hide();
    $('#myDiv3').hide();
    $('#optional-addon').hide();
    $('#special-requirments').hide();
    //$('#payment-policies').hide();
    $('#myDiv4').hide();
    $('#myDiv5').hide();
    $('#myDiv6').hide();
    $('#myDiv7').hide();
    $('#myDiv8').hide();
    $('#myDiv9').hide();
    $('#add_notes').hide();
  // Listen for changes on the checkbox
  $('#packages_inclusion_exclusion_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#myDiv1').show();
      $('#myDiv2').show();
      $('#myDiv3').show();
    } else {
      // If unchecked, hide the div
      $('#myDiv1').hide();
      $('#myDiv2').hide();
      $('#myDiv3').hide();
    }
  });


  $('#packages_optional_add_on_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#optional-addon').show();

    } else {
      // If unchecked, hide the div
      $('#optional-addon').hide();

    }
  });
$('#packages_special_requirment_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#special-requirments').show();

    } else {
      // If unchecked, hide the div
      $('#special-requirments').hide();

    }
  });

  $('#packages_payment_policies_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#myDiv4').show();
      $('#myDiv5').show();
    } else {
      // If unchecked, hide the div
      $('#myDiv4').hide();
      $('#myDiv5').hide();

    }
  });

  $('#packages_terms_conditions_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#myDiv6').show();
      $('#myDiv7').show();
    } else {
      // If unchecked, hide the div
      $('#myDiv6').hide();
      $('#myDiv7').hide();

    }
  });

  $('#packages_cancellation_policy_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#myDiv8').show();
      $('#myDiv9').show();
    } else {
      // If unchecked, hide the div
      $('#myDiv8').hide();
      $('#myDiv9').hide();

    }
  });

  $('#packages_notes_checked_type').change(function() {
    // Check if the checkbox is currently checked
    if ($(this).is(':checked')) {
      // If checked, show the div
      $('#add_notes').show();
    } else {
      // If unchecked, hide the div
      $('#add_notes').hide();

    }
  });

  $('#packages_inclusion_exclusion_common_id_fk').change(function() {
    
    // Check if the checkbox is currently checked
    if ($('#packages_inclusion_exclusion_common_id_fk').val() == '') {
        // alert("k");
      // If checked, show the div
      $('.add1').show();
      $('.add2').show();
      $('.inc').hide();
      $('.exc').hide();
    } else {
        // alert("d");
      // If unchecked, hide the div
      $('.add1').hide();
      $('.add2').hide();
      $('.inc').show();
      $('.exc').show();
    }
  });

  $('#payment_policies_id_fk').change(function() {
    
    // Check if the checkbox is currently checked
    if ($('#payment_policies_id_fk').val() == '') {
        // alert("k");
      // If checked, show the div
      $('.payment_add').show();
      $('.payment').hide();
    } else {
        // alert("d");
      // If unchecked, hide the div
      $('.payment_add').hide();
      $('.payment').show();
    }
  });
  
});

var counter10 = 1;

var n10 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit10 = $("#counter_edit1").val();



if(counter_edit10 >0){
    counter10 = counter_edit10-1;
}

function addMore10() {

  var itinerary_category_id = $("#packages_itinerary_id_fk").val();

  $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     
      // <div class="col-sm-4 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" onClick="addMore9('+num1+');">+ Add new</button> </div>
    //$("#product-item_"+num).append(htmlVal);

  var num1 = 1; var num = 1;
  
  $.ajax({
      url: "<?php echo base_url(); ?>index.php/Packages/itinerary_array_list/",
      dataType: 'json',
      type: 'POST',
      data:{itinerary_category_id:itinerary_category_id},
      success: function(data) {    
          var result = data;
      // console.log(result);

      var field1 = [];
      
      $.each(result, function (i, item) {                

          
          //field1.push('<tr><td>'+item.itineraries_days_day+'</td><td>'+item.state_name+'</td><td><div class="row" id="product-item_'+num1+'">&nbsp <input type="hidden" name="sub-counter-'+num1+'" id="sub-counter-'+num1+'" value="0" /> <div class="col-sm-4"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select properties" required> <option value="">Please Select Properties</option> </select> </div> <div class="col-sm-4 mt-2 mt-sm-0"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select" required> <option value="">Please Select Rooms</option> </select> </div> <div class="col-sm-3 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" onClick="addMore9('+num1+');">+ Add new</button> </div> </div></td></tr>');

          // field1.push('<tr><td><strong>Day1 | ARRIVAL AT COCHIN & TRANSFER TO MUNNAR</strong></td><td><div class="d-flex align-items-center">Alappuzha</div></td><td> <div class="row"> <div class="col-sm-4"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select" required> <option value="">Please Search by title</option> </select> </div> <div class="col-sm-4 mt-2 mt-sm-0"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select" required> <option value="">Please Search by title</option>  </select> </div> <div class="col-sm-4 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" >+ Add new</button> </div> </div> </td></tr> </tbody></table></div>');
          field1.push('<tr><td>'+item.itineraries_days_day+'</td><td>'+item.state_name+'</td><td><div class="row" id="product-item_'+num1+'">&nbsp <input type="hidden" name="sub-counter-'+num1+'" id="sub-counter-'+num1+'" value="0" /> <div class="col-sm-4"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select properties" required> <option value="">Please Select Properties</option> </select> </div> <div class="col-sm-4 mt-2 mt-sm-0"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select" required> <option value="">Please Select Rooms</option> </select> </div> <div class="col-sm-3 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" onClick="addMore9('+num1+');">+ Add new</button> </div> </div></td></tr>');  
          
          num1++;
          
      });

          // $("#counter_edit1").val(num);    
      console.log(field1); 
      //$("#stg").html(field);
      //$("#row1").append(field);
      var htmlVal = '<div class="row"> <div class="col-md-3"> <div class="form-group"> <input type="text" name="packages_properties_common_category_name['+counter10+']" id="packages_properties_common_category_name_'+counter10+'" class="form-control" placeholder="Enter category name" value="" required/> <span class="help-block" style="color:red"></span> </div> </div> </div> <div class="table-responsive"> <table class="table table-responsive-md" id="table2"> <thead> <tr> <th><strong>Day</strong></th><th><strong>Stay Destination</strong></th><th><strong>Properties and room</strong></th></tr></thead> <tbody> '+field1+'</tbody></table></div>';
      $("#property").html(htmlVal);
      }
  });
        
    
  });

  counter10++; 

    
}

$("#packages_itinerary_id_fk").change(function() {

        var itinerary_category_id = $(this).val();

        var num1 = 1; var num = 1;
        
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/itinerary_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{itinerary_category_id:itinerary_category_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                field.push('<tr><td style="display:none"><input checked="checked" type="checkbox" /></td><td>'+item.itineraries_days_day+' | '+item.itineraries_days_title+'<input type="hidden" name="itineraries_days_id_fk['+num+']" id="itineraries_days_id_fk_'+num+'" value="'+item.itineraries_days_day+'"/><input type="hidden" name="packages_itineraries_days_day['+num+']" id="packages_itineraries_days_day_'+num+'" value="'+item.itineraries_days_day+'"/><input type="hidden" name="packages_itineraries_days_title['+num+']" id="packages_itineraries_days_title_'+num+'" value="'+item.itineraries_days_title+'"/></td><td>'+item.state_name+'<input type="hidden" name="packages_itineraries_days_destination_id_fk['+num+']" id="packages_itineraries_days_destination_id_fk_'+num+'" value="'+item.itineraries_days_destination_id_fk+'"/></td><td style="width:500px;hieght:500px">'+item.itineraries_days_description+'<input type="hidden" name="packages_itineraries_days_description['+num+']" id="packages_itineraries_days_description_'+num+'" value="'+item.itineraries_days_description+'"/></td><td><select id="change_designation_id_'+num+'" class="form-control multi-select change_designation" required> <option value="">Please Select Designation</option> </select></td><td><select  id="change_itinerary_id_'+num+'" class="form-control multi-select" required> <option value="">Please Select itinerary</option> </select><select  id="change_itinerary_day_id_'+num+'" class="form-control multi-select" required> <option value="">Please Select Days</option> </select></td></tr>');
                
                $.ajax({
                  
                  type: "POST",
                  url: "<?php echo base_url()?>index.php/Packages/gettdestination_details/",
                  success: function(cities)
                  {
                    // $('.properties').append('<option value="">Please Select Properties</option>');

                    $.each(cities,function(id,city) {

                      var opt = $('<option />');
                      opt.val(id);
                      opt.text(city);

                      $('.change_designation').append(opt);
                      //$('.properties').append(opt);

                    });
                  }
                })

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#itinerary").html(field);

            var field1 = [];
            
            $.each(result, function (i, item) {                

                
                //field1.push('<tr><td>'+item.itineraries_days_day+'</td><td>'+item.state_name+'</td><td><div class="row" id="product-item_'+num1+'">&nbsp <input type="hidden" name="sub-counter-'+num1+'" id="sub-counter-'+num1+'" value="0" /> <div class="col-sm-4"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select properties" required> <option value="">Please Select Properties</option> </select> </div> <div class="col-sm-4 mt-2 mt-sm-0"> <select name="properties_id_fk['+num1+']" id="properties_id_fk_'+num1+'" class="form-control multi-select" required> <option value="">Please Select Rooms</option> </select> </div> <div class="col-sm-3 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" onClick="addMore9('+num1+');">+ Add new</button> </div> </div></td></tr>');

                 
                
                num1++;
                
            });

                // $("#counter_edit1").val(num);    
            console.log(field1); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            //$("#property").html(field1);
            }
        });

         $.ajax({
                  
                  type: "POST",
                  url: "<?php echo base_url()?>index.php/Packages/gettproperties_details/",
                  success: function(cities)
                  {
                    // $('.properties').append('<option value="">Please Select Properties</option>');

                    $.each(cities,function(id,city) {

                      var opt = $('<option />');
                      opt.val(id);
                      opt.text(city);

                      $('.properties').append(opt);
                      //$('.properties').append(opt);

                    });
                  }
                })

});

var counter9 = 1;

var n9 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit9 = $("#counter_edit9").val();



if(counter_edit9 >0){
    counter9 = counter_edit9-1;
}

function addMore9(num=0) {
  
 
var subcnt = eval($('#sub-counter-'+num).val()); subcnt++; $('#sub-counter-'+num).val(subcnt);
 console.log(subcnt);
    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<div class="col-sm-4"> <select name="properties_id_fk['+counter9+']" id="properties_id_fk_'+counter9+'" class="form-control multi-select properties" required> <option value="">Please Select Properties</option> </select> </div><div class="col-sm-4 mt-2 mt-sm-0"> <select name="properties_id_fk['+counter9+']" id="properties_id_fk_'+counter9+'" class="form-control multi-select" required> <option value="">Please Select Rooms</option> </select> </div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow9('+counter9+');"><b>X</b></button></div>';
      // <div class="col-sm-4 mt-2 mt-sm-0"> <button class="btn btn-primary add" type="button" id="submit" onClick="addMore9('+num1+');">+ Add new</button> </div>
    $("#product-item_"+num).append(htmlVal);
        
    
  });   
counter9++;  

}

$("#packages_inclusion_exclusion_common_id_fk").change(function() {

        var inclusion_exclusion_common_id = $(this).val();

        var num1 = 1; var num = 1;
        
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/inclusion_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{inclusion_exclusion_common_id:inclusion_exclusion_common_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                // field.push('<hr><div class="profile-details"><div class="profile-name px-3 pt-2"><input type="hidden" name="room_tariff_hike_rate_id['+num+']" id="room_tariff_hike_rate_id_'+num+'"><input type="hidden" name="room_id_fk['+num+']" id="room_id_fk_'+num+'" value="'+item.properties_room_category_id+'"><h4 class="text-primary mb-0">'+item.properties_room_category_name+'</h4><!--<p>UX / UI Designer</p></div><div class="profile-email px-2 pt-2"><h4 class="text-muted mb-0">hello@email.com</h4><p>Email</p>--></div></div><div class="row rates"><div class="col-md-2"><div class="form-group"><label class="col-lg-6 col-form-label" for="room_tariff_hike_rate_room_rate"><b>Room rate</b> <span class="text-danger">*</span></label><input type="number" class="form-control" name="room_tariff_hike_rate_room_rate['+num+']" id="room_tariff_hike_rate_room_rate_'+num+'" placeholder="Enter Room rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_adult_with_extra_bed"><b>Adult with Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_adult_with_extra_bed['+num+']" id="room_tariff_hike_rate_adult_with_extra_bed_'+num+'" placeholder="Adult with Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_child_with_extra_bed"><b>Child With Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_with_extra_bed['+num+']" id="room_tariff_hike_rate_child_with_extra_bed_'+num+'" placeholder="Child With Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div> <div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_child_sharing_bed"><b>Child Sharing Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_sharing_bed['+num+']" id="room_tariff_hike_rate_child_sharing_bed_'+num+'" placeholder="Child Sharing Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Single Occupancy Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_single_occupancy['+num+']" id="room_tariff_hike_rate_single_occupancy_'+num+'" placeholder="Single Occupancy Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Hike on some days of week</b></label><select name="room_tariff_hike_rate_some_days_type['+num+']" id="room_tariff_hike_rate_some_days_type_'+num+'" class="form-control multi-select item" required><option value="N">No</option><option value="Y">Yes</option></select><span class="help-block" style="color:red"></span></div></div><div class="row some_days" id="some_days_'+num+'"><div class="table-responsive"><table class="table table-responsive-md"><thead><tr><th style="width:50px;"><div class="form-check custom-checkbox checkbox-success check-lg me-3"><input type="checkbox" class="form-check-input checkAll" id="checkAll" name="checkAll_'+num+'"><label class="form-check-label" for="checkAll"></label></div></th><th><strong>Weekday</strong></th><th><strong>Hike Amount Room</strong></th><th><strong>Adult with Extra Bed</strong></th><th><strong>Child With Extra Bed</strong></th><th><strong>Child Sharing Bed</strong></th><th><strong>Single Occupancy</strong></th></tr></thead><tbody>'+ field1.join('') +'</tbody></table></div></div>');
                field.push('<form><div class="row inc"><div class="mb-3 col-md-6"><input type="hidden" name="inclusion_common_id_fk['+num+']" id="inclusion_common_id_fk_'+num+'" value="'+item.inclusion_exclusion_common_id_fk1+'"/><input type="hidden" name="inclusions_id_fk['+num+']" id="inclusions_id_fk_'+num+'" value="'+item.inclusions_id+'"/><textarea class="form-control" name="packages_inclusions_details['+num+']" id="packages_inclusions_details_'+num+'"  rows="5" required>'+item.inclusions_details+'</textarea><span class="help-block" style="color:red"></span></div></form></div>');
                

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#inclusion").html(field);
            }
        });

        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/exclusion_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{inclusion_exclusion_common_id:inclusion_exclusion_common_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                // field.push('<hr><div class="profile-details"><div class="profile-name px-3 pt-2"><input type="hidden" name="room_tariff_hike_rate_id['+num+']" id="room_tariff_hike_rate_id_'+num+'"><input type="hidden" name="room_id_fk['+num+']" id="room_id_fk_'+num+'" value="'+item.properties_room_category_id+'"><h4 class="text-primary mb-0">'+item.properties_room_category_name+'</h4><!--<p>UX / UI Designer</p></div><div class="profile-email px-2 pt-2"><h4 class="text-muted mb-0">hello@email.com</h4><p>Email</p>--></div></div><div class="row rates"><div class="col-md-2"><div class="form-group"><label class="col-lg-6 col-form-label" for="room_tariff_hike_rate_room_rate"><b>Room rate</b> <span class="text-danger">*</span></label><input type="number" class="form-control" name="room_tariff_hike_rate_room_rate['+num+']" id="room_tariff_hike_rate_room_rate_'+num+'" placeholder="Enter Room rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_adult_with_extra_bed"><b>Adult with Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_adult_with_extra_bed['+num+']" id="room_tariff_hike_rate_adult_with_extra_bed_'+num+'" placeholder="Adult with Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_child_with_extra_bed"><b>Child With Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_with_extra_bed['+num+']" id="room_tariff_hike_rate_child_with_extra_bed_'+num+'" placeholder="Child With Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div> <div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_child_sharing_bed"><b>Child Sharing Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_sharing_bed['+num+']" id="room_tariff_hike_rate_child_sharing_bed_'+num+'" placeholder="Child Sharing Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Single Occupancy Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_single_occupancy['+num+']" id="room_tariff_hike_rate_single_occupancy_'+num+'" placeholder="Single Occupancy Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Hike on some days of week</b></label><select name="room_tariff_hike_rate_some_days_type['+num+']" id="room_tariff_hike_rate_some_days_type_'+num+'" class="form-control multi-select item" required><option value="N">No</option><option value="Y">Yes</option></select><span class="help-block" style="color:red"></span></div></div><div class="row some_days" id="some_days_'+num+'"><div class="table-responsive"><table class="table table-responsive-md"><thead><tr><th style="width:50px;"><div class="form-check custom-checkbox checkbox-success check-lg me-3"><input type="checkbox" class="form-check-input checkAll" id="checkAll" name="checkAll_'+num+'"><label class="form-check-label" for="checkAll"></label></div></th><th><strong>Weekday</strong></th><th><strong>Hike Amount Room</strong></th><th><strong>Adult with Extra Bed</strong></th><th><strong>Child With Extra Bed</strong></th><th><strong>Child Sharing Bed</strong></th><th><strong>Single Occupancy</strong></th></tr></thead><tbody>'+ field1.join('') +'</tbody></table></div></div>');
                field.push('<form><div class="row exc"><div class="mb-3 col-md-6"><input type="hidden" name="exclusions_common_id_fk['+num1+']" id="exclusions_common_id_fk_'+num1+'" value="'+item.inclusion_exclusion_common_id_fk2+'"/><input type="hidden" name="exclusions_id_fk['+num1+']" id="exclusions_id_fk_'+num1+'" value="'+item.exclusions_id+'"/><textarea class="form-control" name="packages_exclusions_details['+num1+']" id="packages_exclusions_details_'+num1+'"  rows="5" required>'+item.exclusions_details+'</textarea><span class="help-block" style="color:red"></span></div></form></div>');
                

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#exclusion").html(field);
            }
        });

});

////***Inclusion Dynamic text box details saving into database*****////

////***Payment policies on Dynamic text box details saving into database*****////

$("#payment_policies_id_fk").change(function() {

        var payment_policies_id = $(this).val();

        var num1 = 1; var num = 1;
        
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/payment_policies_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{payment_policies_id:payment_policies_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                // field.push('<hr><div class="profile-details"><div class="profile-name px-3 pt-2"><input type="hidden" name="room_tariff_hike_rate_id['+num+']" id="room_tariff_hike_rate_id_'+num+'"><input type="hidden" name="room_id_fk['+num+']" id="room_id_fk_'+num+'" value="'+item.properties_room_category_id+'"><h4 class="text-primary mb-0">'+item.properties_room_category_name+'</h4><!--<p>UX / UI Designer</p></div><div class="profile-email px-2 pt-2"><h4 class="text-muted mb-0">hello@email.com</h4><p>Email</p>--></div></div><div class="row rates"><div class="col-md-2"><div class="form-group"><label class="col-lg-6 col-form-label" for="room_tariff_hike_rate_room_rate"><b>Room rate</b> <span class="text-danger">*</span></label><input type="number" class="form-control" name="room_tariff_hike_rate_room_rate['+num+']" id="room_tariff_hike_rate_room_rate_'+num+'" placeholder="Enter Room rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_adult_with_extra_bed"><b>Adult with Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_adult_with_extra_bed['+num+']" id="room_tariff_hike_rate_adult_with_extra_bed_'+num+'" placeholder="Adult with Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_child_with_extra_bed"><b>Child With Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_with_extra_bed['+num+']" id="room_tariff_hike_rate_child_with_extra_bed_'+num+'" placeholder="Child With Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div> <div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_child_sharing_bed"><b>Child Sharing Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_sharing_bed['+num+']" id="room_tariff_hike_rate_child_sharing_bed_'+num+'" placeholder="Child Sharing Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Single Occupancy Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_single_occupancy['+num+']" id="room_tariff_hike_rate_single_occupancy_'+num+'" placeholder="Single Occupancy Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Hike on some days of week</b></label><select name="room_tariff_hike_rate_some_days_type['+num+']" id="room_tariff_hike_rate_some_days_type_'+num+'" class="form-control multi-select item" required><option value="N">No</option><option value="Y">Yes</option></select><span class="help-block" style="color:red"></span></div></div><div class="row some_days" id="some_days_'+num+'"><div class="table-responsive"><table class="table table-responsive-md"><thead><tr><th style="width:50px;"><div class="form-check custom-checkbox checkbox-success check-lg me-3"><input type="checkbox" class="form-check-input checkAll" id="checkAll" name="checkAll_'+num+'"><label class="form-check-label" for="checkAll"></label></div></th><th><strong>Weekday</strong></th><th><strong>Hike Amount Room</strong></th><th><strong>Adult with Extra Bed</strong></th><th><strong>Child With Extra Bed</strong></th><th><strong>Child Sharing Bed</strong></th><th><strong>Single Occupancy</strong></th></tr></thead><tbody>'+ field1.join('') +'</tbody></table></div></div>');
                field.push('<form><div class="row"><div class="mb-3 col-md-6"><input type="hidden" name="payment_policies_items_id_fk['+num+']" id="payment_policies_items_id_fk_'+num+'" value="'+item.payment_policies_items_id+'"/><textarea class="form-control" name="packages_payment_policies_details['+num+']" id="packages_payment_policies_details_'+num+'"  rows="5" required>'+item.payment_policies_items_name+'</textarea><span class="help-block" style="color:red"></span></div></form></div>');
                

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#payment-policies").html(field);
            }
        });


});

////***Payment policies on Dynamic text box details saving into database*****////

////***Terms & Condition on Dynamic text box details saving into database*****////

$("#terms_condition_id_fk").change(function() {

        var terms_condition_id = $(this).val();

        var num1 = 1; var num = 1;
        
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/terms_condition_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{terms_condition_id:terms_condition_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                // field.push('<hr><div class="profile-details"><div class="profile-name px-3 pt-2"><input type="hidden" name="room_tariff_hike_rate_id['+num+']" id="room_tariff_hike_rate_id_'+num+'"><input type="hidden" name="room_id_fk['+num+']" id="room_id_fk_'+num+'" value="'+item.properties_room_category_id+'"><h4 class="text-primary mb-0">'+item.properties_room_category_name+'</h4><!--<p>UX / UI Designer</p></div><div class="profile-email px-2 pt-2"><h4 class="text-muted mb-0">hello@email.com</h4><p>Email</p>--></div></div><div class="row rates"><div class="col-md-2"><div class="form-group"><label class="col-lg-6 col-form-label" for="room_tariff_hike_rate_room_rate"><b>Room rate</b> <span class="text-danger">*</span></label><input type="number" class="form-control" name="room_tariff_hike_rate_room_rate['+num+']" id="room_tariff_hike_rate_room_rate_'+num+'" placeholder="Enter Room rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_adult_with_extra_bed"><b>Adult with Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_adult_with_extra_bed['+num+']" id="room_tariff_hike_rate_adult_with_extra_bed_'+num+'" placeholder="Adult with Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_child_with_extra_bed"><b>Child With Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_with_extra_bed['+num+']" id="room_tariff_hike_rate_child_with_extra_bed_'+num+'" placeholder="Child With Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div> <div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_child_sharing_bed"><b>Child Sharing Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_sharing_bed['+num+']" id="room_tariff_hike_rate_child_sharing_bed_'+num+'" placeholder="Child Sharing Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Single Occupancy Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_single_occupancy['+num+']" id="room_tariff_hike_rate_single_occupancy_'+num+'" placeholder="Single Occupancy Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Hike on some days of week</b></label><select name="room_tariff_hike_rate_some_days_type['+num+']" id="room_tariff_hike_rate_some_days_type_'+num+'" class="form-control multi-select item" required><option value="N">No</option><option value="Y">Yes</option></select><span class="help-block" style="color:red"></span></div></div><div class="row some_days" id="some_days_'+num+'"><div class="table-responsive"><table class="table table-responsive-md"><thead><tr><th style="width:50px;"><div class="form-check custom-checkbox checkbox-success check-lg me-3"><input type="checkbox" class="form-check-input checkAll" id="checkAll" name="checkAll_'+num+'"><label class="form-check-label" for="checkAll"></label></div></th><th><strong>Weekday</strong></th><th><strong>Hike Amount Room</strong></th><th><strong>Adult with Extra Bed</strong></th><th><strong>Child With Extra Bed</strong></th><th><strong>Child Sharing Bed</strong></th><th><strong>Single Occupancy</strong></th></tr></thead><tbody>'+ field1.join('') +'</tbody></table></div></div>');
                field.push('<form><div class="row"><div class="mb-3 col-md-6"><input type="hidden" name="terms_condition_item_id_fk['+num+']" id="terms_condition_item_id_fk_'+num+'" value="'+item.terms_condition_items_id+'"/><textarea class="form-control" name="packages_terms_condition_details['+num+']" id="packages_terms_condition_details_'+num+'"  rows="5" required>'+item.terms_condition_items_name+'</textarea><span class="help-block" style="color:red"></span></div></form></div>');
                

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#terms-conditions").html(field);
            }
        });


});

////***Terms & Condition on Dynamic text box details saving into database*****////

////***Cancellation policy on Dynamic text box details saving into database*****////

$("#cancellation_policies_id_fk").change(function() {

        var cancellation_policies_id = $(this).val();

        var num1 = 1; var num = 1;
        
        $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/cancellation_policies_array_list/",
            dataType: 'json',
            type: 'POST',
            data:{cancellation_policies_id:cancellation_policies_id},
            success: function(data) {    
                var result = data;
            // console.log(result);
            var field = [];
            
            $.each(result, function (i, item) {                

                // field.push('<hr><div class="profile-details"><div class="profile-name px-3 pt-2"><input type="hidden" name="room_tariff_hike_rate_id['+num+']" id="room_tariff_hike_rate_id_'+num+'"><input type="hidden" name="room_id_fk['+num+']" id="room_id_fk_'+num+'" value="'+item.properties_room_category_id+'"><h4 class="text-primary mb-0">'+item.properties_room_category_name+'</h4><!--<p>UX / UI Designer</p></div><div class="profile-email px-2 pt-2"><h4 class="text-muted mb-0">hello@email.com</h4><p>Email</p>--></div></div><div class="row rates"><div class="col-md-2"><div class="form-group"><label class="col-lg-6 col-form-label" for="room_tariff_hike_rate_room_rate"><b>Room rate</b> <span class="text-danger">*</span></label><input type="number" class="form-control" name="room_tariff_hike_rate_room_rate['+num+']" id="room_tariff_hike_rate_room_rate_'+num+'" placeholder="Enter Room rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_adult_with_extra_bed"><b>Adult with Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_adult_with_extra_bed['+num+']" id="room_tariff_hike_rate_adult_with_extra_bed_'+num+'" placeholder="Adult with Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_child_with_extra_bed"><b>Child With Extra Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_with_extra_bed['+num+']" id="room_tariff_hike_rate_child_with_extra_bed_'+num+'" placeholder="Child With Extra Bed Rate" required><span class="help-block" style="color:red"></span></div></div> <div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_child_sharing_bed"><b>Child Sharing Bed Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_child_sharing_bed['+num+']" id="room_tariff_hike_rate_child_sharing_bed_'+num+'" placeholder="Child Sharing Bed Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-10 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Single Occupancy Rate</b></label><input type="number" class="form-control" name="room_tariff_hike_rate_single_occupancy['+num+']" id="room_tariff_hike_rate_single_occupancy_'+num+'" placeholder="Single Occupancy Rate" required><span class="help-block" style="color:red"></span></div></div><div class="col-md-2"><div class="form-group"><label class="col-lg-12 col-form-label" for="room_tariff_hike_rate_single_occupancy"><b>Hike on some days of week</b></label><select name="room_tariff_hike_rate_some_days_type['+num+']" id="room_tariff_hike_rate_some_days_type_'+num+'" class="form-control multi-select item" required><option value="N">No</option><option value="Y">Yes</option></select><span class="help-block" style="color:red"></span></div></div><div class="row some_days" id="some_days_'+num+'"><div class="table-responsive"><table class="table table-responsive-md"><thead><tr><th style="width:50px;"><div class="form-check custom-checkbox checkbox-success check-lg me-3"><input type="checkbox" class="form-check-input checkAll" id="checkAll" name="checkAll_'+num+'"><label class="form-check-label" for="checkAll"></label></div></th><th><strong>Weekday</strong></th><th><strong>Hike Amount Room</strong></th><th><strong>Adult with Extra Bed</strong></th><th><strong>Child With Extra Bed</strong></th><th><strong>Child Sharing Bed</strong></th><th><strong>Single Occupancy</strong></th></tr></thead><tbody>'+ field1.join('') +'</tbody></table></div></div>');
                field.push('<form><div class="row"><div class="mb-3 col-md-6"><input type="hidden" name="cancellation_policies_item_id_fk['+counter7+']" id="cancellation_policies_item_id_fk_'+counter7+'" value="'+item.cancellation_policies_item_id+'"/><textarea class="form-control" name="packages_cancellation_policies_details['+num+']" id="packages_cancellation_policies_details_'+num+'"  rows="5" required>'+item.cancellation_policies_item_name+'</textarea><span class="help-block" style="color:red"></span></div></form></div>');
                

                num++;
                
            });

            
                // $("#counter_edit1").val(num);    
            console.log(field); 
            //$("#stg").html(field);
            //$("#row1").append(field);
            $("#cancellation-policy").html(field);
            }
        });


});

////***Cancellation policy on Dynamic text box details saving into database*****////

////***Inclusion Dynamic text box details saving into database*****////

var counter1 = 1;

var n1 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit1 = $("#counter_edit1").val();



if(counter_edit1 >0){
    counter1 = counter_edit1-1;
}

function addMore1() {
 var n1 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row" id="product-item1_'+counter1+'"><div class="mb-3 col-md-6"  ><input type="hidden" name="inclusion_common_id_fk['+counter1+']" id="inclusion_common_id_fk_'+counter1+'"/><input type="hidden" name="inclusions_id_fk['+counter1+']" id="inclusions_id_fk_'+counter1+'" /><textarea class="form-control" name="packages_inclusions_details['+counter1+']" id="packages_inclusions_details_'+counter1+'"  rows="5" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow1('+counter1+');"><b>X</b></button></div></div></form>';
    $("#inclusion").append(htmlVal);   
        
    
  });   
counter1++;  

}
////***Inclusion Dynamic text box details saving into database*****////

////***Inclusion Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow1(counter1) {

    console.log(counter1,"counter");
    $("#product-item1_"+counter1).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}

////***Inclusion Delete dynamic table rows*****///

////***Exclusion Dynamic text box details saving into database*****////

var counter2 = 1;

var n2 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit2 = $("#counter_edit1").val();



if(counter_edit2 >0){
    counter2 = counter_edit2-1;
}

function addMore2() {
 var n1 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row" id="product-item1_'+counter2+'"><div class="mb-3 col-md-6"  ><input type="hidden" name="exclusions_common_id_fk['+counter2+']" id="exclusions_common_id_fk_'+counter2+'" /><input type="hidden" name="exclusions_id_fk['+counter2+']" id="exclusions_id_fk_'+counter2+'" /><textarea class="form-control" name="packages_exclusions_details['+counter2+']" id="packages_exclusions_details_'+counter2+'"  rows="5" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow2('+counter2+');"><b>X</b></button></div></div></form>';
    $("#exclusion").append(htmlVal);   
        
    
  });   
counter2++;  

}
////***Exclusion Dynamic text box details saving into database*****////

////***Exclusion Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow2(counter2) {

    console.log(counter2,"counter");
    $("#product-item1_"+counter2).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}

////***Exclusion Delete dynamic table rows*****///

////***Optional add-on Dynamic text box details saving into database*****////

var counter3 = 1;

var n3 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit3 = $("#counter_edit1").val();



if(counter_edit3 >0){
    counter3 = counter_edit3-1;
}

function addMore3() {
 var n1 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row" id="product-item1_'+counter3+'"><div class="mb-3 col-md-6"><textarea class="form-control" name="packages_optional_add_on_details['+counter3+']" id="packages_optional_add_on_details_'+counter3+'"  rows="5" placeholder="Enter Optional add on" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow3('+counter3+');"><b>X</b></button></div></div></form>';
    $("#optional-addon").append(htmlVal);   
        
    
  });   
counter3++;  

}
////***Optional add-on Dynamic text box details saving into database*****////

////***Optional add-on Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow3(counter3) {

    console.log(counter3,"counter");
    $("#product-item1_"+counter3).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Optional add-on Delete dynamic table rows*****///

////***Special requirments Dynamic text box details saving into database*****////

var counter4 = 1;

var n4 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit4 = $("#counter_edit1").val();



if(counter_edit4 >0){
    counter4 = counter_edit4-1;
}

function addMore4() {
 var n1 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row" id="product-item1_'+counter4+'"><div class="mb-3 col-md-3"><select name="special_requirements_id_fk['+counter4+']" id="special_requirements_id_fk_'+counter4+'" class="form-control special" required></select><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><input type="text" class="form-control" name="packages_special_requirements_cost['+counter4+']" id="packages_special_requirements_cost_'+counter4+'" placeholder="Enter amount" required></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow4('+counter4+');"><b>X</b></button></div></div></form>';
    $("#special-requirments").append(htmlVal);   
        
    $('#special_requirements_id_fk_'+counter4+'').select2();

    $.ajax({
			
			type: "POST",
			url: "<?php echo base_url()?>index.php/Packages/gettspecialrequirment_details/",
			success: function(cities)
			{
				$('#special_requirements_id_fk_'+counter4+'').append('<option value="">Please Select Special requirment</option>');

				$.each(cities,function(id,city) {

				  var opt = $('<option />');
				  opt.val(id);
				  opt.text(city);

				  $('#special_requirements_id_fk_'+counter4+'').append(opt);
				  $('#special_requirements_id_fk'+counter4+'').append(opt);

				});
			}
		})
        
        $(document).on("change",'#special_requirements_id_fk_'+counter4+'',function(){
    //var type = $(this).val();
    //var counterId = $(this).attr("id");
    // var counter = counterId.substr(counterId.length - 1);
    //var counter = counterId.split("_").pop(-1);
    // console.log(counter,"counter");

    special_requirements_packages_id = $('#special_requirements_id_fk_'+counter4+'').val();

     $.ajax({
            url: "<?php echo base_url(); ?>index.php/Packages/Specialrequirmentamount/"+special_requirements_packages_id,
            dataType: 'json',
            type: 'POST',
            success:
            function(data) {
                amount = data['amount'];
                if(amount>0)
                {
                    var amount = data['amount'];
                }
                else{
                    var amount = 0;
                }
                
                    $('#packages_special_requirements_cost_'+counter4+'').val(amount);
                    }
                
            
        });

});
       
    
  });   
counter4++;  

}
 

////***Special requirments Dynamic text box details saving into database*****////

////***Special requirments Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow4(counter4) {

    console.log(counter4,"counter");
    $("#product-item1_"+counter4).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Special requirments Delete dynamic table rows*****///

////***Payment policies Dynamic text box details saving into database*****////

var counter5 = 1;

var n5 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit5 = $("#counter_edit1").val();



if(counter_edit5 >0){
    counter5 = counter_edit5-1;
}

function addMore5() {
 var n5 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row payment" id="product-item1_'+counter5+'"><div class="mb-3 col-md-6"  ><input type="hidden" name="payment_policies_items_id_fk['+counter5+']" id="payment_policies_items_id_fk_'+counter5+'"/><textarea class="form-control" name="packages_payment_policies_details['+counter5+']" id="packages_payment_policies_details_'+counter5+'"  rows="5" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow5('+counter5+');"><b>X</b></button></div></div></form>';
    $("#payment-policies").append(htmlVal);   
        
    
  });   
counter5++;  

}
////***Payment policies Dynamic text box details saving into database*****////

////***Payment policies Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow5(counter5) {

    console.log(counter5,"counter");
    $("#product-item1_"+counter5).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Payment policies Delete dynamic table rows*****///

////***Terms & conditions Dynamic text box details saving into database*****////

var counter6 = 1;

var n6 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit6 = $("#counter_edit1").val();



if(counter_edit6 >0){
    counter6 = counter_edit6-1;
}

function addMore6() {
 var n6 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row payment" id="product-item1_'+counter6+'"><div class="mb-3 col-md-6"  ><input type="hidden" name="terms_condition_item_id_fk['+counter6+']" id="terms_condition_item_id_fk_'+counter6+'" /><textarea class="form-control" name="packages_terms_condition_details['+counter6+']" id="packages_terms_condition_details_'+counter6+'"  rows="5" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow6('+counter6+');"><b>X</b></button></div></div></form>';
    $("#terms-conditions").append(htmlVal);   
        
    
  });   
counter6++;  

}
////***Terms & conditions Dynamic text box details saving into database*****////

////***Terms & conditions Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow6(counter6) {

    console.log(counter6,"counter");
    $("#product-item1_"+counter6).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Terms & conditions Delete dynamic table rows*****///

////***Cancellation policy Dynamic text box details saving into database*****////

var counter7 = 1;

var n6 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit7 = $("#counter_edit1").val();



if(counter_edit7 >0){
    counter7 = counter_edit7-1;
}

function addMore7() {
 var n7 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row payment" id="product-item1_'+counter7+'"><div class="mb-3 col-md-6"  ><input type="hidden" name="cancellation_policies_item_id_fk['+counter7+']" id="cancellation_policies_item_id_fk_'+counter7+'" /><textarea class="form-control" name="packages_terms_condition_details['+counter7+']" id="packages_terms_condition_details_'+counter7+'"  rows="5" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow7('+counter7+');"><b>X</b></button></div></div></form>';
    $("#cancellation-policy").append(htmlVal);   
        
    
  });   
counter7++;  

}
////***Cancellation policy Dynamic text box details saving into database*****////

////***Cancellation policy Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow7(counter7) {

    console.log(counter7,"counter");
    $("#product-item1_"+counter7).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Cancellation policy Delete dynamic table rows*****///

////***Notes Dynamic text box details saving into database*****////

var counter8 = 1;

var n8 = $("#counter_edit1").val();
                 // alert(n1);

var counter_edit8 = $("#counter_edit1").val();



if(counter_edit8 >0){
    counter8 = counter_edit8-1;
}

function addMore8() {
 var n8 = $("#counter_edit").val();

    $("<DIV>").load("", function() {
    
    $(this).attr('data-validation','required');
    $(this).attr('data-validation','nameFields');
    $(this).attr('data-validation','digitsOnly');
    $(this).attr('data-validation','date');
    $(this).attr('data-validation','usPhone');
    $(this).attr('data-validation','email');
    $(this).attr('data-validation','dropDown');


    // var htmlVal = '<DIV class="product-item box box-success list exp_section" id="product-item_'+counter+'">&nbsp <input type="hidden" name="sub-counter-'+counter+'" id="sub-counter-'+counter+'" value="0" /> <table class="table table-bordered" cellspacing="2" ><tr><div class="row"><div class="col-sm-12"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/> <textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter details" required></textarea><button class="btn-sm btn-danger" type="button" style="margin-top:20%;" onClick="deleteRow('+counter+');"><b>X</b></button></div></div></div></tr></table></DIV>';

    //  var htmlVal = '<div class="mb-3 col-md-8 product-item" id="product-item_'+counter+'"><input type="hidden" name="terms_condition_id_fk['+counter+']" id="terms_condition_id_fk_'+counter+'"/><textarea class="form-control" name="terms_condition_items_name['+counter+']" id="terms_condition_items_name_'+counter+'"  rows="5" placeholder="Enter Terms and condition" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3 product-item1" id="product-item1_'+counter+'"><button class="btn-sm btn-danger" type="button" onClick="deleteRow('+counter+');"><b>X</b></button></div>';
     var htmlVal = '<form><div class="row" id="product-item1_'+counter8+'"><div class="mb-3 col-md-6"><textarea class="form-control" name="packages_notes_details['+counter8+']" id="packages_notes_details_'+counter8+'"  rows="5" placeholder="Enter Notes" required></textarea><span class="help-block" style="color:red"></span></div><div class="mb-3 col-md-3"><button class="btn-sm btn-danger" type="button" onClick="deleteRow8('+counter8+');"><b>X</b></button></div></div></form>';
    $("#add_notes").append(htmlVal);   
    
  });   
counter8++;  

}
////***Notes Dynamic text box details saving into database*****////

////***Notes Delete dynamic table rows*****///
var removed_item_ids = [];
function deleteRow8(counter8) {

    console.log(counter8,"counter");
    $("#product-item1_"+counter8).remove();
    var a = $("#countervalue").val();
    $("#countervalue").val(a-1);

   

}
////***Notes Delete dynamic table rows*****///

////***For close the modal *****///
function Quotationmodalclose()
{

    $('#QuotationModal').modal('hide');
   
    //$( "div" ).remove( ".modal-backdrop" );
    $('#staff_id_fk1').val('');
    $('#guest_name1').val('');
    $('#source_id_fk').val('').change();
    // $('#vehicle_id_fk').val('0').change();
    $('#category_name_alert').hide();
    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.staff_id_fk1').removeClass('input-success-o');
    $('.staff_id_fk1').removeClass('input-warning-o');
    $('.guest_name1').removeClass('input-success-o');
    $('.guest_name1').removeClass('input-warning-o');
    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#QuotationModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    // $('#transporter_name').focus();
    var id = $("#id").val();
    $('#category_name_alert').hide();
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_id_fk').removeClass('input-success-o');
    $('.properties_id_fk').removeClass('input-warning-o');
    $('.room_tariff_hike_from_date').removeClass('input-success-o');
    $('.room_tariff_hike_from_date').removeClass('input-warning-o');
})
////***For open the modal *****///
    
////***For open modal of quotation adding form  *****///
    
function add_quotation()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#QuotationModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Quotation Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
    
}

////***For open modal of quotation adding form  *****///

////***For editing quotation details from adding modal form  *****///

function edit_leads(id)
{
    var num_2 = 1;
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?>index.php/Quotation/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
         // .trigger('change.select2')
            
            $('[name="id"]').val(data.leads_id);
            $('[name="lead_type"]').val(data.lead_type);
            $('[name="staff_id_fk"]').val(data.staff_id_fk);
            $('[name="source_id_fk"]').val(data.source_id_fk);
            $('[name="guest_name"]').val(data.guest_name);
            $('[name="agent_id_fk"]').val(data.agent_id_fk);  
            $('[name="total_package_cost"]').val(data.total_package_cost); 
            $('[name="expense"]').val(data.expense);
            $('[name="country_id_fk"]').val(data.country_id_fk);
            $('[name="priority_status_id_fk"]').val(data.priority_status_id_fk);
            $('[name="stage_id_fk"]').val(data.stage_id_fk);
            $('[name="agent_id_fk"]').val(data.agent_id_fk);
            $('[name="lead_type"]').val(data.lead_type);
            $('[name="guest_name"]').val(data.guest_name);
            $('[name="date_type"]').val(data.date_type);
            $('[name="start_date"]').val(data.start_date);
            $('[name="end_date"]').val(data.end_date);
            $('[name="duration"]').val(data.duration);
            $('[name="whats_number"]').val(data.whats_number);
            $('[name="alternative_number"]').val(data.alternative_number);
            $('[name="total_package_cost"]').val(data.total_package_cost);
            $('[name="expense"]').val(data.expense);
            $('[name="margin"]').val(data.margin);
            $('[name="description"]').val(data.description);
                 
            $('#QuotationModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit leads Details'); // Set title to Bootstrap modal title
            $('#btnSave').text('update');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

////***For editing quotation details from adding modal form  *****///

////***For reload the datatable  *****///

function reload_table()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        swal("Quotation details updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room tariff details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Quotation details added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Transporter details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

function reload_table_status()
{
    $table.ajax.reload(null,false); //reload datatable ajax 

        swal("Quotation status updated successfully", "", "success")
       
    
    
}

////***For reload the datatable  *****///

///***For save the quotation details from adding modal form *****///



/////******** Jquery validation when save******/////////////

function showError(msg, el) {
    alert(msg);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('is-invalid');
        setTimeout(() => el.classList.remove('is-invalid'), 2000);
    }
}

function num(v) {
    const n = parseFloat(v);
    return isNaN(n) ? 0 : n;
}

function validateQuotationForm() {

    /* ================= 1. MAIN REQUIRED FIELDS ================= */
    if (!$('#quotation_date').val())
        return showError('Quotation date is required', $('#quotation_date')[0]), false;

    if (!$('#arriving_destination').val())
        return showError('Arriving destination is required', $('#arriving_destination')[0]), false;

    if (!$('#departuring_destination').val())
        return showError('Departuring destination is required', $('#departuring_destination')[0]), false;

    if (!$('#leads_id').val())
        return showError('Please select Lead', $('#leads_id')[0]), false;

    if (!$('#packages_id_fk').val())
        return showError('Please select Package', $('#packages_id_fk')[0]), false;


    /* ================= 2A. AT LEAST ONE OPTION BLOCK ================= */
    const optionBlocks = document.querySelectorAll('.optionBlock');
    if (!optionBlocks || optionBlocks.length === 0) {
        showError('Please add at least one Package Option', document.getElementById('packages_id_fk'));
        return false;
    }

    // If option blocks exist but none selected
    let anySelected = false;
    optionBlocks.forEach(ob => {
        const sel = ob.querySelector('.propertyDropdown');
        if (sel && sel.value) anySelected = true;
    });

    if (!anySelected) {
        const firstSelect = optionBlocks[0]?.querySelector('.propertyDropdown');
        showError('Please select at least one Package Option from dropdown', firstSelect || document.getElementById('packages_id_fk'));
        return false;
    }

    /* ================= OPTION BLOCKS ================= */
    let valid = true;

    document.querySelectorAll('.optionBlock').forEach(optionBlock => {

        if (!valid) return;

        /* 2. Option dropdown + title + cab amount */
        const optionSel = optionBlock.querySelector('.propertyDropdown');
        const titleEl   = optionBlock.querySelector('[name="quotation_options_title[]"]');
        const cabEl     = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');

        if (!optionSel?.value)
            return valid = false, showError('Select Package Option', optionSel);

        if (!titleEl?.value.trim())
            return valid = false, showError('Option title is required', titleEl);

        if (num(cabEl?.value) <= 0)
            return valid = false, showError('Cab amount is required', cabEl);

        /* 3. Room calculated rate must not be 0 */
        optionBlock.querySelectorAll('.autoCalcRateInput').forEach(inp => {
            if (!valid) return;
            if (num(inp.value) <= 0)
                return valid = false, showError('Room calculated rate cannot be 0.00', inp);
        });

        /* ================= DAYS / PROPERTIES / ROOMS ================= */
        optionBlock.querySelectorAll('.itineraryDayRow').forEach(dayRow => {

            if (!valid) return;

            dayRow.querySelectorAll('.propertyBlock').forEach(propertyBlock => {

                if (!valid) return;

                /* 4. Property selected */
                if (!propertyBlock.dataset.propertyId)
                    return valid = false, showError('Property not selected', propertyBlock);

                const roomRows = propertyBlock.querySelectorAll('tbody tr[data-room-id]');

                /* 6. Property opened but no rooms */
                if (roomRows.length === 0)
                    return valid = false, showError('Please add at least one room', propertyBlock);

                roomRows.forEach(roomRow => {

                    if (!valid) return;

                    /* 5. Room selected */
                    if (!roomRow.dataset.roomId)
                        return valid = false, showError('Room not selected', roomRow);
                });
            });
        });

        /* 7. Margin validation */
        const marginType  = optionBlock.querySelector('.optionMarginType');
        const marginValue = optionBlock.querySelector('.optionMarginValue');

        if (!marginType?.value || num(marginValue?.value) <= 0)
            return valid = false, showError('Margin amount/percentage is required', marginValue);
    });

    if (!valid) return false;

    /* ================= 8. PROPERTY INCLUSIONS ================= */
    document.querySelectorAll('#inclusionTable tbody tr').forEach(tr => {
        if (!valid) return;

        const daySel = tr.querySelector('.inclusionDaySelect');
        const nameEl = tr.querySelector('[name="inclusion_name[]"]');
        const amtEl  = tr.querySelector('[name="inclusion_amount[]"]');

        // row filled partially
        if (
            daySel?.value ||
            nameEl?.value.trim() ||
            num(amtEl?.value) > 0
        ) {
            if (!daySel?.value)
                return valid = false, showError('Select Day | Destination for Inclusion', daySel);

            if (!nameEl?.value.trim())
                return valid = false, showError('Inclusion name required', nameEl);

            if (num(amtEl?.value) <= 0)
                return valid = false, showError('Inclusion amount required', amtEl);
        }
    });

    if (!valid) return false;

    /* ================= 9. SPECIAL REQUIREMENTS ================= */
    document.querySelectorAll('#specialReqTable tbody tr').forEach(tr => {
        if (!valid) return;

        const daySel = tr.querySelector('.specialReqDaySelect');
        const reqSel = tr.querySelector('.specialReqSelect');
        const amtEl  = tr.querySelector('.specialReqCost');

        if (
            daySel?.value ||
            reqSel?.value ||
            num(amtEl?.value) > 0
        ) {
            if (!daySel?.value)
                return valid = false, showError('Select Day | Destination for Requirement', daySel);

            if (!reqSel?.value)
                return valid = false, showError('Select Special Requirement', reqSel);

            if (num(amtEl?.value) <= 0)
                return valid = false, showError('Requirement amount required', amtEl);
        }
    });

    return valid;
}

// function save() {

//     let url = save_method === 'add'
//         ? "<?php echo base_url();?>index.php/Quotation/ajax_add/"
//         : "<?php echo base_url();?>index.php/Quotation/ajax_update/";

//     $('#btnSave').text('saving...').attr('disabled', true);
// recalcAllOptionsBeforeSave();
// // send payload...

//     // const form = document.getElementById('form');
//     // const data = new FormData(form);

//     // ✅ ADD JSON PAYLOAD
//     // const payload = buildQuotationPayload();
//     // data.append('data', JSON.stringify(payload));
// var data = new FormData(form);
// data.append('data', JSON.stringify(buildQuotationPayload()));

//     $.ajax({
//         url: url,
//         type: "POST",
//         data: data,
//         dataType: "JSON",
//         processData: false,
//         contentType: false,
//         success: function (res) {

//             if (res.status) {
//                 $('#QuotationModal').modal('hide');
//                 reload_table();
//             } else {
//                 alert('Validation failed');
//             }

//             $('#btnSave').text('save').attr('disabled', false);
//         },
//         error: function () {
//             alert('Error saving data');
//             $('#btnSave').text('save').attr('disabled', false);
//         }
//     });
// }

function save() {

    // ✅ VALIDATE FIRST
    if (!validateQuotationForm()) {
        return;
    }

    let url = save_method === 'add'
        ? "<?php echo base_url();?>index.php/Quotation/ajax_add/"
        : "<?php echo base_url();?>index.php/Quotation/ajax_update/";

    $('#btnSave').text('saving...').attr('disabled', true);

    // ensure latest totals
    recalcAllOptionsBeforeSave();

    const form = document.getElementById('form');
    const data = new FormData(form);

    // JSON payload
    data.append('data', JSON.stringify(buildQuotationPayload()));

    $.ajax({
        url: url,
        type: "POST",
        data: data,
        dataType: "JSON",
        processData: false,
        contentType: false,
        success: function (res) {

            if (res.status) {
                $('#QuotationModal').modal('hide');
                reload_table();
            } else {
                alert('Validation failed on server');
            }

            $('#btnSave').text('save').attr('disabled', false);
        },
        error: function () {
            alert('Error saving data');
            $('#btnSave').text('save').attr('disabled', false);
        }
    });
}


///***For save the quotation details from adding modal form *****///

$(document).ready(function () {

  function resetInclusionBox() {
    // Keep only first row
    const $tbody = $('#inclusionTable tbody');
    $tbody.find('tr:gt(0)').remove();

    // Clear first row inputs/select
    $tbody.find('tr:eq(0) input').val('');
    $tbody.find('tr:eq(0) select').val('').trigger('change');

    // Disable first row remove btn
    $tbody.find('tr:eq(0) .removeInclusionBtn').prop('disabled', true);
  }

  function resetSpecialReqBox() {
    const $tbody = $('#specialReqTable tbody');
    $tbody.find('tr:gt(0)').remove();

    $tbody.find('tr:eq(0) input').val('');
    $tbody.find('tr:eq(0) select').val('').trigger('change');

    $tbody.find('tr:eq(0) .removeSpecialReqBtn').prop('disabled', true);
  }

  function toggleBox($checkbox, $box, resetFn) {
    if ($checkbox.is(':checked')) {
      $box.slideDown(150);

      // ✅ fill dropdowns if your data already loaded
      loadInclusionAndRequirementDropdownData();

      // ✅ re-init select2 inside newly shown box (important)
      setTimeout(function(){
        $box.find('select').each(function(){
          initSelect2(this, $(this).hasClass('specialReqSelect') ? 'Select Requirement' : 'Select Day | Date | Destination');
        });
      }, 50);

    } else {
      $box.slideUp(150, function(){
        resetFn();
      });
    }
  }

  // default state (hide both)
  $('#inclusionBox').hide();
  $('#specialReqBox').hide();

  // on load (if checked due to edit)
  toggleBox($('#quotation_property_inclusion_type'), $('#inclusionBox'), resetInclusionBox);
  toggleBox($('#quotation_special_requirement_type'), $('#specialReqBox'), resetSpecialReqBox);

  // change handlers
  $('#quotation_property_inclusion_type').on('change', function () {
    toggleBox($(this), $('#inclusionBox'), resetInclusionBox);
  });

  $('#quotation_special_requirement_type').on('change', function () {
    toggleBox($(this), $('#specialReqBox'), resetSpecialReqBox);
  });

});


/* ================= SPECIAL REQUIREMENTS ================= */



let __dayOptions = [];          // from accommodation_plan
let __specialReqOptions = [];   // from special_requirements

function formatDate(d) {
  // d is YYYY-MM-DD
  if (!d) return '';
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

/**
 * dayKey format we store in <option value="">:
 * property_day_id_fk|stay_destination_id_fk|accommodation_date
 */
function makeDayKey(row) {
  return `${row.property_day_id_fk}|${row.stay_destination_id_fk}|${row.accommodation_date}`;
}

function buildDayOptionLabel(row) {
  return `Day ${row.packages_properties_days_day || ''} | ${formatDate(row.accommodation_date)} | ${row.district_name || ''}`;
}

function initSelect2(el, placeholder = 'Select') {
    if (!el) return;

    // destroy if already initialized
    if ($(el).hasClass('select2-hidden-accessible')) {
        $(el).select2('destroy');
    }

    // If this select is inside a Bootstrap modal, attach dropdown to modal
    const $modalParent = $(el).closest('.modal');
    const opts = {
        width: '100%',
        placeholder,
        allowClear: true,
        minimumResultsForSearch: 0 // ✅ ALWAYS show search box
    };

    if ($modalParent.length) {
        opts.dropdownParent = $modalParent; // ✅ IMPORTANT for focus + search typing
    }

    $(el).select2(opts);
}

function applySpecialReqCostFromSelect(sel) {
  if (!sel) return;

  const row = sel.closest('tr');
  if (!row) return;

  const costInput = row.querySelector('.specialReqCost');
  if (!costInput) return;

  const opt = sel.options[sel.selectedIndex];
  const cost = opt ? (opt.getAttribute('data-cost') || '0') : '0';

  costInput.value = cost;
}

/* ✅ Works with Select2 */
$(document).on('select2:select', '.specialReqSelect', function () {
  applySpecialReqCostFromSelect(this);
});

$(document).on('select2:clear', '.specialReqSelect', function () {
  const row = this.closest('tr');
  const costInput = row ? row.querySelector('.specialReqCost') : null;
  if (costInput) costInput.value = '';
});

/* ✅ Fallback if Select2 not active */
document.addEventListener('change', function (e) {
  const sel = e.target.closest('.specialReqSelect');
  if (!sel) return;
  applySpecialReqCostFromSelect(sel);
});


function fillDaySelect(selectEl) {
    if (!selectEl) return;

    let html = `<option value="">Select Day | Date | Destination</option>`;
    __dayOptions.forEach(r => {
        const key = makeDayKey(r);
        html += `<option value="${key}">${buildDayOptionLabel(r)}</option>`;
    });

    selectEl.innerHTML = html;

    // ✅ Select2 init
    initSelect2(selectEl, 'Select Day | Date | Destination');
}


function fillSpecialReqSelect(selectEl) {
    if (!selectEl) return;

    let html = `<option value="">Select Requirement</option>`;
    __specialReqOptions.forEach(r => {
        html += `
            <option value="${r.special_requirements_id}"
                    data-cost="${r.special_requirements_cost || 0}">
                ${r.special_requirements_name}
            </option>`;
    });

    selectEl.innerHTML = html;

    // ✅ Select2 init
    initSelect2(selectEl, 'Select Requirement');

    // if something already selected, apply its cost
applySpecialReqCostFromSelect(selectEl);

}


/* ================= LOAD DROPDOWNS (call on package/lead change) ================= */

function loadInclusionAndRequirementDropdownData() {
  const leadId = document.getElementById('leads_id')?.value || '';
  const packageId = document.getElementById('packages_id_fk')?.value || '';

  // Fill existing rows
document.querySelectorAll('.inclusionDaySelect').forEach(el => {
    fillDaySelect(el);
});

document.querySelectorAll('.specialReqDaySelect').forEach(el => {
    fillDaySelect(el);
});

document.querySelectorAll('.specialReqSelect').forEach(el => {
    fillSpecialReqSelect(el);
});


  if (!leadId || !packageId) return;

  const urlDays =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_accommodation_day_options` +
    `?lead_id=${encodeURIComponent(leadId)}&package_id=${encodeURIComponent(packageId)}`;

  const urlReq =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_special_requirements`;

  Promise.all([
    fetch(urlDays).then(r => r.json()),
    fetch(urlReq).then(r => r.json())
  ])
  .then(([daysRes, reqRes]) => {
    __dayOptions = (daysRes && daysRes.status && Array.isArray(daysRes.data)) ? daysRes.data : [];
    __specialReqOptions = (reqRes && reqRes.status && Array.isArray(reqRes.data)) ? reqRes.data : [];

    // Fill existing rows selects
    document.querySelectorAll('.inclusionDaySelect').forEach(fillDaySelect);
    document.querySelectorAll('.specialReqDaySelect').forEach(fillDaySelect);
    document.querySelectorAll('.specialReqSelect').forEach(fillSpecialReqSelect);
  })
  .catch(err => console.error(err));

  recalcAllInclusionSpecialTotals();

}

// Call it when lead/package changes:
document.getElementById('packages_id_fk')?.addEventListener('change', loadInclusionAndRequirementDropdownData);
document.getElementById('leads_id')?.addEventListener('change', loadInclusionAndRequirementDropdownData);

/* ================= ROW TEMPLATES ================= */

function createInclusionRow() {
  return `
  <tr>
    <td>
      <select class="form-select form-select-sm inclusionDaySelect" name="inclusion_day_key[]"></select>
    </td>
    <td>
      <input type="text" class="form-control form-control-sm"
             name="inclusion_name[]" placeholder="Inclusion name">
    </td>
    <td>
      <input type="number" class="form-control form-control-sm"
             name="inclusion_amount[]" placeholder="Amount">
    </td>
    <td class="text-center">
      <button type="button" class="btn btn-sm btn-danger removeInclusionBtn">
        <i class="bi bi-trash"></i>
      </button>
    </td>
  </tr>`;
}

function createSpecialReqRow() {
  return `
  <tr>
    <td>
      <select class="form-select form-select-sm specialReqDaySelect" name="specialreq_day_key[]"></select>
    </td>
    <td>
      <select class="form-select form-select-sm specialReqSelect" name="quotation_special_requirements_id_fk[]"></select>
    </td>
    <td>
      <input type="number" class="form-control form-control-sm specialReqCost"
             name="special_requirements_cost[]" placeholder="Amount">
    </td>
    <td class="text-center">
      <button type="button" class="btn btn-sm btn-danger removeSpecialReqBtn">
        <i class="bi bi-trash"></i>
      </button>
    </td>
  </tr>`;
}

/* ================= ADD/REMOVE ROWS ================= */

// document.getElementById('addInclusionBtn').addEventListener('click', function (e) {
//     e.preventDefault();

//     const tbody = document.querySelector('#inclusionTable tbody');
//     tbody.insertAdjacentHTML('beforeend', createInclusionRow());

//     const row = tbody.lastElementChild;

//     fillDaySelect(row.querySelector('.inclusionDaySelect'));
// });

document.getElementById('addInclusionBtn').addEventListener('click', function (e) {
  e.preventDefault();

  const tbody = document.querySelector('#inclusionTable tbody');
  tbody.insertAdjacentHTML('beforeend', createInclusionRow());

  const row = tbody.lastElementChild;
  fillDaySelect(row.querySelector('.inclusionDaySelect'));

  recalcInclusionTotal();
});


// document.addEventListener('click', function (e) {
//   if (e.target.closest('.removeInclusionBtn')) {
//     e.target.closest('tr').remove();
//   }
// });

document.addEventListener('click', function (e) {
  if (e.target.closest('.removeInclusionBtn')) {
    e.target.closest('tr').remove();
    recalcInclusionTotal();
  }
});


// document.getElementById('addSpecialReqBtn').addEventListener('click', function (e) {
//     e.preventDefault();

//     const tbody = document.querySelector('#specialReqTable tbody');
//     tbody.insertAdjacentHTML('beforeend', createSpecialReqRow());

//     const row = tbody.lastElementChild;

//     fillDaySelect(row.querySelector('.specialReqDaySelect'));
//     fillSpecialReqSelect(row.querySelector('.specialReqSelect'));
// });

document.getElementById('addSpecialReqBtn').addEventListener('click', function (e) {
  e.preventDefault();

  const tbody = document.querySelector('#specialReqTable tbody');
  tbody.insertAdjacentHTML('beforeend', createSpecialReqRow());

  const row = tbody.lastElementChild;
  fillDaySelect(row.querySelector('.specialReqDaySelect'));
  fillSpecialReqSelect(row.querySelector('.specialReqSelect'));

  recalcSpecialReqTotal();
});


// document.addEventListener('click', function (e) {
//   if (e.target.closest('.removeSpecialReqBtn')) {
//     e.target.closest('tr').remove();
//   }
// });

document.addEventListener('click', function (e) {
  if (e.target.closest('.removeSpecialReqBtn')) {
    e.target.closest('tr').remove();
    recalcSpecialReqTotal();
  }
});


/* ================= AUTO-FILL COST WHEN SELECT REQUIREMENT ================= */

// document.addEventListener('change', function(e) {
//   const sel = e.target.closest('.specialReqSelect');
//   if (!sel) return;

//   const row = sel.closest('tr');
//   const costInput = row.querySelector('.specialReqCost');
//   const opt = sel.options[sel.selectedIndex];

//   const cost = opt?.dataset?.cost ?? '';
//   if (costInput) costInput.value = cost;
// });

// ✅ Works with normal select + select2
document.addEventListener('change', function (e) {
  const sel = e.target.closest('.specialReqSelect');
  if (!sel) return;

  const row = sel.closest('tr');
  const costInput = row?.querySelector('.specialReqCost');
  if (!costInput) return;

  // read selected option data-cost
  const opt = sel.options[sel.selectedIndex];
  const cost = opt && opt.dataset ? (opt.dataset.cost || '0') : '0';

  costInput.value = cost;

  // ✅ update total instantly
  recalcSpecialReqTotal();
});


function num(v) {
  const n = parseFloat(v);
  return isNaN(n) ? 0 : n;
}

function money(n) {
  return num(n).toFixed(2);
}

/* ✅ Recalculate inclusion total */
function recalcInclusionTotal() {
  let total = 0;
  document.querySelectorAll('#inclusionTable tbody [name="inclusion_amount[]"]').forEach(inp => {
    total += num(inp.value);
  });

  const txt = document.getElementById('totalInclusionAmountText');
  const hid = document.getElementById('totalInclusionAmountInput');
  if (txt) txt.textContent = money(total);
  if (hid) hid.value = money(total);

  return total;
}

/* ✅ Recalculate special requirements total */
function recalcSpecialReqTotal() {
  let total = 0;
  document.querySelectorAll('#specialReqTable tbody [name="special_requirements_cost[]"]').forEach(inp => {
    total += num(inp.value);
  });

  const txt = document.getElementById('totalSpecialReqAmountText');
  const hid = document.getElementById('totalSpecialReqAmountInput');
  if (txt) txt.textContent = money(total);
  if (hid) hid.value = money(total);

  return total;
}

/* ✅ Recalculate both (use after add/remove/load) */
function recalcAllInclusionSpecialTotals() {
  recalcInclusionTotal();
  recalcSpecialReqTotal();
}

/* Live update on typing amount fields */
document.addEventListener('input', function (e) {
  if (e.target.matches('#inclusionTable tbody [name="inclusion_amount[]"]')) {
    recalcInclusionTotal();
  }
  if (e.target.matches('#specialReqTable tbody [name="special_requirements_cost[]"]')) {
    recalcSpecialReqTotal();
  }
});

let optionCount = 0;

/* ================= ENABLE ADD OPTION AFTER PACKAGE ================= */

const packageSelect = document.getElementById('packages_id_fk');
const addOptionBtn = document.getElementById('addOptionBtn');
const optionsContainer = document.getElementById('optionsContainer');

packageSelect.addEventListener('change', () => {
    addOptionBtn.disabled = !packageSelect.value;
    optionsContainer.innerHTML = '';
    optionCount = 0;
    // loadDayDestOptionsForInclusionAndReq();
});

/* ================= ADD OPTION ================= */

// addOptionBtn.addEventListener('click', () => {
document.getElementById('addOptionBtn')?.addEventListener('click', function (e) {
  e.preventDefault();   // stop form submit
  e.stopPropagation();
    optionCount++;

    optionsContainer.insertAdjacentHTML(
        'beforeend',
        getOptionTemplate(optionCount)
    );

    const optionBlock = optionsContainer.lastElementChild;
    const dropdown = optionBlock.querySelector('.propertyDropdown');

    fetchPropertyCategories(dropdown);
});

/* ================= LOAD ITINERARY ON OPTION SELECT ================= */

document.addEventListener('change', (e) => {

    const dropdown = e.target.closest('.propertyDropdown');
    if (!dropdown) return;

    const optionBlock = dropdown.closest('.optionBlock');
    if (!optionBlock) return;

    const commonId = dropdown.value;
    if (!commonId) return;

    loadItinerary(optionBlock, commonId);
});

/* ================= REMOVE OPTION ================= */

document.addEventListener('click', (e) => {
    const btn = e.target.closest('.removeOptionBtn');
    if (!btn) return;

    btn.closest('.optionBlock')?.remove();
    reIndexOptions();
});

/* ================= HELPERS ================= */

function reIndexOptions() {
    optionCount = 0;
    document.querySelectorAll('.optionBlock').forEach((block) => {
        optionCount++;
        block.querySelector('.optionTitle').innerText = `Option ${optionCount}`;
        block.dataset.optionIndex = optionCount;

        const removeBtn = block.querySelector('.removeOptionBtn');
        optionCount === 1
            ? removeBtn.classList.add('d-none')
            : removeBtn.classList.remove('d-none');
    });
}

/* ================= FETCH PROPERTY OPTIONS ================= */

function fetchPropertyCategories(dropdown) {

    const packageId = packageSelect.value;
    if (!packageId) return;

    dropdown.innerHTML = '<option>Loading...</option>';

    fetch(`<?php echo base_url(); ?>index.php/Quotation/get_property_categories_by_package?package_id=${packageId}`)
        .then(res => res.json())
        .then(res => {
            dropdown.innerHTML = '<option value="">Select package option</option>';
            if (!res.status) return;

            res.data.forEach(item => {
                const opt = document.createElement('option');
                opt.value = item.packages_properties_common_id;
                opt.textContent = item.packages_properties_common_category_name;
                dropdown.appendChild(opt);
            });
        });
}

/* ================= LOAD FULL ITINERARY ================= */
function loadItinerary(optionBlock, commonId) {

    const container = optionBlock.querySelector('.itineraryContainer');
    if (!container) return;

    // ✅ Your select id is leads_id (from your HTML)
    const leadId = document.getElementById('leads_id')?.value || '';
    const packageId = document.getElementById('packages_id_fk')?.value || '';

    // ✅ Debug (check in browser console)
    console.log('loadItinerary params =>', { leadId, packageId, commonId });

    if (!commonId || !leadId || !packageId) {
        container.innerHTML = `
            <p class="text-danger mb-0">
                Missing params: 
                commonId=${commonId || 'EMPTY'},
                leadId=${leadId || 'EMPTY'},
                packageId=${packageId || 'EMPTY'}.
                Please select Lead + Package + Package Option.
            </p>`;
        return;
    }

    container.innerHTML = '<p>Loading itinerary...</p>';

    const url =
        `<?php echo base_url(); ?>index.php/Quotation/get_package_full_itinerary` +
        `?packages_properties_common_id=${encodeURIComponent(commonId)}` +
        `&lead_id=${encodeURIComponent(leadId)}` +
        `&package_id=${encodeURIComponent(packageId)}`;

    fetch(url)
        .then(async (r) => {
            // ✅ read as text first to avoid JSON.parse crash
            const text = await r.text();
            console.log('API raw response:', text);

            if (!text || text.trim() === '') {
                throw new Error('Empty response from server');
            }

            try {
                return JSON.parse(text);
            } catch (err) {
                throw new Error('Response is not valid JSON. Check API raw response in console.');
            }
        })
        .then(res => {

            if (!res.status || !Array.isArray(res.data) || res.data.length === 0) {
                container.innerHTML = `<p class="text-warning mb-0">No accommodation days found for this lead/package.</p>`;
                return;
            }

            let html = `
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Day | Date</th>
                            <th>Stay Destination</th>
                            <th>Properties & Rooms</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            res.data.forEach(day => {

                let propertiesHTML = '';

                (day.properties || []).forEach(property => {

                    let roomsHTML = '';

                    (property.rooms || []).forEach(room => {
                        roomsHTML += `
                            <tr data-room-id="${room.properties_room_category_id || ''}" data-packages-room-id="${room.packages_properties_rooms_id || 0}"
      data-day-id="${day.packages_properties_days_id || 0}">
                                <td class="roomName">
                                    ${room.properties_room_category_name || ''}
                                    <input type="hidden" name="packages_properties_rooms_id_fk[]" value="${room.packages_properties_rooms_id || 0}">
                                    <input type="hidden" name="quotation_properties_rooms_id_fk[]" value="${room.properties_room_category_id || 0}">
                                </td>
                                <td><span class="autoCalcRateText">0.00</span><!-- Hidden input for saving to DB -->
    <input type="hidden"
           name="total_room_cost[][]"
           class="autoCalcRateInput"
           value="0.00"></td>
                                <td class="text-center">
                                    <button type="button"
        class="btn btn-sm btn-warning me-1 editRoomBtn"
        data-lead-id="${leadId}"
        data-property-day-id="${day.packages_properties_days_id}"
        data-stay-destination-id="${day.packages_properties_days_destination_id_fk}"
        data-property-id="${property.properties_id}"
        data-room-category-id="${room.properties_room_category_id}">
    <i class="bi bi-pencil"></i>
</button>

                                    <button type="button" class="btn btn-sm btn-danger removeRoomBtn">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    });

                    propertiesHTML += `
                        <div class="propertyBlock mt-3"
                             data-property-id="${property.properties_id || ''}"
                             data-packages-property-id="${property.packages_properties_id || 0}">
                            <h6 class="fw-bold text-primary propertyTitle">
                                Property: ${property.properties_name || ''}
                            </h6>

                            <input type="hidden" name="packages_properties_id_fk[]" value="${property.packages_properties_id || 0}">
                            <input type="hidden" name="properties_id_fk[]" value="${property.properties_id || 0}">

                            <table class="table table-sm table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Room Name</th>
                                        <th>Calculated Rate</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>${roomsHTML}</tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-center">
                                            <button type="button" class="btn btn-sm btn-success addRoomBtn">
                                                <i class="bi bi-plus-circle"></i> Add New Room
                                            </button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    `;
                });

                html += `
                    <tr class="itineraryDayRow">
                        <td>
                            <strong>Day ${day.packages_properties_days_day || ''}</strong>
                            <input type="hidden" name="packages_properties_days_id_fk[]" value="${day.packages_properties_days_id || 0}">
                            <input type="hidden" name="quotation_properties_days_day[]" value="${day.packages_properties_days_day || ''}">
                        </td>

                        <td>
                            ${day.district_name || ''}
                            <input type="hidden" name="quotation_properties_days_destination_id_fk[]" value="${day.packages_properties_days_destination_id_fk || 0}">
                        </td>

                        <td>
                            <div class="propertiesContainer">${propertiesHTML}</div>

                            <div class="propertySelector d-none mt-2">
                                <select class="form-select form-select-sm propertySelectDropdown">
                                    <option value="">Select Property</option>
                                </select>
                            </div>

                            <div class="text-center mt-2">
                                <button type="button" class="btn btn-sm btn-primary addPropertyBtn">
                                    <i class="bi bi-plus-square"></i> Add Property
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            html += `</tbody></table><!-- ================= OPTION TOTAL SUMMARY ================= -->
<div class="option-total-box border rounded p-3 mt-4 bg-light">

  <div class="row g-3 align-items-end">

    <!-- Total Cost -->
    <div class="col-md-4">
      <label class="form-label fw-semibold">Total Cost</label>
      <div class="fw-bold text-primary fs-5">
        ₹ <span class="optionTotalCostText">0.00</span>
      </div>
      <input type="hidden" class="optionTotalCostInput" name="option_total_cost[]">
    </div>

    <!-- Margin -->
    <div class="col-md-4">
      <label class="form-label fw-semibold">Margin</label>
      <div class="d-flex gap-2">
        <select class="form-select form-select-sm optionMarginType">
          <option value="amount">Amount</option>
          <option value="percent">Percentage (%)</option>
        </select>

        <input type="number"
               class="form-control form-control-sm optionMarginValue"
               placeholder="Enter margin">
      </div>
    </div>

    <!-- Total Quote Rate -->
    <div class="col-md-4 text-end">
      <label class="form-label fw-semibold">Total Quote Rate</label>
      <div class="fw-bold text-primary fs-4">
        ₹ <span class="optionQuoteTotalText">0.00</span>
      </div>
      <input type="hidden" class="optionQuoteTotalInput" name="option_quote_total[]">
    </div>

  </div>
</div>
</div>`;
            container.innerHTML = html;
        })
        .catch(err => {
            console.error(err);
            container.innerHTML = `<p class="text-danger mb-0">${err.message}</p>`;
        });
}



/* ================= TEMPLATE ================= */

function getOptionTemplate(index) {
    return `
    <div class="optionBlock border p-3 mb-4" data-option-index="${index}">
        <h2 class="optionTitle mb-3">Option ${index}</h2>

        <div class="row mb-3">
            <div class="col-md-3">
                <label>Select package option</label>
                <select name=packages_properties_common_id_fk[] class="form-select form-select-sm propertyDropdown">
                    <option value="">Select package option</option>
                </select>
            </div>

            <div class="col-md-3">
                <label>Name of the option</label>
                <input type="text" name=quotation_options_title[] class="form-control">
            </div>

            <div class="col-md-3 d-flex align-items-end gap-2">
                <div class="w-100">
                    <label>Cab amount</label>
                    <input type="number" name=quotation_options_cab_amount[] class="form-control">
                </div>

                <button class="btn btn-danger removeOptionBtn ${index === 1 ? 'd-none' : ''}">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        </div>

        <div class="itineraryContainer"></div>
    </div>
    `;
}



////////////********** *************///////////

document.addEventListener('click', function (e) {

    const btn = e.target.closest('.addPropertyBtn');
    if (!btn) return;

    const td = btn.closest('td');
    const selector = td.querySelector('.propertySelector');
    const dropdown = selector.querySelector('.propertySelectDropdown');

    selector.classList.remove('d-none');

    if (dropdown.dataset.loaded === '1') return;

    dropdown.innerHTML = '<option>Loading...</option>';

    fetch(`<?php echo base_url(); ?>index.php/Quotation/get_properties`)
        .then(r => r.json())
        .then(r => {
            dropdown.innerHTML = '<option value="">Select Property</option>';
            r.data.forEach(p => {
                dropdown.innerHTML += `
                    <option value="${p.properties_id}">
                        ${p.properties_name}
                    </option>`;
            });
            dropdown.dataset.loaded = '1';
        });
});


document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('propertySelectDropdown')) return;

    const dropdown = e.target;
    const propertyId = dropdown.value;
    if (!propertyId) return;

    const td = dropdown.closest('td');
    const propertiesContainer = td.querySelector('.propertiesContainer');

    // 🔴 VALIDATION: SAME DAY DUPLICATE PROPERTY
    const exists = [...propertiesContainer.querySelectorAll('.propertyBlock')]
        .some(block => block.dataset.propertyId === propertyId);

    if (exists) {
        alert('This property is already added for this day.');
        dropdown.value = '';
        return;
    }

    const propertyName = dropdown.options[dropdown.selectedIndex].text;

    propertiesContainer.insertAdjacentHTML('beforeend', `
        <div class="propertyBlock mt-3" data-property-id="${propertyId}">
            
            <h6 class="fw-bold text-primary">
                Property: ${propertyName}
            </h6>

            <!-- ✅ HIDDEN FIELDS (IMPORTANT) -->
            <input type="hidden" name="properties_id_fk[]" value="${propertyId}">
            <input type="hidden" name="packages_properties_id_fk[]" value="0">

            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>Room Name</th>
                        <th>Rate</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-center">
                            <button class="btn btn-sm btn-success addRoomBtn">
                                <i class="bi bi-plus-circle"></i> Add Room
                            </button>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    `);

    dropdown.value = '';
    dropdown.closest('.propertySelector').classList.add('d-none');
});

document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('propertySelectDropdown')) return;

    const dropdown = e.target;
    const propertyId = dropdown.value;
    if (!propertyId) return;

    const td = dropdown.closest('td');
    const propertiesContainer = td.querySelector('.propertiesContainer');

    let exists = false;

    propertiesContainer.querySelectorAll('.propertyBlock').forEach(block => {
        if (block.dataset.propertyId === propertyId) {
            exists = true;
        }
    });

    if (exists) {
        alert('This property is already added for this day.');
        dropdown.value = '';
        return;
    }

    // ✅ continue adding property if not duplicate
});


function getRoomRowTemplate(propertyId, rooms) {
  let options = `<option value="">Select Room</option>`;
  rooms.forEach(r => {
    options += `<option value="${r.properties_room_category_id}">
      ${r.properties_room_category_name}
    </option>`;
  });

  return `
    <tr>
      <td>
        <select class="form-select form-select-sm roomSelect">${options}</select>
        <input type="hidden" name="packages_properties_rooms_id_fk[]" class="pkgRoomInput">
        <input type="hidden" name="quotation_properties_rooms_id_fk[]" class="roomInput">
      </td>
      <td class="roomRate"><span class="autoCalcRateText">0.00</span><!-- Hidden input for saving to DB -->
    <input type="hidden"
           name="total_room_cost[][]"
           class="autoCalcRateInput"
           value="0.00"></td>
      <td class="text-center">
        <button type="button"
                class="btn btn-sm btn-warning me-1 editRoomBtn"
                data-lead-id=""
                data-property-id="${propertyId}"
                data-room-category-id="">
          <i class="bi bi-pencil"></i>
        </button>
        <button type="button" class="btn btn-sm btn-danger removeRoomBtn">
          <i class="bi bi-trash"></i>
        </button>
      </td>
    </tr>
  `;
}

document.addEventListener('change', function (e) {
  if (!e.target.classList.contains('roomSelect')) return;

  const select = e.target;
  const roomId = select.value;
  if (!roomId) return;

  const row = select.closest('tr');
  const propertyBlock = select.closest('.propertyBlock');

  const leadId = document.getElementById('selected_lead_id').value || '';
  const propertyId = propertyBlock?.dataset.propertyId || '';

  // set hidden inputs
  row.querySelector('.roomInput').value = roomId;
  row.querySelector('.pkgRoomInput').value = '0'; // since it's new manual add, no package_room_id

  // set edit button dataset
  const editBtn = row.querySelector('.editRoomBtn');
  if (editBtn) {
    editBtn.dataset.leadId = leadId;
    editBtn.dataset.propertyId = propertyId;
    editBtn.dataset.roomCategoryId = roomId;
  }

  // mark for validation
  row.dataset.roomId = roomId;
});


document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('roomSelect')) return;

    const select = e.target;
    const row = select.closest('tr');
    const propertyBlock = select.closest('.propertyBlock');

    const roomId = select.value;
    if (!roomId) return;

    let duplicate = false;

    // check preloaded rooms
    propertyBlock.querySelectorAll('tr[data-room-id]').forEach(tr => {
        if (tr.dataset.roomId === roomId) duplicate = true;
    });

    // check newly added rooms
    propertyBlock.querySelectorAll('.roomSelect').forEach(other => {
        if (other !== select && other.value === roomId) duplicate = true;
    });

    if (duplicate) {
        alert('Room already selected');
        select.value = '';
        return;
    }

    const selectedOption = select.options[select.selectedIndex];

    // ✅ CRITICAL: store IDs
    row.dataset.roomId = roomId;
    row.dataset.packagesRoomId = selectedOption.dataset.packageRoomId;

    row.querySelector('.roomInput').value = roomId;
    row.querySelector('.pkgRoomInput').value =
        selectedOption.dataset.packageRoomId;
});

document.addEventListener('click', function (e) {

    const btn = e.target.closest('.addRoomBtn');
    if (!btn) return;

    const propertyBlock = btn.closest('.propertyBlock');
    const tbody = propertyBlock.querySelector('tbody');
    const propertyId = propertyBlock.dataset.propertyId;

    fetch(`<?php echo base_url(); ?>index.php/Quotation/get_rooms?properties_id=${propertyId}`)
        .then(res => res.json())
        .then(res => {
            if (!res.status || !res.data.length) return;

            tbody.insertAdjacentHTML(
                'beforeend',
                getRoomRowTemplate(propertyId, res.data)
            );
        });
});


document.addEventListener('click', function (e) {

    const btn = e.target.closest('.removeRoomBtn');
    if (!btn) return;

    btn.closest('tr').remove();
});

function parseDayDestValue(val) {
  // "dayId|stayDestId|date"
  const parts = (val || '').split('|');
  return {
    packages_properties_days_id_fk: parts[0] ? parseInt(parts[0], 10) : 0,
    stay_destination_id_fk: parts[1] ? parseInt(parts[1], 10) : 0,
    accommodation_date: parts[2] || ''
  };
}


function buildQuotationPayload() {

    const payload = { options: [], inclusions: [], special_requirements: [] };

    // Loop through each option block
    document.querySelectorAll('.optionBlock').forEach(optionBlock => {

        const option = {
            packages_properties_common_id_fk:
                optionBlock.querySelector('.propertyDropdown')?.value || '',
            title:
                optionBlock.querySelector('[name="quotation_options_title[]"]')?.value || '',
            cab_amount:
                optionBlock.querySelector('[name="quotation_options_cab_amount[]"]')?.value || '',
            
            // ✅ NEW: save exactly what UI calculated
            quotation_options_total_cost:
                optionBlock.querySelector('.optionTotalCostInput')?.value || '0',

            // store 'percent' or 'amount' (same as your UI)
            quotation_options_margin_type:
                optionBlock.querySelector('.optionMarginType')?.value || 'amount',

            quotation_options_margin_value:
                optionBlock.querySelector('.optionMarginValue')?.value || '0',

            quotation_options_total_quote_rate:
            optionBlock.querySelector('.optionQuoteTotalInput')?.value || '0',
            days: []
        };

        // Loop only actual day rows in itinerary table (skip room/property rows)
        optionBlock.querySelectorAll('.itineraryContainer tbody > tr').forEach(dayRow => {

            // Only process rows that contain day inputs
            const dayIdInput = dayRow.querySelector('[name="packages_properties_days_id_fk[]"]');
            if (!dayIdInput) return; // skip non-day rows

            const day = {
                packages_properties_days_id_fk: dayIdInput.value,
                day: dayRow.querySelector('[name="quotation_properties_days_day[]"]')?.value || '',
                destination_id: dayRow.querySelector('[name="quotation_properties_days_destination_id_fk[]"]')?.value || '',
                properties: []
            };

            // Loop properties within this day
            const propertiesContainer = dayRow.querySelector('.propertiesContainer');
            if (propertiesContainer) {
                propertiesContainer.querySelectorAll('.propertyBlock').forEach(propertyBlock => {

                    const property = {
                        packages_properties_id_fk: propertyBlock.dataset.packagesPropertyId || 0,
                        properties_id_fk: propertyBlock.dataset.propertyId || 0,
                        rooms: []
                    };

                    
                    // Loop rooms within this property
                    propertyBlock.querySelectorAll('tbody tr').forEach(roomRow => {
                        if (!roomRow.dataset.roomId) return;

                        //READ TOTAL ROOM COST from the row (you must have this hidden input in the row)
            const totalRoomCost =
              roomRow.querySelector('input.autoCalcRateInput')?.value ||
              roomRow.querySelector('[name="total_room_cost[]"]')?.value ||
              '0';
                        property.rooms.push({
                            packages_properties_rooms_id_fk: roomRow.dataset.packagesRoomId || 0,
                            quotation_properties_rooms_id_fk: roomRow.dataset.roomId,
                             // ✅ NEW FIELD (will go to DB later)
              total_room_cost: totalRoomCost
                        });
                    });

                    day.properties.push(property);
                });
            }

            option.days.push(day);
        });

        payload.options.push(option);
    });


        // ================= INCLUSIONS =================
    payload.inclusions = [];
    document.querySelectorAll('#inclusionTable tbody tr').forEach(tr => {
      const dayKey = tr.querySelector('[name="inclusion_day_key[]"]')?.value || '';
      const name = tr.querySelector('[name="inclusion_name[]"]')?.value || '';
      const amount = tr.querySelector('[name="inclusion_amount[]"]')?.value || '';

      if (!dayKey || !name) return;

      payload.inclusions.push({ dayKey, name, amount });
    });

    // ================= SPECIAL REQUIREMENTS =================
    payload.special_requirements = [];
    document.querySelectorAll('#specialReqTable tbody tr').forEach(tr => {
      const dayKey = tr.querySelector('[name="specialreq_day_key[]"]')?.value || '';
      const reqId = tr.querySelector('[name="quotation_special_requirements_id_fk[]"]')?.value || '';
      const cost = tr.querySelector('[name="special_requirements_cost[]"]')?.value || '';

      if (!dayKey || !reqId) return;

      payload.special_requirements.push({
        dayKey,
        quotation_special_requirements_id_fk: reqId,
        cost
      });
    });

    return payload;
}

    function recalcAllOptionsBeforeSave() {
  document.querySelectorAll('.optionBlock').forEach(ob => recalcOptionTotals(ob));
}


////////////********** *************///////////


function setHtmlSafe(selector, html) {
    const el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}

function setTextSafe(selector, text) {
    const el = document.querySelector(selector);
    if (el) el.textContent = text;
}

/* ================= EDIT ROOM BUTTON (ENQUIRY ONLY) ================= */
/* helpers (keep yours) */
/* ================= SAFE HELPERS ================= */
function setHtmlSafe(selector, html) {
    const el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}
function setTextSafe(selector, text) {
    const el = document.querySelector(selector);
    if (el) el.textContent = text;
}


/***********************
 *  POLICY AGE HELPERS
 ***********************/
function toInt(v, def = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}

function inRange(age, from, to) {
  if (!Number.isFinite(age)) return false;
  if (!Number.isFinite(from) || !Number.isFinite(to)) return false;
  return age >= from && age <= to;
}

function normalizeYesNo(v) {
  const s = String(v ?? '').trim().toLowerCase();
  return (s === 'y' || s === 'yes' || s === '1' || s === 'true');
}

/**
 * Build room policy age ranges string:
 * Baby 2-3 YR | Child 4-14 YR OR Baby - | Child -
 */
function getRoomPolicyAgeText(room) {
  const babyType = normalizeYesNo(room.properties_room_category_complimentary_guest_between_type);
  const babyFrom = toInt(room.properties_room_category_complimentary_guest_between_from_year, 0);
  const babyTo   = toInt(room.properties_room_category_complimentary_guest_between_to_year, 0);

  const childType = normalizeYesNo(room.properties_room_category_child_rate_applied_guest_between_type);
  const childFrom = toInt(room.properties_room_category_child_rate_applied_guest_from_year, 0);
  const childTo   = toInt(room.properties_room_category_child_rate_applied_guest_to_year, 0);

  const babyTxt  = (babyType && babyFrom > 0 && babyTo > 0) ? `Baby ${babyFrom}-${babyTo} YR` : `Baby -`;
  const childTxt = (childType && childFrom > 0 && childTo > 0) ? `Child ${childFrom}-${childTo} YR` : `Child -`;

  return `${babyTxt} | ${childTxt}`;
}

/***********************
 *  APPLIED PLAN (AGE BASED)
 *  Turns enquiry children ages into: adult/child/baby counts
 ***********************/
function computeAppliedCountsFromAges(room, enquiryPlan, childAges) {
  // enquiryPlan: { adults, children } from guset_count_details
  // childAges: [{age, count}, ...] from child_age_break_up

  const welcomesAll = normalizeYesNo(room.properties_room_category_welcomes_child_all_ages);
  const restrictUnder = toInt(room.properties_room_category_admission_restricted_guests_under_age, 0);

  const compType = normalizeYesNo(room.properties_room_category_complimentary_guest_between_type);
  const compFrom = toInt(room.properties_room_category_complimentary_guest_between_from_year, 0);
  const compTo   = toInt(room.properties_room_category_complimentary_guest_between_to_year, 0);

  const childType = normalizeYesNo(room.properties_room_category_child_rate_applied_guest_between_type);
  const childFrom = toInt(room.properties_room_category_child_rate_applied_guest_from_year, 0);
  const childTo   = toInt(room.properties_room_category_child_rate_applied_guest_to_year, 0);

  const adultOver = toInt(room.properties_room_category_adult_rate_applied_guest_over, 0);

  let adults = toInt(enquiryPlan.adults, 0);
  let children = 0;
  let baby = 0;

  let hasUnderRestrictedChild = false;

  // If you didn’t store ages, fall back to enquiryPlan.children
  const ageRows = Array.isArray(childAges) && childAges.length
    ? childAges
    : (toInt(enquiryPlan.children, 0) ? [{ age: null, count: toInt(enquiryPlan.children, 0) }] : []);

  ageRows.forEach(row => {
    const age = row.age === null ? null : toInt(row.age, NaN);
    const cnt = toInt(row.count, 0);
    if (cnt <= 0) return;

    // If no age info => treat as "child" unless rule #1 forces adult
    if (age === null || !Number.isFinite(age)) {
      // Rule 1: adultOver == 0 AND welcomesAll==Y AND restrictUnder==0 => child becomes adult
      if (adultOver === 0 && welcomesAll && (!restrictUnder || restrictUnder === 0)) {
        adults += cnt;
      } else {
        children += cnt;
      }
      return;
    }

    // Rule 2: restricted age -> convert to adult and flag warning
    if (!welcomesAll && restrictUnder > 0 && age < restrictUnder) {
      adults += cnt;
      hasUnderRestrictedChild = true;
      return;
    }

    // Rule 3: complimentary range => baby
    if (compType && compFrom > 0 && compTo > 0 && inRange(age, compFrom, compTo)) {
      baby += cnt;
      return;
    }

    // Rule 4: child rate range => child
    if (childType && childFrom > 0 && childTo > 0 && inRange(age, childFrom, childTo)) {
      children += cnt;
      return;
    }

    // Adult rule by age
    if (adultOver > 0 && age >= adultOver) {
      adults += cnt;
      return;
    }

    // Rule 1 again (welcomes + adultOver==0)
    if (adultOver === 0 && welcomesAll && (!restrictUnder || restrictUnder === 0)) {
      adults += cnt;
      return;
    }

    // default => child
    children += cnt;
  });

  return {
    applied: { adults, children, baby },
    warnings: {
      restrictUnder,
      hasUnderRestrictedChild
    }
  };
}

/***********************
 *  CORE ALLOCATOR
 *  Uses policy db/eb/sb like your examples
 *
 *  Interpretation:
 *  - db = number of adults allowed per room WITHOUT extra bed
 *  - eb = extra adult capacity per room (extra beds)
 *  - sb = sharing-bed capacity per room for baby/child
 ***********************/
function autoAllocate(policy, applied) {
  const db = toInt(policy.db, 0);
  const eb = toInt(policy.eb, 0);
  const sb = toInt(policy.sb, 0);

  let adults = toInt(applied.adults, 0);
  let children = toInt(applied.children, 0);
  let baby = toInt(applied.baby, 0);

  // outputs
  const out = {
    eligible: true,
    // pax-wise
    pax: {
      adult: { db: 0, eb: 0, sb: 0, sgl: 0 },
      child: { db: 0, eb: 0, sb: 0, sgl: 0 },
      baby:  { db: 0, eb: 0, sb: 0, sgl: 0 },
    },
    // rooming plan inputs (counts only)
    plan: {
      rooms_units: 0,
      extra_bed_adult: 0,
      child_sharing_bed: 0,
      single_occupancy: 0
    },
    // messages under pax box
    notes: {
      surplus: { db: 0, eb: 0, sb: 0 },
      excess:  { eb: 0 },
      alerts: []
    }
  };

  // ======= Scenario 1: all zero => not eligible
  if (db === 0 && eb === 0 && sb === 0) {
    out.eligible = false;
    out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB count.');
    return out;
  }

  // ======= Adult-only invalid: db=0 sb>0 eb=0
  if (adults > 0 && children === 0 && baby === 0 && db === 0 && eb === 0 && sb > 0) {
    out.eligible = false;
    out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB count.');
    return out;
  }

  // ======= Adult-only: 1 adult special SGL rules
  if (adults === 1 && children === 0 && baby === 0) {

    // scenario 2: db>=1 eb=0 => SGL 1
    if (db >= 1 && eb === 0) {
      out.pax.adult.sgl = 1;
      out.plan.single_occupancy = 1;
      out.plan.rooms_units = 1;
      return out;
    }

    // scenario 3: db=0 eb>=1 => SGL 1 and EB 1
    if (db === 0 && eb >= 1) {
      out.pax.adult.sgl = 1;
      out.pax.adult.eb = 1;
      out.plan.single_occupancy = 1;
      out.plan.extra_bed_adult = 1;
      out.plan.rooms_units = 1;
      out.notes.excess.eb = 1; // "Excess Bed Utilization: EB:1"
      return out;
    }

    // scenario 4: db=0 sb>=1 eb=0 already handled invalid above
  }

  // ======= General Adult allocation (your examples 5-14 etc.)
  // If db == 0 and adults > 0, only EB can host adults (rare but you used it)
  // We'll treat room base capacity = db + eb. If db=0, capacity = eb.
  const capAdultPerRoom = db + eb;

  if (adults > 0) {

    // If cap is 0 but adults exist => not eligible
    if (capAdultPerRoom <= 0) {
      out.eligible = false;
      out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB/EB policy.');
      return out;
    }

    // rooms needed
    const rooms = Math.ceil(adults / capAdultPerRoom);

    // DB utilization means: rooms count (like your examples)
    // For db=1 -> adult DB becomes adults because rooms = adults when cap=1
    // For db=2 -> adult DB becomes rooms (e.g. 8 adults => rooms 4)
    // BUT you display "Adult DB" as number of rooms (units). That matches your examples.
    out.pax.adult.db = rooms; // number of rooms
    out.plan.rooms_units = rooms;

    // base beds available for adults inside rooms = rooms * db
    const baseBedSlots = rooms * db;

    // extra adults beyond base => EB used
    let needExtra = Math.max(0, adults - baseBedSlots);

    // EB capacity total
    const ebCap = rooms * eb;

    // clamp
    if (needExtra > ebCap) {
      // should not happen if rooms computed from capAdultPerRoom,
      // but keep safe
      needExtra = ebCap;
      out.notes.alerts.push('Not enough EB capacity for this enquiry.');
    }

    out.pax.adult.eb = needExtra;
    out.plan.extra_bed_adult = needExtra;

    // Surplus EB (when eb policy exists and not fully used)
    if (eb > 0) {
      out.notes.surplus.eb = Math.max(0, ebCap - needExtra);
    }

    // Special: if db=0 and adults hosted only by EB => mark EB “excess”
    if (db === 0 && needExtra > 0) {
      out.notes.excess.eb = needExtra;
    }

    // Special: if adults==1 and db>=1 but eb>0, still your rule says SGL
    // We already handled adults===1 earlier, but keep safe
    if (adults === 1) {
      out.pax.adult.db = 0;
      out.pax.adult.eb = (db === 0 ? 1 : 0);
      out.pax.adult.sgl = 1;
      out.plan.rooms_units = 1;
      out.plan.single_occupancy = 1;
    }
  }

  // ======= Child/Baby allocation into SB (per room)
  // Your later scenarios use SB for baby/child “sharing bed”.
  // We allocate sharing beds across rooms calculated above.
  const roomsCount = Math.max(1, out.plan.rooms_units || 0);
  const sbCapTotal = roomsCount * sb;
  const needSB = children + baby;

  const useSB = Math.min(sbCapTotal, needSB);
  out.plan.child_sharing_bed = useSB;

  // split SB usage: prefer baby first, then child (common)
  const babySB = Math.min(baby, useSB);
  const childSB = Math.max(0, useSB - babySB);

  out.pax.baby.sb = babySB;
  out.pax.child.sb = childSB;

  // Surplus SB
  if (sb > 0) out.notes.surplus.sb = Math.max(0, sbCapTotal - useSB);

  // If there are remaining child/baby not placed
  const remain = needSB - useSB;
  if (remain > 0) {
    out.notes.alerts.push('Not enough SB capacity for child/baby. Please adjust rooming manually.');
  }

  // Surplus DB (when db per room > what is required per room, like your db=4 example)
  // In your example: adults=9, db=4 => rooms=3, baseBedSlots=12, unused base beds = 3
  // You show "Surplus Bed Available: DB:3"
  const unusedBaseBeds = Math.max(0, (roomsCount * db) - adults);
  out.notes.surplus.db = unusedBaseBeds;

  return out;
}

/***********************
 *  APPLY ALLOCATION TO MODAL UI
 ***********************/
function applyAllocationToModal(allocation) {
  // reset message areas if you have them
  setTextSafe('#paxNoteSurplus', '');
  setTextSafe('#paxNoteExcess', '');
  setTextSafe('#paxNoteAlert', '');

  // pax-wise spans
  setTextSafe('[data-role="adult-db"]', allocation.pax.adult.db);
  setTextSafe('[data-role="adult-eb"]', allocation.pax.adult.eb);
  setTextSafe('[data-role="adult-sb"]', allocation.pax.adult.sb);
  setTextSafe('[data-role="adult-sgl"]', allocation.pax.adult.sgl);

  setTextSafe('[data-role="child-db"]', allocation.pax.child.db);
  setTextSafe('[data-role="child-eb"]', allocation.pax.child.eb);
  setTextSafe('[data-role="child-sb"]', allocation.pax.child.sb);
  setTextSafe('[data-role="child-sgl"]', allocation.pax.child.sgl);

  setTextSafe('[data-role="baby-db"]', allocation.pax.baby.db);
  setTextSafe('[data-role="baby-eb"]', allocation.pax.baby.eb);
  setTextSafe('[data-role="baby-sb"]', allocation.pax.baby.sb);
  setTextSafe('[data-role="baby-sgl"]', allocation.pax.baby.sgl);

  // rooming plan input fields (Auto)
  // Use your modal input names/ids; adjust selectors if different.
  const autoRooms = document.querySelector('[name="auto_room_member_count"]');
  const autoEB    = document.querySelector('[name="auto_extra_bed_adult_count"]');
  const autoSB    = document.querySelector('[name="auto_child_sharing_bed_count"]');
  const autoSGL   = document.querySelector('[name="auto_single_occupancy_count"]');

  if (autoRooms) autoRooms.value = allocation.plan.rooms_units;
  if (autoEB)    autoEB.value    = allocation.plan.extra_bed_adult;
  if (autoSB)    autoSB.value    = allocation.plan.child_sharing_bed;
  if (autoSGL)   autoSGL.value   = allocation.plan.single_occupancy;

  // rooming plan input fields (Manual) default same as auto
  const manRooms = document.querySelector('[name="manual_count"]');
  const manEB    = document.querySelector('[name="manual_extra_bed_adult_count"]');
  const manSB    = document.querySelector('[name="manual_child_sharing_bed_count"]');
  const manSGL   = document.querySelector('[name="manual_single_occupancy_count"]');

  if (manRooms) manRooms.value = allocation.plan.rooms_units;
  if (manEB)    manEB.value    = allocation.plan.extra_bed_adult;
  if (manSB)    manSB.value    = allocation.plan.child_sharing_bed;
  if (manSGL)   manSGL.value   = allocation.plan.single_occupancy;

  // notes
  const surplusParts = [];
  if (allocation.notes.surplus.db > 0) surplusParts.push(`DB:${allocation.notes.surplus.db}`);
  if (allocation.notes.surplus.eb > 0) surplusParts.push(`EB:${allocation.notes.surplus.eb}`);
  if (allocation.notes.surplus.sb > 0) surplusParts.push(`SB:${allocation.notes.surplus.sb}`);

  if (surplusParts.length) {
    setTextSafe('#paxNoteSurplus', `Surplus Bed Available: ${surplusParts.join(' ')}`);
  }

  if (allocation.notes.excess.eb > 0) {
    setTextSafe('#paxNoteExcess', `Excess Bed Utilization: EB:${allocation.notes.excess.eb}`);
  }

  if (allocation.notes.alerts.length) {
    setTextSafe('#paxNoteAlert', allocation.notes.alerts.join(' | '));
  }
}


/* ================= EDIT ROOM BUTTON (FULL) ================= */
function setHtmlSafe(selector, html) {
    var el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}
function setTextSafe(selector, text) {
    var el = document.querySelector(selector);
    if (el) el.textContent = (text === undefined || text === null) ? '' : String(text);
}
function setTextSafeIn(modalEl, selector, text) {
    if (!modalEl) return;
    var el = modalEl.querySelector(selector);
    if (el) el.textContent = (text === undefined || text === null) ? '' : String(text);
}
function setHtmlSafeIn(modalEl, selector, html) {
    if (!modalEl) return;
    var el = modalEl.querySelector(selector);
    if (el) el.innerHTML = html || '';
}

document.addEventListener('click', function (e) {

    var btn = e.target.closest('.editRoomBtn');
    if (!btn) return;

    var leadId         = btn.dataset.leadId || '';
    var propertyId     = btn.dataset.propertyId || '';
    var roomCategoryId = btn.dataset.roomCategoryId || '';
    var propertyDayId  = btn.dataset.propertyDayId || '';
    var stayDestId     = btn.dataset.stayDestinationId || '';

    if (!leadId || !propertyId || !roomCategoryId || !propertyDayId || !stayDestId) {
        alert('Missing lead/property/room/day/destination details');
        console.log({ leadId: leadId, propertyId: propertyId, roomCategoryId: roomCategoryId, propertyDayId: propertyDayId, stayDestId: stayDestId });
        return;
    }

    var modalEl = document.getElementById('roompricingandguestallocationModal');
    if (!modalEl) {
        alert('Modal not found in page');
        return;
    }

    // store last clicked button row for UI update after save
window.__lastRoomEditBtn = btn;

// day row (itinerary day row)
const dayRow = btn.closest('.itineraryDayRow'); 
const dayId = dayRow?.querySelector('[name="packages_properties_days_id_fk[]"]')?.value || '';

// room row id (quotation_properties_rooms_id_fk)
// you already store room row id in hidden input inside the room row:
const roomTr = btn.closest('tr');
const qpRoomId = roomTr?.querySelector('[name="packages_properties_rooms_id_fk[]"]')?.value || '';

document.getElementById('modal_packages_properties_days_id_fk').value = dayId;
document.getElementById('modal_quotation_properties_rooms_id_fk').value = qpRoomId;

    /* ================= RESET MODAL ================= */
    setTextSafeIn(modalEl, '#modalTotalRate', '0');
    setTextSafeIn(modalEl, '#modalLeadInfo', 'Loading...');
    setTextSafeIn(modalEl, '#modalRoomInfo', 'Loading...');
    setTextSafeIn(modalEl, '[data-role="room-policy"]', 'Loading...');
    setTextSafeIn(modalEl, '[data-role="meal-plan"]', '-');

    // Room policy age line (Baby/Child range)
    setTextSafeIn(modalEl, '[data-role="room-policy-ages"]', 'Baby - | Child -');

    // ✅ In Enquiry reset (Adult + Child only)
    setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
    setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
    setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', '-');

    // ✅ Applied reset (Adult + Child + Baby + meal)
    setTextSafeIn(modalEl, '[data-role="applied-adult"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-child"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-baby"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
    setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', '');
    setHtmlSafeIn(modalEl, '#appliedMealWarningWrap', '');

    // ✅ reset pax-wise bed utilization spans
    var spans = modalEl.querySelectorAll('[data-role^="adult-"],[data-role^="child-"],[data-role^="baby-"]');
    for (var i = 0; i < spans.length; i++) spans[i].textContent = '0';

    // ✅ hidden fields
    var modalLead = document.getElementById('modal_lead_id');
    var modalProp = document.getElementById('modal_property_id');
    var modalRoom = document.getElementById('modal_room_category_id');
    if (modalLead) modalLead.value = leadId;
    if (modalProp) modalProp.value = propertyId;
    if (modalRoom) modalRoom.value = roomCategoryId;

    // ✅ open modal first
    // bootstrap.Modal.getOrCreateInstance(modalEl).show();
//     $('#roompricingandguestallocationModal').modal({
//   backdrop: 'static',
//   keyboard: false,
//   show: true
// });
$('#roompricingandguestallocationModal').modal('show'); // show bootstrap modal

    /* ================= API URLS ================= */
    var urlPolicy =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_room_policy_details` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    var urlEnquiry =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_in_enquiry_context` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_day_id=${encodeURIComponent(propertyDayId)}` +
        `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    var urlApplied =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_applied_plan_context` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_day_id=${encodeURIComponent(propertyDayId)}` +
        `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    /* ================= LOAD ALL ================= */
    Promise.all([
        fetch(urlPolicy).then(function (r) { return r.json(); }),
        fetch(urlEnquiry).then(function (r) { return r.json(); }),
        fetch(urlApplied).then(function (r) { return r.json(); })
    ])
    .then(function (responses) {

        var policyRes = responses[0];
        var enquiryRes = responses[1];
        var appliedRes = responses[2];

        /* ================= POLICY UI ================= */
        var policy = { db: 0, eb: 0, sb: 0 };

        if (policyRes && policyRes.status) {

            var lead = (policyRes.data && policyRes.data.lead) ? policyRes.data.lead : {};
            var property = (policyRes.data && policyRes.data.property) ? policyRes.data.property : {};
            var room = (policyRes.data && policyRes.data.room) ? policyRes.data.room : {};

            var db  = parseInt(room.properties_room_category_number_of_adults_allowed, 10);
            var eb  = parseInt(room.properties_room_category_extra_bed_mattress_allowed_in_room, 10);
            var sb  = parseInt(room.properties_room_category_children_allowed_on_bed_sharing_basis, 10);
            var inv = room.properties_room_category_inventory;

            if (isNaN(db)) db = 0;
            if (isNaN(eb)) eb = 0;
            if (isNaN(sb)) sb = 0;
            if (inv === undefined || inv === null) inv = 0;

            policy = { db: db, eb: eb, sb: sb };

            setTextSafeIn(modalEl, '#modalLeadInfo', 'Lead No: ' + (lead.leads_number || '-'));

            setHtmlSafeIn(
                modalEl,
                '#modalRoomInfo',
                (property.properties_name || '-') + '<br>' +
                (room.properties_room_category_name || '-') + '<br>' +
                'DB:' + db + ' | EB:' + eb + ' | SB:' + sb + ' | Inventory:' + inv
            );

            setTextSafeIn(modalEl, '[data-role="room-policy"]', 'DB:' + db + ' | EB:' + eb + ' | SB:' + sb + ' | Inventory:' + inv);

            // Room default meal plan name
            setTextSafeIn(modalEl, '[data-role="meal-plan"]', room.meal_plan_name || '-');

            // Baby/Child age range text from backend (if you return it)
            var agesTxt = (policyRes.data && policyRes.data.policy_ages_text) ? policyRes.data.policy_ages_text : '';
            setTextSafeIn(modalEl, '[data-role="room-policy-ages"]', agesTxt ? agesTxt : 'Baby - | Child -');
        }

        /* ================= IN ENQUIRY UI ================= */
        if (enquiryRes && enquiryRes.status) {

            var eqData = enquiryRes.data ? enquiryRes.data : {};
            var eqPlan = eqData.plan ? eqData.plan : null;

            setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', eqData.meal_plan_name || '-');

            if (eqPlan) {
                setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', (eqPlan.adults !== undefined && eqPlan.adults !== null) ? eqPlan.adults : 0);
                setTextSafeIn(modalEl, '[data-role="enquiry-child"]', (eqPlan.children !== undefined && eqPlan.children !== null) ? eqPlan.children : 0);
            } else {
                setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
                setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
            }

        } else {
            setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
            setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
            setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', '-');
        }

        /* ================= APPLIED UI ================= */
        var appliedPlan = { adults: 0, children: 0, baby: 0 };

        setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
        setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', '');
        setHtmlSafeIn(modalEl, '#appliedMealWarningWrap', '');

        if (appliedRes && appliedRes.status) {

            var apData = appliedRes.data ? appliedRes.data : {};

            // Applied meal name
            setTextSafeIn(modalEl, '[data-role="applied-meal"]', apData.meal_plan_name || '-');

            // mismatch icon (ONLY for applied meal)data-bs-placement="top"
            if (parseInt(apData.meal_plan_mismatch, 10) === 1) {

                setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', (
                    '<span class="ms-2 text-warning" ' +
                    'data-bs-toggle="tooltip" data-placement="top" ' +
                    'title="Room\'s default meal plan is overridden by the enquiry meal plan">' +
                    '<i class="bi bi-exclamation-triangle-fill"></i>' +
                    '</span>'
                ));

                var wrap = modalEl.querySelector('#mealMismatchIconWrap');
                var tipEl = wrap ? wrap.querySelector('[data-bs-toggle="tooltip"]') : null;
                // if (tipEl) new bootstrap.Tooltip(tipEl);
                if (tipEl) $(tipEl).tooltip();
            }

            // EP room-only warning: room default meal plan id = 2
            if (parseInt(apData.room_is_ep_room_only, 10) === 1) {
                setHtmlSafeIn(modalEl, '#appliedMealWarningWrap',
                    '<div class="text-danger mt-2"><small>' +
                    'Meal rates not found. Update rates or enter manually in the supplement cost field.' +
                    '</small></div>'
                );
            }

            // Applied counts computed in backend (adult/child/baby)
            if (apData.applied) {
                appliedPlan.adults = parseInt(apData.applied.adults, 10); if (isNaN(appliedPlan.adults)) appliedPlan.adults = 0;
                appliedPlan.children = parseInt(apData.applied.children, 10); if (isNaN(appliedPlan.children)) appliedPlan.children = 0;
                appliedPlan.baby = parseInt(apData.applied.baby, 10); if (isNaN(appliedPlan.baby)) appliedPlan.baby = 0;
            }

            setTextSafeIn(modalEl, '[data-role="applied-adult"]', appliedPlan.adults);
            setTextSafeIn(modalEl, '[data-role="applied-child"]', appliedPlan.children);
            setTextSafeIn(modalEl, '[data-role="applied-baby"]', appliedPlan.baby);

        } else {
            setTextSafeIn(modalEl, '[data-role="applied-adult"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-child"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-baby"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
        }

        /* ================= AUTO ALLOCATION ================= */
        if (typeof autoAllocateBeds === 'function' && typeof applyAutoAllocationToModal === 'function') {
            var allocation = autoAllocateBeds(policy, appliedPlan);
            applyAutoAllocationToModal(allocation);

            // 1) copy auto -> manual so manual starts same
            syncAutoToManualCountsAndRates();

           // 2) calculate amounts + totals for both
           refreshAllAmountsAndTotals();

        }

        const urlTariff =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_tariff_by_context` +
    `?lead_id=${encodeURIComponent(leadId)}` +
    `&property_day_id=${encodeURIComponent(propertyDayId)}` +
    `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
    `&property_id=${encodeURIComponent(propertyId)}` +
    `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

fetch(urlTariff)
  .then(r => r.json())
  .then(tariffRes => {
      applyTariffRatesToModal(tariffRes);
      calcTotalFromAuto(); // optional
  })
  .catch(err => console.error('Tariff API error', err));


    })
    .catch(function (err) {
        console.error(err);
        alert('Error loading modal data');
    });

});





/* ================= Auto Allocation ================= */
function autoAllocateBeds(policy, applied) {

    const roomDB = Number(policy.db || 0);
    const roomEB = Number(policy.eb || 0);
    const roomSB = Number(policy.sb || 0);

    let adults = Number(applied.adults || 0);
    let children = Number(applied.children || 0);
    let baby = Number(applied.baby || 0);

    const dbCap = roomDB > 0 ? roomDB : 2;

    // ===== Adults -> Rooms/DB/EB =====
    let rooms = Math.ceil(adults / dbCap);
    if (rooms < 1 && adults > 0) rooms = 1;

    let adultsInDB = Math.min(adults, rooms * dbCap);
    let remainingAdults = adults - adultsInDB;

    let adultsInEB = 0;

    if (remainingAdults > 0 && roomEB > 0) {
        const ebCapacityTotal = rooms * roomEB;
        adultsInEB = Math.min(remainingAdults, ebCapacityTotal);
        remainingAdults -= adultsInEB;
    }

    while (remainingAdults > 0) {
        rooms += 1;

        const takeDB = Math.min(dbCap, remainingAdults);
        adultsInDB += takeDB;
        remainingAdults -= takeDB;

        if (roomEB > 0 && remainingAdults > 0) {
            const takeEB = Math.min(roomEB, remainingAdults);
            adultsInEB += takeEB;
            remainingAdults -= takeEB;
        }
    }

    // SGL (approx): if remainder is 1 adult in last room
    let remDB = adults % dbCap;
    let adultSGLRooms = (dbCap > 1 && remDB === 1) ? 1 : 0;

    // ===== Children/Baby -> SB =====
    let sbCapacityTotal = rooms * roomSB;

    let childInSB = Math.min(children, sbCapacityTotal);
    let remainingChildren = children - childInSB;

    let babyInSB = Math.min(baby, Math.max(0, sbCapacityTotal - childInSB));
    let remainingBaby = baby - babyInSB;

    let extraChildRooms = 0;

    while ((remainingChildren + remainingBaby) > 0) {

        if (roomSB <= 0) break;

        extraChildRooms += 1;

        const takeChild = Math.min(roomSB, remainingChildren);
        remainingChildren -= takeChild;

        const freeSB = roomSB - takeChild;
        const takeBaby = Math.min(freeSB, remainingBaby);
        remainingBaby -= takeBaby;
    }

    return {
        totalRooms: rooms + extraChildRooms,
        adult: { db: Math.max(0, adults - adultsInEB), eb: adultsInEB, sb: 0, sgl: adultSGLRooms },
        child: { db: 0, eb: 0, sb: (children - remainingChildren), sgl: 0 },
        baby: { db: 0, eb: 0, sb: (baby - remainingBaby), sgl: 0 },
        warnings: { unallocatedChildren: remainingChildren, unallocatedBaby: remainingBaby }
    };
}

function setValSafe(selector, val) {
    const el = document.querySelector(selector);
    if (el) el.value = (val ?? 0);
}

function applyAutoAllocationToModal(result) {

    // ---------------------------
    // AUTO ROOMING PLAN INPUTS
    // ---------------------------
    setValSafe('#roompricingandguestallocationModal [name="auto_room_member_count"]', result.totalRooms ?? 0);

    // If your autoAllocateBeds also calculates these, use them.
    // If not, they will become 0 (safe).
    setValSafe('#roompricingandguestallocationModal [name="auto_extra_bed_adult_count"]', result.adult?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_extra_bed_child_count"]', result.child?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_child_sharing_bed_count"]', result.child?.sb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_single_occupancy_count"]', result.adult?.sgl ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_supplment_cost_count"]', 0); // later

    // ---------------------------
    // ✅ MANUAL DEFAULTS = SAME AS AUTO
    // ---------------------------
    setValSafe('#roompricingandguestallocationModal [name="manual_count"]', result.totalRooms ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_extra_bed_adult_count"]', result.adult?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_extra_bed_child_count"]', result.child?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_child_sharing_bed_count"]', result.child?.sb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_single_occupancy_count"]', result.adult?.sgl ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_supplment_cost_count"]', 0); // later

    // ---------------------------
    // PAX-WISE BED UTILIZATION
    // ---------------------------
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-db"]',  result.adult?.db  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-eb"]',  result.adult?.eb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-sb"]',  result.adult?.sb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-sgl"]', result.adult?.sgl ?? 0);

    setTextSafe('#roompricingandguestallocationModal [data-role="child-db"]',  result.child?.db  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-eb"]',  result.child?.eb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-sb"]',  result.child?.sb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-sgl"]', result.child?.sgl ?? 0);

    setTextSafe('#roompricingandguestallocationModal [data-role="baby-db"]',   result.baby?.db   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-eb"]',   result.baby?.eb   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-sb"]',   result.baby?.sb   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-sgl"]',  result.baby?.sgl  ?? 0);

    // ---------------------------
    // WARNINGS (optional)
    // ---------------------------
    if (result.warnings && (result.warnings.unallocatedChildren > 0 || result.warnings.unallocatedBaby > 0)) {
        console.warn('Unallocated pax due to policy limits:', result.warnings);
    }
}

function setInputSafe(selector, val) {
    const el = document.querySelector(selector);
    if (el) el.value = (val === undefined || val === null) ? '' : val;
}

function applyTariffRatesToModal(tariffRes) {

    if (!tariffRes || !tariffRes.status) return;

    const d = tariffRes.data || {};
    const rates = d.rates || {};

    // ✅ Rooms | Units RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_room_member_rate"]', rates.room_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_rate"]', rates.room_rate || 0);

    // ✅ Extra Bed Adult RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_extra_bed_adult_rate"]', rates.adult_eb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_extra_bed_adult_rate"]', rates.adult_eb_rate || 0);

    // ✅ Extra Bed Child RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_extra_bed_child_rate"]', rates.child_eb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_extra_bed_child_rate"]', rates.child_eb_rate || 0);

    // ✅ Child Sharing Bed RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_child_sharing_bed_rate"]', rates.child_sb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_child_sharing_bed_rate"]', rates.child_sb_rate || 0);

    // ✅ Single Occupancy RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_single_occupancy_rate"]', rates.sgl_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_single_occupancy_rate"]', rates.sgl_rate || 0);

    // ✅ Supplement Cost COUNT = NA (Auto + Manual)
    const supCountAuto = document.querySelector('#roompricingandguestallocationModal [name="auto_supplment_cost_count"]');
    const supCountMan  = document.querySelector('#roompricingandguestallocationModal [name="manual_supplment_cost_count"]');
    if (supCountAuto) { supCountAuto.value = 'NA'; supCountAuto.setAttribute('readonly','readonly'); }
    if (supCountMan)  { supCountMan.value  = 'NA'; supCountMan.setAttribute('readonly','readonly'); }

    // ✅ Supplement Cost RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_supplment_cost"]', d.supplement_amount || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_supplment_cost"]', d.supplement_amount || 0);
}

function calcTotalFromAuto() {

    const num = (sel) => parseFloat(document.querySelector(sel)?.value || 0) || 0;

    const roomsCount = num('#roompricingandguestallocationModal [name="auto_room_member_count"]');
    const roomsRate  = num('#roompricingandguestallocationModal [name="auto_room_member_rate"]');

    const ebAcount = num('#roompricingandguestallocationModal [name="auto_extra_bed_adult_count"]');
    const ebArate  = num('#roompricingandguestallocationModal [name="auto_extra_bed_adult_rate"]');

    const ebCcount = num('#roompricingandguestallocationModal [name="auto_extra_bed_child_count"]');
    const ebCrate  = num('#roompricingandguestallocationModal [name="auto_extra_bed_child_rate"]');

    const sbCount = num('#roompricingandguestallocationModal [name="auto_child_sharing_bed_count"]');
    const sbRate  = num('#roompricingandguestallocationModal [name="auto_child_sharing_bed_rate"]');

    const sglCount = num('#roompricingandguestallocationModal [name="auto_single_occupancy_count"]');
    const sglRate  = num('#roompricingandguestallocationModal [name="auto_single_occupancy_rate"]');

    const supplement = num('#roompricingandguestallocationModal [name="auto_supplment_cost"]');

    const total =
        (roomsCount * roomsRate) +
        (ebAcount * ebArate) +
        (ebCcount * ebCrate) +
        (sbCount * sbRate) +
        (sglCount * sglRate) +
        supplement;

    setTextSafe('#modalTotalRate', total.toFixed(2));
}

/* ================= RATE + AMOUNT CALC HELPERS ================= */

function toNumber(val) {
  if (val === null || val === undefined) return 0;
  val = ('' + val).replace(/,/g, '').trim();
  if (val === '' || val.toUpperCase() === 'NA') return 0;
  const n = parseFloat(val);
  return isNaN(n) ? 0 : n;
}

function money(val) {
  // you can format if you want. Keeping simple:
  const n = toNumber(val);
  return (Math.round(n * 100) / 100).toFixed(2);
}

function getPlanInput(plan, line, field) {
  return document.querySelector(
    `#roompricingandguestallocationModal [data-plan="${plan}"][data-line="${line}"][data-field="${field}"]`
  );
}

function setAmount(plan, line, amount) {
  const span = document.querySelector(
    `#roompricingandguestallocationModal [data-role="amount-${plan}-${line}"]`
  );
  if (span) span.textContent = money(amount);

  const hidden = document.querySelector(
    `#roompricingandguestallocationModal [data-save="${plan}"][data-line="${line}"][data-save-field="amount"]`
  );
  if (hidden) hidden.value = money(amount);
}

function calcLineAmount(plan, line) {
  const countEl = getPlanInput(plan, line, 'count');
  const rateEl  = getPlanInput(plan, line, 'rate');

  const rate = toNumber(rateEl ? rateEl.value : 0);

  // Supplement: amount = rate only (count is NA)
  if (line === 'supplement') {
    setAmount(plan, line, rate);
    return rate;
  }

  const count = toNumber(countEl ? countEl.value : 0);
  const amt = count * rate;
  setAmount(plan, line, amt);
  return amt;
}

function calcTotal(plan) {
  const lines = ['rooms', 'eb_adult', 'eb_child', 'sb_child', 'sgl', 'supplement'];
  let total = 0;

  lines.forEach(line => {
    total += calcLineAmount(plan, line);
  });

  // total html + hidden
  const totalSpan = document.querySelector(`#roompricingandguestallocationModal [data-role="total-${plan}"]`);
  if (totalSpan) totalSpan.textContent = money(total);

  const totalHidden = document.getElementById(`${plan}_total_rate`);
  if (totalHidden) totalHidden.value = money(total);

  return total;
}

/* Copy Auto -> Manual counts/rates so manual starts same as auto */
function syncAutoToManualCountsAndRates() {
  const lines = ['rooms', 'eb_adult', 'eb_child', 'sb_child', 'sgl', 'supplement'];

  lines.forEach(line => {
    const aCount = getPlanInput('auto', line, 'count');
    const aRate  = getPlanInput('auto', line, 'rate');
    const mCount = getPlanInput('manual', line, 'count');
    const mRate  = getPlanInput('manual', line, 'rate');

    // manual should start same values (only if inputs exist)
    if (mCount && aCount) mCount.value = aCount.value;
    if (mRate && aRate) mRate.value = aRate.value;
  });
}

/* Call this whenever modal opens or whenever auto allocation/rates loaded */
function refreshAllAmountsAndTotals() {
  // Auto
  calcTotal('auto');
  // Manual
  calcTotal('manual');
}

/* Manual live update when user edits count/rate */
document.addEventListener('input', function (e) {
  const el = e.target;
  if (!el.closest('#roompricingandguestallocationModal')) return;

  const plan = el.dataset.plan;
  const line = el.dataset.line;

  if (plan !== 'manual') return; // only manual updates by user input
  if (!line) return;

  // update only that line and total
  calcLineAmount('manual', line);
  calcTotal('manual');
});

const roomModalEl = document.getElementById('roompricingandguestallocationModal');

if (roomModalEl) {
  roomModalEl.addEventListener('shown.bs.modal', function () {
    // Wait 1 tick so DOM values are painted
    setTimeout(() => {
      refreshAllAmountsAndTotals();
    }, 0);
  });
}

document.getElementById('btnSave1')?.addEventListener('click', function () {

    const dayId   = document.getElementById('modal_packages_properties_days_id_fk')?.value || '';
    const roomRow = document.getElementById('modal_quotation_properties_rooms_id_fk')?.value || '';

    if (!dayId || !roomRow) {
        console.log({ dayId, roomRow });
        return alert('Missing Day ID or Room Row ID');
    }

    const fd = new FormData();
    fd.append('packages_properties_days_id_fk', dayId);
    fd.append('quotation_properties_rooms_id_fk', roomRow);

    const spanNum = (sel) => (document.querySelector(sel)?.textContent || '0').trim();
    const inputVal = (sel, def='0') => (document.querySelector(sel)?.value ?? def);

    // pax wise
    fd.append('pax_wise_bed_adult_db_count', spanNum('[data-role="adult-db"]'));
    fd.append('pax_wise_bed_adult_eb_count', spanNum('[data-role="adult-eb"]'));
    fd.append('pax_wise_bed_adult_sgl_count', spanNum('[data-role="adult-sb"]'));

    fd.append('pax_wise_bed_child_db_count', spanNum('[data-role="child-db"]'));
    fd.append('pax_wise_bed_child_eb_count', spanNum('[data-role="child-eb"]'));
    fd.append('pax_wise_bed_child_sb_count', spanNum('[data-role="child-sb"]'));

    fd.append('pax_wise_bed_baby_db_count', spanNum('[data-role="baby-db"]'));
    fd.append('pax_wise_bed_baby_eb_count', spanNum('[data-role="baby-eb"]'));
    fd.append('pax_wise_bed_baby_sb_count', spanNum('[data-role="baby-sb"]'));

    // Auto inputs
    fd.append('room_unit_auto_count', inputVal('[name="auto_room_member_count"]'));
    fd.append('room_unit_auto_rate', inputVal('[name="auto_room_member_rate"]'));
    fd.append('room_unit_auto_total_rate', (document.querySelector('[data-role="amount-auto-rooms"]')?.textContent || '0'));

    fd.append('extra_bed_adult_auto_count', inputVal('[name="auto_extra_bed_adult_count"]'));
    fd.append('extra_bed_adult_auto_rate', inputVal('[name="auto_extra_bed_adult_rate"]'));
    fd.append('extra_bed_adult_auto_total_rate', (document.querySelector('[data-role="amount-auto-eb_adult"]')?.textContent || '0'));

    fd.append('extra_bed_child_auto_count', inputVal('[name="auto_extra_bed_child_count"]'));
    fd.append('extra_bed_child_auto_rate', inputVal('[name="auto_extra_bed_child_rate"]'));
    fd.append('extra_bed_child_auto_total_rate', (document.querySelector('[data-role="amount-auto-eb_child"]')?.textContent || '0'));

    fd.append('child_sharing_bed_auto_count', inputVal('[name="auto_child_sharing_bed_count"]'));
    fd.append('child_sharing_bed_auto_rate', inputVal('[name="auto_child_sharing_bed_rate"]'));
    fd.append('child_sharing_bed_auto_total_rate', (document.querySelector('[data-role="amount-auto-sb_child"]')?.textContent || '0'));

    fd.append('single_occupancy_auto_count', inputVal('[name="auto_single_occupancy_count"]'));
    fd.append('single_occupancy_auto_rate', inputVal('[name="auto_single_occupancy_rate"]'));
    fd.append('single_occupancy_auto_total_rate', (document.querySelector('[data-role="amount-auto-sgl"]')?.textContent || '0'));

    fd.append('supplyment_auto_cost', inputVal('[name="auto_supplment_cost"]'));
    fd.append('supplyment_auto_total_cost', (document.querySelector('[data-role="amount-auto-supplement"]')?.textContent || '0'));

    // Manual inputs
    fd.append('room_unit_manual_count', inputVal('[name="manual_count"]'));
    fd.append('room_unit_manual_rate', inputVal('[name="manual_rate"]'));
    fd.append('room_unit_manual_total_rate', (document.querySelector('[data-role="amount-manual-rooms"]')?.textContent || '0'));

    fd.append('extra_bed_adult_manual_count', inputVal('[name="manual_extra_bed_adult_count"]'));
    fd.append('extra_bed_adult_manual_rate', inputVal('[name="manual_extra_bed_adult_rate"]'));
    fd.append('extra_bed_adult_manual_total_rate', (document.querySelector('[data-role="amount-manual-eb_adult"]')?.textContent || '0'));

    fd.append('extra_bed_child_manual_count', inputVal('[name="manual_extra_bed_child_count"]'));
    fd.append('extra_bed_child_manual_rate', inputVal('[name="manual_extra_bed_child_rate"]'));
    fd.append('extra_bed_child_manual_total_rate', (document.querySelector('[data-role="amount-manual-eb_child"]')?.textContent || '0'));

    fd.append('child_sharing_bed_manual_count', inputVal('[name="manual_child_sharing_bed_count"]'));
    fd.append('child_sharing_bed_manual_rate', inputVal('[name="manual_child_sharing_bed_rate"]'));
    fd.append('child_sharing_bed_manual_total_rate', (document.querySelector('[data-role="amount-manual-sb_child"]')?.textContent || '0'));

    fd.append('single_occupancy_manual_count', inputVal('[name="manual_single_occupancy_count"]'));
    fd.append('single_occupancy_manual_rate', inputVal('[name="manual_single_occupancy_rate"]'));
    fd.append('single_occupancy_manual_total_rate', (document.querySelector('[data-role="amount-manual-sgl"]')?.textContent || '0'));

    fd.append('supplyment_manual_cost', inputVal('[name="manual_supplment_cost"]'));
    fd.append('supplyment_manual_total_cost', (document.querySelector('[data-role="amount-manual-supplement"]')?.textContent || '0'));

    // totals
    fd.append('auto_total_rate', (document.querySelector('[data-role="total-auto"]')?.textContent || '0'));
    fd.append('manual_total_rate', (document.querySelector('[data-role="total-manual"]')?.textContent || '0'));

    fetch(`<?php echo base_url(); ?>index.php/Quotation/ajax_add_quotation_room_tariff_details`, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        if (!res.status) {
            alert(res.message || 'Save failed');
            return;
        }

        // ✅ Update Auto Calculated Rate in the row of the clicked edit button
        const autoTotal = parseFloat(res.auto_total_rate || 0).toFixed(2);


        // if (window.__lastRoomEditBtn) {
        //     const tr = window.__lastRoomEditBtn.closest('tr');
        //     const rateText  = tr?.querySelector('.autoCalcRateText');
        //     const rateInput = tr?.querySelector('.autoCalcRateInput');

        //     const autoTotal = parseFloat(res.auto_total_rate || 0).toFixed(2);

        //     if (rateText)  rateText.textContent = autoTotal;
        //     if (rateInput) rateInput.value = autoTotal;
        // }

//         if (window.__lastRoomEditBtn) {
//             const tr = window.__lastRoomEditBtn.closest('tr');
//             const rateText  = tr?.querySelector('.autoCalcRateText');
//             const rateInput = tr?.querySelector('.autoCalcRateInput');

//             // res should return both totals from backend
//             const manualTotal = parseFloat(res.manual_total_rate || 0) || 0;
//             const autoTotal   = parseFloat(res.auto_total_rate || 0) || 0;

//             // ✅ priority: manual > auto
//             const finalTotal = (manualTotal > 0 ? manualTotal : autoTotal).toFixed(2);

//             if (rateText)  rateText.textContent = finalTotal;
//             if (rateInput) rateInput.value = finalTotal;

//             // refreshQuoteSummaryTotals();

//             const optionBlock = window.__lastRoomEditBtn.closest('.optionBlock');
// if (optionBlock) {
//   recalcOptionTotals(optionBlock);
// }


//         }

        if (window.__lastRoomEditBtn) {
  const tr = window.__lastRoomEditBtn.closest('tr');
  const rateText  = tr?.querySelector('.autoCalcRateText');
  const rateInput = tr?.querySelector('.autoCalcRateInput');

  // ✅ IMPORTANT: use MANUAL total if you want manual to be final
  const manualTotal = num(document.querySelector('#manual_total_rate')?.value || 0);
  const finalTotal  = manualTotal > 0 ? manualTotal : num(document.querySelector('#auto_total_rate')?.value || 0);

  const val = finalTotal.toFixed(2);

  if (rateText)  rateText.textContent = val;
  if (rateInput) rateInput.value = val;

  // ✅ NOW recalc the totals for this option block
  const optionBlock = window.__lastRoomEditBtn.closest('.optionBlock');
  if (optionBlock) recalcOptionTotals(optionBlock);
}


        // close modal
        const modalEl = document.getElementById('roompricingandguestallocationModal');
        bootstrap.Modal.getInstance(modalEl)?.hide();
    })
    .catch(err => {
        console.error(err);
        alert('Server error');
    });

});



/* ================= READ VALUES ================= */

/**
 * If you have multiple optionBlocks, we calculate totals using the ACTIVE option.
 * ACTIVE = the optionBlock that user is working on (has selected package option)
 * If you want "highest room among ALL options", change getActiveOptionBlock().
 */
function getActiveOptionBlock() {
  // Best-effort: choose first visible optionBlock
  const blocks = Array.from(document.querySelectorAll('.optionBlock'));
  if (!blocks.length) return null;

  // If you mark active one with class, prefer that:
  const active = document.querySelector('.optionBlock.active');
  if (active) return active;

  // Otherwise take first:
  return blocks[0];
}

function getCabCost() {
  const optionBlock = getActiveOptionBlock();
  if (!optionBlock) return 0;

  const cabEl = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');
  return toNumber(cabEl ? cabEl.value : 0);
}

function getHighestRoomRate() {
  const optionBlock = getActiveOptionBlock();
  if (!optionBlock) return 0;

  let maxRate = 0;

  // Room rows have hidden input .autoCalcRateInput (your plan)
  optionBlock.querySelectorAll('.autoCalcRateInput').forEach(inp => {
    const v = toNumber(inp.value);
    if (v > maxRate) maxRate = v;
  });

  // If you don't have inputs in some rows, also try text
  optionBlock.querySelectorAll('.autoCalcRateText').forEach(span => {
    const v = toNumber(span.textContent);
    if (v > maxRate) maxRate = v;
  });

  return maxRate;
}

function getInclusionTotal() {
  let total = 0;
  document.querySelectorAll('[name="inclusion_amount[]"]').forEach(inp => {
    total += toNumber(inp.value);
  });
  return total;
}

function getSpecialReqTotal() {
  let total = 0;
  document.querySelectorAll('[name="special_requirements_cost[]"], .specialReqCost').forEach(inp => {
    total += toNumber(inp.value);
  });
  return total;
}

function getMarginAmount(totalCost) {
  const type = document.getElementById('marginType')?.value || 'amount';
  const value = toNumber(document.getElementById('marginValue')?.value);

  if (type === 'percent') {
    return (totalCost * value) / 100;
  }
  return value;
}

/* ================= MAIN CALC ================= */

function refreshQuoteSummaryTotals() {
  const cab = getCabCost();
  const highestRoom = getHighestRoomRate();
  const inclusionTotal = getInclusionTotal();
  const specialReqTotal = getSpecialReqTotal();

  const totalCost = cab + highestRoom + inclusionTotal + specialReqTotal;
  const marginAmount = getMarginAmount(totalCost);
  const totalQuote = totalCost + marginAmount;

  // UI text
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = money(val);
  };

  setText('cabCostText', cab);
  setText('highestRoomText', highestRoom);
  setText('inclusionTotalText', inclusionTotal);
  setText('specialReqTotalText', specialReqTotal);
  setText('marginAmountText', marginAmount);

  setText('totalCostText', totalCost);
  setText('totalQuoteText', totalQuote);

  // Hidden inputs for save
  const totalCostInp = document.getElementById('total_cost');
  const marginInp = document.getElementById('margin_amount');
  const totalQuoteInp = document.getElementById('total_quote_rate');

  if (totalCostInp) totalCostInp.value = money(totalCost);
  if (marginInp) marginInp.value = money(marginAmount);
  if (totalQuoteInp) totalQuoteInp.value = money(totalQuote);
}

/* ================= LIVE UPDATES ================= */

// Any typing in Cab / Inclusion / Special Req should recalc
document.addEventListener('input', function (e) {
  const t = e.target;

  if (
    t.matches('[name="quotation_options_cab_amount[]"]') ||
    t.matches('[name="inclusion_amount[]"]') ||
    t.matches('[name="special_requirements_cost[]"]') ||
    t.closest('.specialReqCost') ||
    t.id === 'marginValue'
  ) {
    refreshQuoteSummaryTotals();
  }
});

// Margin type change
document.addEventListener('change', function (e) {
  const t = e.target;
  if (t && t.id === 'marginType') refreshQuoteSummaryTotals();
});


/* ===== GLOBAL HELPERS ===== */
function num(v) {
  const n = parseFloat(v);
  return isNaN(n) ? 0 : n;
}

/* Highest room auto-calculated rate per day (sum of max per day) */
function calculateHighestRoomRatePerDay(optionBlock) {
  const dayMax = {}; // {dayId: maxRate}

  optionBlock.querySelectorAll('.autoCalcRateInput').forEach(input => {
    const tr = input.closest('tr');
    const dayId = tr?.getAttribute('data-day-id');
    if (!dayId) return;

    const rate = num(input.value);

    if (dayMax[dayId] === undefined || rate > dayMax[dayId]) {
      dayMax[dayId] = rate;
    }
  });

  return Object.values(dayMax).reduce((a, b) => a + b, 0);
}


function recalcOptionTotals(optionBlock) {
  if (!optionBlock) return;

  const cabInput = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');
  const cabAmount = num(cabInput?.value);

  const roomsTotal = calculateHighestRoomRatePerDay(optionBlock);
  const totalCost = cabAmount + roomsTotal;

  const costText  = optionBlock.querySelector('.optionTotalCostText');
  const costInput = optionBlock.querySelector('.optionTotalCostInput');
  if (costText)  costText.textContent = totalCost.toFixed(2);
  if (costInput) costInput.value = totalCost.toFixed(2);

  const marginTypeEl  = optionBlock.querySelector('.optionMarginType');
  const marginValueEl = optionBlock.querySelector('.optionMarginValue');

  const marginType  = marginTypeEl ? marginTypeEl.value : 'amount';
  const marginValue = num(marginValueEl?.value);

  let marginAmount = 0;
  if (marginType === 'percent') marginAmount = (totalCost * marginValue) / 100;
  else marginAmount = marginValue;

  const quoteTotal = totalCost + marginAmount;

  const quoteText  = optionBlock.querySelector('.optionQuoteTotalText');
  const quoteInput = optionBlock.querySelector('.optionQuoteTotalInput');
  if (quoteText)  quoteText.textContent = quoteTotal.toFixed(2);
  if (quoteInput) quoteInput.value = quoteTotal.toFixed(2);
}

/* ===== LIVE RECALC TRIGGERS ===== */
document.addEventListener('input', function (e) {
  // cab amount
  if (e.target.name === 'quotation_options_cab_amount[]') {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }

  // margin value
  if (e.target.classList.contains('optionMarginValue')) {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }
});

document.addEventListener('change', function (e) {
  // margin type
  if (e.target.classList.contains('optionMarginType')) {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }
});


// Status options
const QUOTATION_STATUSES = [
  { id: 1, text: 'Generated' },
  { id: 2, text: 'Draft' },
  { id: 3, text: 'Sent' },
  { id: 4, text: 'Rejected' },
  { id: 5, text: 'Accepted' }
];

// function initStatusSelect2() {
//   const $el = $('#quotation_current_status');

//   // destroy old select2 if already applied
//   if ($el.hasClass('select2-hidden-accessible')) {
//     $el.select2('destroy');
//   }

//   $el.empty().append('<option value="">Select Status</option>');
//   QUOTATION_STATUSES.forEach(s => {
//     $el.append(`<option value="${s.id}">${s.text}</option>`);
//   });

//   // IMPORTANT: dropdownParent for modal (fix cursor/search typing)
//   $el.select2({
//     width: '100%',
//     dropdownParent: $('#ChangeStatusModal'),
//     placeholder: 'Select Status',
//     allowClear: true,
//     minimumResultsForSearch: 0
//   });
// }

function change_status(quotationId) {
  if (!quotationId) return;

  // reset form
  $('#changeStatusForm')[0].reset();
  $('#quotation_id').val(quotationId);

  // fill select
  const $status = $('#quotation_current_status');
  $status.empty().append('<option value="">Select Status</option>');

  QUOTATION_STATUSES.forEach(s => {
    $status.append(`<option value="${s.id}">${s.text}</option>`);
  });

  // init select2 properly inside modal
  if ($status.hasClass('select2-hidden-accessible')) {
    $status.select2('destroy');
  }

  $status.select2({
    width: '100%',
    dropdownParent: $('#ChangeStatusModal'),
    placeholder: 'Select Status',
    allowClear: true
  });

  // open modal (Bootstrap 4)
  // $('#ChangeStatusModal').modal({
  //   backdrop: 'static',
  //   keyboard: false
  // });
$('#ChangeStatusModal').modal('show'); // show bootstrap modal
  // fetch current status
  $.getJSON(
    "<?php echo base_url(); ?>index.php/Quotation/ajax_get_quotation_status",
    { quotation_id: quotationId },
    function (res) {
      if (res.status) {
        $('#quotation_current_status')
          .val(res.data.quotation_current_status)
          .trigger('change');
      }
    }
  );
}


function saveChangeStatus() {
  const quotationId = $('#quotation_id').val();
  const status = $('#quotation_current_status').val();

  if (!status) {
    alert('Please select status');
    return;
  }

  $.ajax({
    url: "<?php echo base_url(); ?>index.php/Quotation/ajax_update_quotation_status",
    type: "POST",
    dataType: "JSON",
    data: {
      quotation_id: quotationId,
      quotation_current_status: status
    },
    success: function (res) {
      if (res.status) {
        $('#ChangeStatusModal').modal('hide');
        reload_table_status();
      } else {
        alert('Failed to update status');
      }
    },
    error: function () {
      alert('Server error');
    }
  });
}



document.getElementById('leads_id').addEventListener('change', function () {
  document.getElementById('selected_lead_id').value = this.value || '';
});

$(document).ready(function() {
    $('#leads_id').change(function() {
    //alert("oo");
          var leads_id = $('#leads_id').val();
          $.ajax({
              url: "<?php echo base_url(); ?>index.php/Quotation/packageid_underlead/"+leads_id,
              dataType: 'json',
              type: 'POST',
              success:
              function(data) {

                packages_id = data['package_id_fk'];
                // alert(packages_id);

                 if(packages_id != '') {
                  $.ajax({
                      url: "<?php echo base_url(); ?>index.php/Quotation/fetch_package_under_lead",
                      method: "POST",
                      data: {
                          packages_id: packages_id
                      },
                      success: function(data) {
                          $('#packages_id_fk').html(data);
                          // $('#city').html('<option value="">Select City</option>');
                      }
                  });
                  } else {
                      $('#packages_id_fk').html('<option value="0">Please Select Package</option>');
                      // $('#city').html('<option value="">Select City</option>');
                  }
                
                  }
            
          });

    
       

    });
});
</script>