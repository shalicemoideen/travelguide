<script>
////***Date picker *****///
$('#quotation_date').bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: 'DD/MM/YYYY'
}).bootstrapMaterialDatePicker('setDate', moment());

$('#start_date1').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });

$('#end_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });
$('#leads_start_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });

$('#leads_end_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });
$('#travels_start_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });

$('#travels_end_date').bootstrapMaterialDatePicker({
         weekStart: 0,
        time: false,
        format: 'DD/MM/YYYY'
    });
////***Date picker *****///

////***Filter button hide and show*****///

$(document).ready(function () {
    $("#btn").click(function () {
        $("#Create").toggle();
    });
});

$(document).ready(function () {
    $("#btn1").click(function () {
        $("#Create1").toggle();
    });
});

$(document).ready(function () {
    $("#btn2").click(function () {
        $("#Create2").toggle();
    });
});


////***Filter button hide and show*****///

////***Latest dropdown select2*****///

$("#lead_type1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#staff_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#source_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#package_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#country_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#priority_status_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#stage_id_fk1").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#country_id_fk").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#priority_status_id_fk").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#stage_id_fk").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#date_type").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#package_id_fk").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});
$("#agent_id_fk").select2({
  dropdownParent: $("#LeadsModal"),
  minimumResultsForSearch: 0
});


////***Latest dropdown select2*****///

////***searching button*****///

$('#search').click(function () {
        
        $table.ajax.reload();
    });

$( "#guest_name_filter" ).keypress(function() {
            $table.ajax.reload();
});

$( "#whats_number_filter" ).keypress(function() {
            $table.ajax.reload();
});



$('#search1').click(function () {
        
        $table1.ajax.reload();
    });

$('#search2').click(function () {
        
        $table2.ajax.reload();
    });

// $( "#b2b_partner_person_name1" ).keypress(function() {
//             $table.ajax.reload();
// });

////***searching button*****///


////***ajax hide & show on view page*****///
$(document).ready(function() {
    $(".panel-body a").on('click', function(e) {
        e.preventDefault()
        var page = $(this).data('page');
        $("#pages .page:not('.hide')").stop().fadeOut('fast', function() {
            $(this).addClass('hide');
            $('#pages .page[data-page="'+page+'"]').fadeIn('slow').removeClass('hide');
        });
    });
});

////***ajax hide & show on view page*****///

////***Leads details on view*****///  

function Tariff_details(id){
    // var conf = confirm("Do you want to Edit details?");
    // if(conf){
        $('#Tariff_details').html();
        $.ajax({
        url:"<?php echo base_url();?>index.php/Room_tariff_management/get_data",
        type: 'POST',
        data:{id:id},
        dataType: 'json',
        success:
        function(data)
        {
             //alert(data['id']);
               document.getElementById('Id').value=data['room_tariff_hike_id'];
                //$("#properties_name").html(data['properties_name']);
                
               
               
            
        },
        
        error:function(e){
        console.log("error");
        }
      
      });
      $('.nav-link').removeClass('active');
      $('#Tariff_details').addClass('active');
}

////***Leads details on view*****///

////***Room category details*****///

function Hike_tariff_details(id){
    // alert(id);
    //var id = document.getElementById('Id').value;
    $table1 = $('#Hike_room_tariff_registration').DataTable( {
        "searching": false,
        "processing": true,
        "serverSide": true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "bDestroy" : true,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        // aLengthMenu: [
          // [1, 2],
          // [1, 2]
        // ],
        // iDisplayLength: 1,
        dom: 'lBfrtip',
            buttons: [
                
                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Hike room tariff details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Hike room tariff details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5, 6]
                                    },
                                    title: 'Hike room tariff details',
                                    customize: function ( win ) {
                                    $(win.document.body)
                                        .css( 'font-size', '10pt' )
                                        .prepend(
                                            // '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                                        );

                                    $(win.document.body).find( 'table' )
                                        .addClass( 'compact' )
                                        .css( 'font-size', 'inherit' );
                                    },
                                },
                
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Room_tariff_management/get_hikeRoomtariff/"+id,
            "type": "POST",
            "data" : function (d) {
                        d.properties_id = $("#properties_id").val();
                        d.property_category_id_fk = $("#property_category_id_fk").val();
                        d.properties_room_category_id = $("#properties_room_category_id").val();
                        d.room_tariff_hike_createdby_user_id = $("#room_tariff_hike_createdby_user_id").val();
                        d.start_date = $("#start_date").val();
                        d.end_date = $("#end_date").val();
                        
                        
           }
        },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table1.column(0).nodes().each(function(node,index,dt){
            $table1.cell(node).data(index+1);
            });
            
           $('td', row).eq(7).html('<div class="d-flex"><a href="javascript:void(0)" id="rt" onclick="edit_room('+data['properties_room_category_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_room('+data['properties_room_category_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a></div>');

           },

        "columns": [
            { "data": "hike_room_tariff_hike_status", "orderable": false },
            { "data": "properties_name", "orderable": false },
            { "data": "hike_room_tariff_hike_from_date", "orderable": false },
            { "data": "hike_room_tariff_hike_to_date", "orderable": false },
            { "data": "hike_room_tariff_hike_description", "orderable": false },
            { "data": "hike_room_tariff_hike_createdby_user_name", "orderable": false },                      
            { "data": "hike_room_tariff_hike_id", "orderable": false }
            
   
        ]
        
    } );
    
    $('.nav-link').removeClass('active');
    $('#Hike_tariff_details').addClass('active');
    
  }
    
 
////***Hike tariff details*****///

////***Latest Jquery form validation for adding form*****///
        
$("#form").validate({
            debug: true,
            validClass: "success",
            rules: {
                    
                    // booking_work_order_end_date: { greaterThan: "#booking_work_order_date" }
                
            },
            messages: {
                
            },
            
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('input-success-o').addClass('input-warning-o');
            },
            unhighlight: function(element) {
                $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('input-warning-o').addClass('input-success-o');
            },

        });

////***Latest Jquery form validation for adding form*****///


////***Listing table*****///

var save_method; //for save method string
var table;
  $(document).ready(function() {
    
    
    $table = $('#Leads_table').DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // "bDestroy" : true,
        dom: 'lBfrtip',
            buttons: [
                
                                {
                                    extend: 'excel',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5]
                                    }
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions: {
                                        columns: [0, 1, 2, 3, 4, 5]
                                    }
                                },
                                {
                                    extend: 'print',
                                    exportOptions: {
                                        columns: [0 ,1, 2, 3, 4, 5]
                                    }
                                },
                               
            ],
        "ajax": {
            "url": "<?php echo base_url();?>index.php/Leads/get/",
            "type": "POST",
            "data" : function (d) {
                        d.staff_id = $("#staff_id").val();
                        d.source_id = $("#source_id").val();
                        d.packages_id = $("#packages_id").val();
                        d.country_id = $("#country_id").val();
                        d.priority_status_id = $("#priority_status_id").val();
                        d.stages_id = $("#stages_id").val();
                        d.lead_type = $("#lead_type").val();
                        d.guest_name_filter = $("#guest_name_filter").val();
                        d.whats_number_filter = $("#whats_number_filter").val();
                        d.leads_createdby_userid = $("#leads_createdby_userid").val();
                        d.leads_start_date = $("#leads_start_date").val();
                        d.leads_end_date = $("#leads_end_date").val();
                        d.travels_start_date = $("#travels_start_date").val();
                        d.travels_end_date = $("#travels_end_date").val();
           }            
        },
        // "ajax": {
            // "url": "<?php echo site_url('States/get')?>",
            // "type": "POST"
        // },
        "createdRow": function ( row, data, index ) {
          
//            $('td',row).eq(0).html(index+1);
           $table.column(0).nodes().each(function(node,index,dt){
            $table.cell(node).data(index+1);
            });
            
            

            // $('td', row).eq(5).html('<div class="form-button-action"><a  data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task" href="javascript:void(0)" onclick="edit_role('+data['roles_id']+')"><i class="fa fa-edit"></i></a><button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove" href="javascript:void(0)" onclick="return delete_role('+data['roles_id']+')"><i class="fa fa-times"></i></button></div>');

            // $('td', row).eq(6).html('<div class="d-flex"><a href="javascript:void(0)" onclick="edit_room_tariff('+data['room_tariff_hike_id']+')" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a><a href="javascript:void(0)" onclick="return delete_room_tariff('+data['room_tariff_hike_id']+')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a></div>');

            // if(data['leads_accomodation_status'] == 0){

            //   $('td', row).eq(13).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="openChangeStatusModal('+data['leads_id']+')">Change status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="showStatusModal('+data['leads_id']+')">Show status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_room_tariff('+data['room_tariff_hike_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_room_tariff('+data['room_tariff_hike_id']+')">Delete</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="guset_count('+data['leads_id']+')">Guest count</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="accomodation_plan('+data['leads_id']+')">Accomodation plan</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Room_tariff_management/View/'+data['room_tariff_hike_id']+'" >View Details</a></div></div>');
            // }
            
            //  if(data['leads_accomodation_status'] == 1){
              
            //   $('td', row).eq(13).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="openChangeStatusModal('+data['leads_id']+')">Change status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="showStatusModal('+data['leads_id']+')">Show status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_room_tariff('+data['room_tariff_hike_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_room_tariff('+data['room_tariff_hike_id']+')">Delete</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="guset_count_edit('+data['leads_id']+')">Guest count</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="accomodation_plan('+data['leads_id']+')">Accomodation plan</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Room_tariff_management/View/'+data['room_tariff_hike_id']+'" >View Details</a></div></div>');
            //  }

            //  if(data['leads_accomodation_status'] == 2){
              
              $('td', row).eq(13).html('<div class="dropdown ms-auto text-end"><div class="btn-link" data-bs-toggle="dropdown"><svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></div><div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="openChangeStatusModal('+data['leads_id']+')">Change status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="showStatusModal('+data['leads_id']+')">Show status</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="open_quotation('+data['leads_id']+')">Quotation</a><a class="dropdown-item" href="javascript:void(0)" id="rt" onclick="edit_room_tariff('+data['room_tariff_hike_id']+')">Edit</a><a class="dropdown-item" href="javascript:void(0)" onclick="return delete_room_tariff('+data['room_tariff_hike_id']+')">Delete</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="guset_count_edit('+data['leads_id']+')">Guest count</a><a class="dropdown-item" href="javascript:void(0)" id="rt"  onclick="accomodation_plan('+data['leads_id']+')">Accomodation plan</a><a class="dropdown-item" href="<?php echo base_url();?>index.php/Room_tariff_management/View/'+data['room_tariff_hike_id']+'" >View Details</a></div></div>');
            //  }
            
            
           },

           "drawCallback": function( settings ) {
                // displaySelectByUserType();
            },

        "columns": [
            { "data": "leads_status", "orderable": false },
            { "data": "lead_type", "orderable": false },
            { "data": "leads_number", "orderable": false },
            { "data": "guest_name", "orderable": false },
            { "data": "whats_number", "orderable": false },
            { "data": "lead_register_date", "orderable": false },
            { "data": "start_date", "orderable": false },
            { "data": "duration", "orderable": false },
            { "data": "end_date", "orderable": false },
            { "data": "packages_title", "orderable": false },
            { "data": "stages_button", "orderable": false },
            { "data": "priority_status_button", "orderable": false },
            { "data": "leads_createdby_username", "orderable": false },                      
            { "data": "leads_id", "orderable": false }
            
            
        ]
        
    });
    
  

  });
    
 
////***Listing table*****///

////***For close the modal *****///
function Leadsmodalclose()
{

    $('#LeadsModal').modal('hide');
     $('#form')[0].reset();
    $('#form').removeClass('was-validated');
    //$( "div" ).remove( ".modal-backdrop" );
    $('#staff_id_fk1').val('');
    $('#guest_name1').val('');
    $('#source_id_fk').val('').change();
    // $('#vehicle_id_fk').val('0').change();
    $('#category_name_alert').hide();
    $('.submit').removeAttr('disabled');
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.staff_id_fk1').removeClass('input-success-o');
    $('.staff_id_fk1').removeClass('input-warning-o');
    $('.guest_name1').removeClass('input-success-o');
    $('.guest_name1').removeClass('input-warning-o');
    // $('#btnSave').removeAttr('disabled');
}
////***For close the modal *****///

////***For open the modal *****///
$('#LeadsModal').on('shown.bs.modal', function () {
    // $("#state_id_fk").select2('open');
    // $('#transporter_name').focus();
    var id = $("#id").val();
    if(id == '')
    { 
        $('#properties_id_fk').val('').change();
        // $('#vehicle_id_fk').val('0').change();
    }
    $('#category_name_alert').hide();
    // $(".submit").attr("disabled", "disabled");
    $('.form-group').removeClass('input-success-o');
    $('.form-group').removeClass('input-warning-o');
    $('.properties_id_fk').removeClass('input-success-o');
    $('.properties_id_fk').removeClass('input-warning-o');
    $('.room_tariff_hike_from_date').removeClass('input-success-o');
    $('.room_tariff_hike_from_date').removeClass('input-warning-o');
})
////***For open the modal *****///
    
////***For open modal of leads adding form  *****///
    
function add_leads()
{ 
    save_method = 'add';
    $("#id").val('');
    $('#form')[0].reset(); // reset form on modals
    $('#form').removeClass('was-validated');
    //  resetSelect2Validation();
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#LeadsModal').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add leads Details'); // Set Title to Bootstrap modal title
    $('#btnSave').text('save');
    var selectedValue = $("#lead_type1 option:selected").val();
    if(selectedValue=="B2C")
    {
    // alert("oo");
    $('.staff_id_fk1').show();
    $('.source_id_fk').show();
    $('.guest_name').show();
    $('.country_id_fk').show();
    $('.whats_number').show();
    $('.alternative_number').show();
    $('.priority_status_id_fk').show();
    $('.stage_id_fk').show();
    $('.date_type').show();
    $('.stage_id_fk').show();
    $('#hidden5').show();
    $('.agent_id_fk').hide();
    $('.total_package_cost').hide();
    $('.expense').hide();
    $('.margin').hide();
    $('.description').hide();
    }
}

////***For open modal of leads adding form  *****///

////***For editing room leads details from adding modal form  *****///

function edit_leads(id)
{
    var num_2 = 1;
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('input-warning-o'); // clear error class
    $('.help-block').empty(); // clear error string

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url();?>index.php/Leads/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
         // .trigger('change.select2')
            
            $('[name="id"]').val(data.leads_id);
            $('[name="lead_type"]').val(data.lead_type);
            $('[name="staff_id_fk"]').val(data.staff_id_fk);
            $('[name="source_id_fk"]').val(data.source_id_fk);
            $('[name="guest_name"]').val(data.guest_name);
            $('[name="agent_id_fk"]').val(data.agent_id_fk);  
            $('[name="total_package_cost"]').val(data.total_package_cost); 
            $('[name="expense"]').val(data.expense);
            $('[name="country_id_fk"]').val(data.country_id_fk);
            $('[name="priority_status_id_fk"]').val(data.priority_status_id_fk);
            $('[name="stage_id_fk"]').val(data.stage_id_fk);
            $('[name="agent_id_fk"]').val(data.agent_id_fk);
            $('[name="lead_type"]').val(data.lead_type);
            $('[name="guest_name"]').val(data.guest_name);
            $('[name="date_type"]').val(data.date_type);
            $('[name="start_date"]').val(data.start_date);
            $('[name="end_date"]').val(data.end_date);
            $('[name="duration"]').val(data.duration);
            $('[name="whats_number"]').val(data.whats_number);
            $('[name="alternative_number"]').val(data.alternative_number);
            $('[name="total_package_cost"]').val(data.total_package_cost);
            $('[name="expense"]').val(data.expense);
            $('[name="margin"]').val(data.margin);
            $('[name="description"]').val(data.description);
                 
            $('#LeadsModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit leads Details'); // Set title to Bootstrap modal title
            $('#btnSave').text('update');

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

////***For editing leads details from adding modal form  *****///

////***For reload the datatable  *****///
function reload_table_guset_count()
{

    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        swal("Guest count updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room tariff details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Guest count added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Transporter details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
}
function reload_table()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        swal("Leads details updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room tariff details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Leads details added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Transporter details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

function reload_table_guest_count()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#guset_count_id").val();
    if(id)
    {  

        swal("Guest count details updated successfully", "", "success")
        
    }
    else{
        
        swal("Guest count details added successfully", "", "success")

        
    }
    
    
}

function reload_table_accomodation()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#accommodation_plan_guset_count_id_fk").val();
    if(id)
    {  

        swal("Accommodation details updated successfully", "", "success")
        
    }
    else{
        
        swal("Accommodation details added successfully", "", "success")

        
    }
    
    
}

////***For reload the datatable  *****///

///***For save the leads details from adding modal form *****///

// function save()
// {
     
//     var url;

//     if(save_method == 'add') {
//         $("#id").val('');
//         $('#btnSave').text('saving...'); //change button text
//         $('#btnSave').attr('disabled',true); //set button disable

//         url = "<?php echo base_url();?>index.php/Leads/ajax_add/";
//     } 
//     else {

//         $('#btnSave').text('updating...'); //change button text
//         $('#btnSave').attr('disabled',true); //set button disable

//         url = "<?php echo base_url();?>index.php/Leads/ajax_update/";
//     }
    
//     var fd = new FormData();
    
//     var form = document.getElementById('form');
//     var data = new FormData(form);
//     // ajax adding data to database
//     $.ajax({
//         url : url,
//         type: "POST",
//         data: data, //$('#form').serialize(),
//         dataType: "JSON",
//         //cache : false,
//         processData: false,
//         enctype: 'multipart/form-data',
//         contentType: false,
//         success: function(data)
//         {

//             if(data.status) //if success close modal and reload ajax table
//             {

//                 $('#LeadsModal').modal('hide');
//                 // $('body').removeClass('modal-open');
//                 // $('.modal-backdrop').remove();


//                 reload_table();
//             }
//             else
//             {
//                 for (var i = 0; i < data.inputerror.length; i++) 
//                 {
//                     $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('input-warning-o'); //select parent twice to select div form-group class and add has-error class
//                     if($('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').length) {
//                         $('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').text(data.error_string[i]); //select span help-block class set text error string
//                     } else {
//                         $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
//                     }
//                 }
//             }
//             $('#btnSave').text('save'); //change button text
//             $('#btnSave').attr('disabled',false); //set button enable 
//             $('.help-block').val('hide');

//         },
//         error: function (jqXHR, textStatus, errorThrown)
//         {
//             alert('Error adding / update data');
//             $('#btnSave').text('save'); //change button text
//             $('#btnSave').attr('disabled',false); //set button enable 

//         }
//     });
// }

// $('.lst-flt-select2-form').select2({
//     placeholder: "Please select",
//     width: '100%',
//     allowClear: true,
// });

function validateSelect2(select) {
    let val = $(select).val();
    let container = $(select).next('.select2-container'); // get the Select2 UI
// alert(val);
    // if(val === "" || val === null) {
    if(val === null || val === "" || (Array.isArray(val) && val.length === 0)) {
        // alert("k");
        container.addClass('is-invalid').removeClass('is-valid');
        return false;
    } else {
        // alert("d");
        container.addClass('is-valid').removeClass('is-invalid');
        return true;
    }
}




function resetValidation() {
    $('#form')[0].reset();
    $('#form').removeClass('was-validated');
    $('.select2-container').removeClass('is-valid is-invalid');
    $('input, textarea').removeClass('is-valid is-invalid');
}

// On modal show
$('#LeadsModal').on('show.bs.modal', resetValidation);

// Optional: validate on change
$('.lst-flt-select2-form').on('change', function() {
    validateSelect2(this);
});

const B2C_FIELDS = [
    'staff_id_fk',
    'source_id_fk',
    'guest_name',
    'country_id_fk',
    'priority_status_id_fk',
    'whats_number',
    'date_type',
    'start_date',
    'duration',
    'package_id_fk'
];

const B2B_FIELDS = [
    'agent_id_fk',
    'total_package_cost',
    'expense',
    'margin'
];

function validateInput(name) {
    let el = $('[name="' + name + '"]');
    let val = el.val();

    if (!val) {
        el.addClass('is-invalid').removeClass('is-valid');
        return false;
    }

    el.addClass('is-valid').removeClass('is-invalid');
    return true;
}


function validateSelect2ByName(name) {
    let el = $('[name="' + name + '"]');
    return validateSelect2(el);
}
function save() {

    let leadType = $('[name="lead_type"]').val();
    let allValid = true;

    // Clear previous validation
    $('.is-valid, .is-invalid').removeClass('is-valid is-invalid');

    // Decide fields to validate
    let fieldsToValidate = [];

    if (leadType === 'B2C') {
        fieldsToValidate = B2C_FIELDS;
    } else if (leadType === 'B2B') {
        fieldsToValidate = B2B_FIELDS;
    }

    // Validate selected fields only
    fieldsToValidate.forEach(name => {
        let el = $('[name="' + name + '"]');

        if (el.hasClass('lst-flt-select2-form')) {
            if (!validateSelect2ByName(name)) allValid = false;
        } else {
            if (!validateInput(name)) allValid = false;
        }
    });

    if (!allValid) return; // 🚫 stop submit

    // ✅ proceed with save
    $('#btnSave').text('saving...').attr('disabled', true);

    let form = document.getElementById('form');
    let data = new FormData(form);
    let url = save_method === 'add'
        ? "<?php echo base_url();?>index.php/Leads/ajax_add/"
        : "<?php echo base_url();?>index.php/Leads/ajax_update/";

    $.ajax({
        url: url,
        type: "POST",
        data: data,
        dataType: "JSON",
        processData: false,
        contentType: false,
        success: function (data) {
            if (data.status) {
                $('#LeadsModal').modal('hide');
                reload_table();
            }
            $('#btnSave').text('save').attr('disabled', false);
        },
        error: function () {
            alert('Error saving data!');
            $('#btnSave').text('save').attr('disabled', false);
        }
    });
}



///***For save the leads details from adding modal form *****///

////***For reload the datatable for delete *****///

function reload_table_delete()
{
    $table.ajax.reload(null,false); //reload datatable ajax
    
    swal("Leads details deleted successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room tariff details deleted successfully";

        //  $("#roles_delete").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
        
}

////***For reload the datatable for delete *****///
    
////***For reload the leads datatable for delete *****///

function delete_leads(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Leads/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.leads_id);
            $('[name="guest_name"]').val(data.guest_name);
            $('#deleterowModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title1').text('Do you want to delete this record?'); // Set title to Bootstrap modal title
            $('#btnSave1').text('delete');
            $('#btnSave1').attr('disabled',false); //set button enable 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}

function delete_leads_action()
{
    $('#btnSave1').text('deleting...'); //change button text
    $('#btnSave1').attr('disabled',true); //set button disable 
    var url;

        url = "<?php echo base_url();?>index.php/Leads/delete/";
        
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form1').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $("#id").val('');
                $('#deleterowModal').modal('hide');
                reload_table_delete();
                // ('body').removeClass('modal-open');
                //$('.modal-backdrop').remove();
                
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    if($('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').length) {
                        $('[name="'+data.inputerror[i]+'"]').parent().find('.help-block').text(data.error_string[i]); //select span help-block class set text error string
                    } else {
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                    }
                }
            }

            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave1').text('save'); //change button text
            $('#btnSave1').attr('disabled',false); //set button enable 

        }
    });
}

////***** For delete the leads details from  database *****///


// function accomodation_plan(id)
// {
//      $.ajax({
//         url : "<?php echo base_url();?>index.php/Leads/ajax_edit/" + id,
//         type: "GET",
//         dataType: "JSON",
//         success: function(data)
//         {

//             $('[name="guset_count_lead_id_fk"]').val(data.leads_id);
//             $('[name="guset_count_package_id_fk"]').val(data.package_id_fk);
//             $('#accomodation_planModal').modal('show'); // show bootstrap modal when complete loaded
//             $('.modal-title1').text('Add Accomodation Plan Details'); // Set title to Bootstrap modal title
//             $('#btnSave').text('save'); 

//         },
//         error: function (jqXHR, textStatus, errorThrown)
//         {
//             alert('Error get data from ajax');
//         }
//     });
    
//     // $('#deleterowModal').modal('show'); // show bootstrap modal
//         // ajax delete data to database 
// }

function accomodation_plan(id)
{
  $.ajax({
    url: "<?php echo base_url('index.php/Leads/ajax_accommodation_plan/'); ?>" + id,
    type: "GET",
    dataType: "JSON",
    success: function (res) {

      $('#lead_id_fk').val(res.lead.leads_id);
      $('#pacakage_id_fk').val(res.lead.package_id_fk);

      let tbody = $('#accommodationTableBody');
      tbody.empty();

      $.each(res.days, function (i, day) {

        // ✅ existing record for this day_id (if saved earlier)
        // IMPORTANT: day.packages_itinerary_days_id must match accommodation_plan.day_id_fk
        const ex = res.existing && res.existing[day.packages_itinerary_days_id]
          ? res.existing[day.packages_itinerary_days_id]
          : null;

        // choose status (existing takes priority, otherwise use day default)
        const selectedStatus = ex
          ? ex.accomodation_required_staus
          : (day.accomodation_required_staus || '');

        const selectedDestination = ex ? ex.stay_destination_id_fk : '';
        const selectedMeal        = ex ? ex.meal_plan_id_fk : '';
        const selectedPax         = ex ? ex.guset_count_details_id_fk : '';

        // Destination options
        let destinationOptions = '<option value="">Select Destination</option>';
        $.each(res.destinations, function (_, d) {
          let sel = (String(d.state_id) === String(selectedDestination)) ? 'selected' : '';
          destinationOptions += `<option value="${d.state_id}" ${sel}>${d.state_name}</option>`;
        });

        // Meal options
        let mealOptions = '<option value="">Select Meal Plan</option>';
        $.each(res.meal_plans, function (_, m) {
          let sel = (String(m.meal_plan_id) === String(selectedMeal)) ? 'selected' : '';
          mealOptions += `<option value="${m.meal_plan_id}" ${sel}>${m.meal_plan_name}</option>`;
        });

        // Pax options
        let paxOptions = '<option value="">Select Pax Plan</option>';
        let singleValue = null;

        $.each(res.pax_plans, function (_, p) {
          let sel = (String(p.guset_count_details_id) === String(selectedPax)) ? 'selected' : '';
          paxOptions += `<option value="${p.guset_count_details_id}" ${sel}>
              ${p.pax_count_plan} (${p.adults}A + ${p.children}C)
            </option>`;

          if (p.guset_count_details_type === 'S') {
            singleValue = p.guset_count_details_id;
          }
        });

        const dayLabel = day.packages_itineraries_days_day || ('Day ' + (i+1));

        tbody.append(`
          <tr class="acc-row">
            <td>
              <input type="hidden" name="itinerary_day_id[]" value="${day.packages_itinerary_days_id}">
              <input type="hidden" name="day[]" value="${dayLabel}">
              <span class="fw-semibold">${dayLabel}</span>
            </td>

            <td>
              <div class="field-wrap">
                <select name="accommodation_status[]" class="form-control acc-status lst-flt-select2">
                  <option value="">Select</option>
                  <option value="R" ${selectedStatus==='R'?'selected':''}>Required</option>
                  <option value="N" ${selectedStatus==='N'?'selected':''}>Not Required</option>
                </select>
                <span class="state-ico"></span>
              </div>
            </td>

            <td>
              <div class="field-wrap">
                <select name="stay_destination_id[]" class="form-control acc-field lst-flt-select2">
                  ${destinationOptions}
                </select>
                <span class="state-ico"></span>
              </div>
            </td>

            <td>
              <div class="field-wrap">
                <select name="meal_plan_id[]" class="form-control acc-field lst-flt-select2">
                  ${mealOptions}
                </select>
                <span class="state-ico"></span>
              </div>
            </td>

            <td>
              <div class="field-wrap">
                <select name="pax_count_plan_id[]" class="form-control acc-field lst-flt-select2 pax-plan">
                  ${paxOptions}
                </select>
                <span class="state-ico"></span>
              </div>
            </td>
          </tr>
        `);

        // ✅ Apply Same-guest rule (auto-select + disable pax plan)
        const $row = tbody.find('tr.acc-row').last();
        const $paxSelect = $row.find('select[name="pax_count_plan_id[]"]');

        if (singleValue) {
          // if no existing selected pax, force single
          if (!selectedPax) $paxSelect.val(singleValue);
          $paxSelect.prop('disabled', true);
          if (!$paxSelect.next('small').length) {
            $paxSelect.after('<small class="text-muted d-block">Auto-selected single Pax Plan</small>');
          }
        } else {
          $paxSelect.prop('disabled', false);
          $paxSelect.next('small').remove();
        }

        // ✅ If status is N, disable other fields
        if (selectedStatus === 'N') {
          $row.find('.acc-field').prop('disabled', true).val('').trigger('change');
          $row.addClass('table-secondary');
        }
      });

      // select2 inside modal
      initSelect2AccModal();

      // validate + disable save if invalid
      validateAllAccRows();

      $('#accomodation_planModal').modal('show');
    },
    error: function(xhr){
      console.log('AJAX error:', xhr.responseText);
      alert('Failed to load accommodation plan (see console)');
    }
  });
}


function guset_count(id)
{
     $.ajax({
        url : "<?php echo base_url();?>index.php/Leads/ajax_edit/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="guset_count_lead_id_fk"]').val(data.leads_id);
            $('[name="guset_count_package_id_fk"]').val(data.package_id_fk);
            $('#gusetcountModal').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title1').text('Add Guest count Details'); // Set title to Bootstrap modal title
            $('#btnSave').text('save'); 

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    
    // $('#deleterowModal').modal('show'); // show bootstrap modal
        // ajax delete data to database 
}



document.addEventListener('DOMContentLoaded', function () {

  const sameRadio = document.getElementById('ds');
  const diffRadio = document.getElementById('df');
  const addPlanBtn = document.getElementById('addInclusionBtn');
  const saveBtn = document.getElementById('btnSaveGuest');
  const tableBody = document.querySelector('#inclusionTable tbody');

  let planIndex = 1;

  loadSameGuest();

  sameRadio.addEventListener('change', loadSameGuest);
  diffRadio.addEventListener('change', loadDifferentGuest);
  addPlanBtn.addEventListener('click', () => addPlan(true));
  saveBtn.addEventListener('click', saveGuestCount);

  function loadSameGuest() {
    tableBody.innerHTML = '';
    planIndex = 1;
    addPlanBtn.style.display = 'none';
    addPlan(false);
    validateAllPlans(); // ensure save state correct
  }

  function loadDifferentGuest() {
    tableBody.innerHTML = '';
    planIndex = 1;
    addPlanBtn.style.display = 'inline-block';
    addPlan(true);
    validateAllPlans();
  }

  function addPlan(removable) {
    const planNo = planIndex++;

    const paxRow = document.createElement('tr');
    paxRow.classList.add('pax-row');
    paxRow.innerHTML = `
      <td>
        <strong>Plan ${planNo}</strong>
        ${removable ? '<button type="button" class="btn btn-sm btn-danger remove-plan ms-2">×</button>' : ''}
      </td>
      <td><div class="field-wrap"><input type="number" min="0" class="form-control adult" value="0"></div></td>
      <td><div class="field-wrap"><input type="number" min="0" class="form-control child" value="0"></div></td>
      <td class="total text-center">0</td>
    `;
    tableBody.appendChild(paxRow);

    const childRow = document.createElement('tr');
    childRow.classList.add('child-wrapper');
    childRow.innerHTML = `
      <td colspan="4">
        <div class="p-3 bg-light rounded">
          <table class="table table-sm child-table">
            <tbody>
              <tr class="child-row">
                <td><div class="field-wrap"><input type="number" min="0" class="form-control age" placeholder="Age"</div></td>
                <td><div class="field-wrap"><input type="number" min="0" class="form-control count" placeholder="Count"></div></td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <button type="button" class="btn btn-sm btn-success add-child">+ Add new row</button>
          <div class="text-danger error mt-1"></div>
        </div>
      </td>
    `;
    tableBody.appendChild(childRow);

    bindPlanEvents(paxRow, childRow);

    const removeBtn = paxRow.querySelector('.remove-plan');
    if (removeBtn) {
      removeBtn.onclick = () => {
        childRow.remove();
        paxRow.remove();
        validateAllPlans();
      };
    }

    validateAllPlans();
  }

  // ==============================
  // VALIDATION CORE
  // ==============================
  function validateAllPlans() {
    const guestType = document.querySelector('input[name="guest_type"]:checked').value;

    let allOk = true;

    document.querySelectorAll('#inclusionTable tbody tr.pax-row').forEach(paxRow => {
      const childRow = paxRow.nextElementSibling; // child-wrapper
      const ok = validatePlan(paxRow, childRow, guestType);
      if (!ok) allOk = false;
    });

    saveBtn.disabled = !allOk;
    return allOk;
  }

  function validatePlan(paxRow, childRow, guestType) {
    const adultEl = paxRow.querySelector('.adult');
    const childEl = paxRow.querySelector('.child');
    const errEl = childRow.querySelector('.error');
    const childTbody = childRow.querySelector('.child-table tbody');

    const adults = toInt(adultEl.value);
    const children = toInt(childEl.value);

    // requirement: in SAME and DIFFERENT you asked adults and children must be > 0
    if (adults <= 0 || children <= 0) {
      errEl.textContent = 'Adults and Children must be greater than 0';
      return false;
    }

    // child breakup sum(count) <= children (including first default row)
    let used = 0;
    childTbody.querySelectorAll('.count').forEach(c => used += toInt(c.value));

    if (used > children) {
      errEl.textContent = `Child count exceeded (Allowed: ${children})`;
      return false;
    }

    // If OK clear error
    errEl.textContent = '';
    return true;
  }

  function toInt(v) {
    const n = parseInt(v, 10);
    return isNaN(n) ? 0 : n;
  }

  // ==============================
  // PLAN EVENTS
  // ==============================


function guset_count_edit(id) {
  // Add Mode UI reset
  $('#guset_count_id').val(''); // important: empty means INSERT
  $('#ds').prop('checked', true).trigger('change'); // Same default
  // rebuild UI blocks
  // call your function that clears table and adds 1 plan
  // loadSameGuest();
   // ✅ EDIT MODE must fetch existing guest count
    openGuestCountModal(id);
  $('#gusetcountModal').modal('show');
}

// function openGuestCountModal(leadId) {

//   $.ajax({
//     url: "<?php echo site_url('Leads/ajax_get_guest_count'); ?>/" + leadId,
//     type: "GET",
//     dataType: "json",
//     success: function(res){

//       if (!res.status) {
//         alert('Fetch failed');
//         return;
//       }

//       if (!res.exists) {
//         // safety fallback: open as add mode
//         guset_count(leadId);
//         return;
//       }

//       // ✅ set master id (so save will UPDATE)
//       $('#guset_count_id').val(res.master.guset_count_id);

//       // select type
//       if (res.master.guset_count_type === 'D') {
//         $('#df').prop('checked', true);
//       } else {
//         $('#ds').prop('checked', true);
//       }

//       // clear table and rebuild from DB
//       const tbody = document.querySelector('#inclusionTable tbody');
//       tbody.innerHTML = '';
//       planIndex = 1;

//       // show/hide add plan button
//       if (res.master.guset_count_type === 'D') {
//         document.getElementById('addInclusionBtn').style.display = 'inline-block';
//       } else {
//         document.getElementById('addInclusionBtn').style.display = 'none';
//       }

//       // build plans + child breakup
//       res.details.forEach(function(detail, idx){
//         addPlanFromData(detail, idx, res.master.guset_count_type === 'D');
//       });

//       $('#gusetcountModal').modal('show');
//     }
//   });
// }

function openGuestCountModal(leadId) {

  // ✅ ALWAYS set lead id (required by backend)
  $('#guset_count_lead_id_fk').val(leadId);

  $.ajax({
    url: "<?php echo site_url('Leads/ajax_get_guest_count'); ?>/" + leadId,
    type: "GET",
    dataType: "json",
    success: function(res){

      if (!res.status) { alert('Fetch failed'); return; }

      if (!res.exists) {
        guset_count(leadId);
        return;
      }

      // ✅ set package id (required by backend)
      // take it from master record (recommended)
      $('#guset_count_package_id_fk').val(res.master.guset_count_package_id_fk);

      // ✅ set master id (for update endpoint, if you use it)
      $('#guset_count_id').val(res.master.guset_count_id);

      // type selection...
      if (res.master.guset_count_type === 'D') $('#df').prop('checked', true);
      else $('#ds').prop('checked', true);

      // rebuild plans...
      const tbody = document.querySelector('#inclusionTable tbody');
      tbody.innerHTML = '';
      planIndex = 1;

      document.getElementById('addInclusionBtn').style.display =
        (res.master.guset_count_type === 'D') ? 'inline-block' : 'none';

      res.details.forEach(function(detail, idx){
        addPlanFromData(detail, idx, res.master.guset_count_type === 'D');
      });

      $('#gusetcountModal').modal('show');
    }
  });
}


function fillGuestCountModal(res){
  // master id
  document.getElementById('guset_count_id').value = res.master.guset_count_id;

  // select type
  if(res.master.guset_count_type === 'D'){
    document.getElementById('df').checked = true;
    loadDifferentGuest(true); // you’ll adjust loadDifferentGuest to accept "skip default add"
  } else {
    document.getElementById('ds').checked = true;
    loadSameGuest(true);
  }

  // clear table
  const tbody = document.querySelector('#inclusionTable tbody');
  tbody.innerHTML = '';
  planIndex = 1;

  // build each plan
  res.details.forEach((d, idx) => {
    addPlanFromData(d, idx, res.master.guset_count_type === 'D');
  });
}

function addPlanFromData(detail, idx, removable){
  const tbody = document.querySelector('#inclusionTable tbody');
  const planNo = idx + 1;

  const paxRow = document.createElement('tr');
  paxRow.classList.add('pax-row');
  paxRow.innerHTML = `
    <td>
      <strong>${detail.pax_count_plan || ('Plan ' + planNo)}</strong>
      <input type="hidden" name="detail_id[]" class="detail-id" value="${detail.guset_count_details_id}">
      ${removable ? '<button type="button" class="btn btn-sm btn-danger remove-plan ms-2">×</button>' : ''}
    </td>
    <td><input type="number" min="0" class="form-control adult" value="${detail.adults}"></td>
    <td><input type="number" min="0" class="form-control child" value="${detail.children}"></td>
    <td class="total text-center">${detail.total_count}</td>
  `;
  tbody.appendChild(paxRow);

  const childRow = document.createElement('tr');
  childRow.classList.add('child-wrapper');
  childRow.innerHTML = `
    <td colspan="4">
      <div class="p-3 bg-light rounded">
        <table class="table table-sm child-table">
          <tbody></tbody>
        </table>
        <button type="button" class="btn btn-sm btn-success add-child">+ Add new row</button>
        <div class="text-danger error mt-1"></div>
      </div>
    </td>
  `;
  tbody.appendChild(childRow);

  const ctbody = childRow.querySelector('.child-table tbody');

  // render child rows
  if(detail.child_breakup && detail.child_breakup.length){
    detail.child_breakup.forEach(cb => {
      const tr = document.createElement('tr');
      tr.classList.add('child-row');
      tr.innerHTML = `
        <td><input type="number" min="0" class="form-control age" value="${cb.age}"></td>
        <td><input type="number" min="0" class="form-control count" value="${cb.count}"></td>
        <td><button type="button" class="btn btn-sm btn-danger remove-child">×</button></td>
      `;
      ctbody.appendChild(tr);
      // tr.querySelector('.remove-child').onclick = () => tr.remove();
      tr.querySelector('.remove-child').onclick = () => {
        tr.remove();
        validateAllPlans(); // or validatePlanRealtime() if available here
      };

    });
  } else {
    // default row if none
    const tr = document.createElement('tr');
    tr.classList.add('child-row');
    tr.innerHTML = `
      <td><input type="number" min="0" class="form-control age"></td>
      <td><input type="number" min="0" class="form-control count"></td>
      <td></td>
    `;
    ctbody.appendChild(tr);
  }

  // hook add-child + validation + remove-plan (reuse your bindPlanEvents)
  bindPlanEvents(paxRow, childRow);

  const rm = paxRow.querySelector('.remove-plan');
  // if(rm){
  //   rm.onclick = () => { paxRow.remove(); childRow.remove(); };
  // }
  if(rm){
    rm.onclick = () => {
      paxRow.remove();
      childRow.remove();
      validateAllPlans(); // ✅ IMPORTANT
    };
  }

}

function bindPlanEvents(paxRow, childRow) {

  var adult = paxRow.querySelector('.adult');
  var child = paxRow.querySelector('.child');
  var total = paxRow.querySelector('.total');

  var error = childRow.querySelector('.error');
  var childTbody = childRow.querySelector('.child-table tbody');

  function updateTotal(){
    total.textContent = toInt(adult.value) + toInt(child.value);
  }

  function validatePlanRealtime(){
    var ok = true;

    // Adults required > 0
    if (toInt(adult.value) <= 0){
      setInvalid(adult, 'Adults > 0');
      ok = false;
    } else setValid(adult);

    // Children required > 0
    var childrenAllowed = toInt(child.value);
    if (childrenAllowed <= 0){
      setInvalid(child, 'Children > 0');
      ok = false;
    } else setValid(child);

    // Validate each child breakup row
    var used = 0;
    var rowError = false;

    childRow.querySelectorAll('.child-row').forEach(function(r){
      var ageInput = r.querySelector('.age');
      var countInput = r.querySelector('.count');

      if (toInt(ageInput.value) <= 0){
        setInvalid(ageInput, 'Age > 0');
        rowError = true;
      } else setValid(ageInput);

      if (toInt(countInput.value) <= 0){
        setInvalid(countInput, 'Count > 0');
        rowError = true;
      } else setValid(countInput);

      used += toInt(countInput.value);
    });

    if (rowError){
      error.textContent = 'Child age & count are required';
      ok = false;
    } else {
      // EXACT MATCH rule requested
      if (childrenAllowed > 0 && used < childrenAllowed){
        error.textContent = 'Child breakup incomplete (Need: ' + childrenAllowed + ', Given: ' + used + ')';
        // mark all count boxes invalid to guide user
        childRow.querySelectorAll('.count').forEach(function(c){ setInvalid(c, 'Need total = ' + childrenAllowed); });
        ok = false;
      } else if (childrenAllowed > 0 && used > childrenAllowed){
        error.textContent = 'Child count exceeded (Allowed: ' + childrenAllowed + ')';
        childRow.querySelectorAll('.count').forEach(function(c){ setInvalid(c, 'Max ' + childrenAllowed); });
        ok = false;
      } else {
        error.textContent = '';
      }
    }

    // ✅ Remove child row (delegated) + revalidate
    childRow.addEventListener('click', function(e){
      const btn = e.target.closest('.remove-child');
      if(!btn) return;

      const tr = btn.closest('tr.child-row');
      if(!tr) return;

      tr.remove();
      validatePlanRealtime();  // ✅ IMPORTANT
    });

    // Enable/disable save across ALL plans
    validateAllPlansButton();
    return ok;
  }

  function validateAllPlansButton(){
    var allOk = true;
    document.querySelectorAll('#inclusionTable tbody tr.pax-row').forEach(function(pr){
      var cr = pr.nextElementSibling;
      if (!cr) return;

      var a = pr.querySelector('.adult');
      var c = pr.querySelector('.child');
      if (toInt(a.value) <= 0 || toInt(c.value) <= 0) allOk = false;

      // exact match check
      var allowed = toInt(c.value);
      var used = 0;
      cr.querySelectorAll('.child-row .count').forEach(function(x){ used += toInt(x.value); });

      // also require age/count >0
      cr.querySelectorAll('.child-row .age, .child-row .count').forEach(function(x){
        if (toInt(x.value) <= 0) allOk = false;
      });

      if (allowed <= 0 || used !== allowed) allOk = false;
      if (cr.querySelector('.error') && cr.querySelector('.error').textContent.trim() !== '') allOk = false;
    });

    document.getElementById('btnSaveGuest').disabled = !allOk;
  }

  // Realtime listeners
  adult.addEventListener('input', function(){ updateTotal(); validatePlanRealtime(); });
  child.addEventListener('input', function(){ updateTotal(); validatePlanRealtime(); });

  // delegate child age/count typing
  childTbody.addEventListener('input', function(e){
    if (e.target.classList.contains('age') || e.target.classList.contains('count')){
      validatePlanRealtime();
    }
  });

  // Add row
  childRow.querySelector('.add-child').onclick = function(){
    var tr = document.createElement('tr');
    tr.classList.add('child-row');
    tr.innerHTML = `
      <td>
        <div class="field-wrap">
          <input type="number" min="0" class="form-control age" placeholder="Age">
         
        </div>
      </td>
      <td>
        <div class="field-wrap">
          <input type="number" min="0" class="form-control count" placeholder="Count">
          
        </div>
      </td>
      <td><button type="button" class="btn btn-sm btn-danger remove-child">×</button></td>
    `;
    childTbody.appendChild(tr);

    tr.querySelector('.remove-child').onclick = function(){
      tr.remove();
      validatePlanRealtime();
    };

    validatePlanRealtime();
  };

  // initial
  updateTotal();
  validatePlanRealtime();
}

  // ==============================
  // COLLECT PAYLOAD (your existing one is fine; keep safe checks)
  // ==============================
  function collectPayload() {
    const payload = {
      guest_type: document.querySelector('input[name="guest_type"]:checked').value,
      pax: []
    };

    document.querySelectorAll('.pax-row').forEach(paxRow => {
      const childRow = paxRow.nextElementSibling;
      if (!childRow) return;

      const planLabel = paxRow.querySelector('strong');
      const adultInput = paxRow.querySelector('.adult');
      const childInput = paxRow.querySelector('.child');
      const totalCell = paxRow.querySelector('.total');

      if (!planLabel || !adultInput || !childInput || !totalCell) return;

      const plan = {
        planName: planLabel.textContent.trim(),
        adults: adultInput.value,
        children: childInput.value,
        total: totalCell.textContent,
        childrenAge: []
      };

      childRow.querySelectorAll('.child-row').forEach(r => {
        const ageInput = r.querySelector('.age');
        const countInput = r.querySelector('.count');
        if (ageInput && countInput) {
          plan.childrenAge.push({ age: ageInput.value, count: countInput.value });
        }
      });

      payload.pax.push(plan);
    });

    return payload;
  }

  // ==============================
  // SAVE
  // ==============================
//   function saveGuestCount() {
//     // block submit if validation fails
//     if (!validateAllPlans()) return;

//     const payload = collectPayload();

//     const fd = new FormData();
//     fd.append('guset_count_lead_id_fk', document.getElementById('guset_count_lead_id_fk').value);
//     fd.append('guset_count_package_id_fk', document.getElementById('guset_count_package_id_fk').value);
//     fd.append('guest_type', payload.guest_type);

//     let totalGuests = 0;

//     payload.pax.forEach(p => {
//       fd.append('pax_count_plan[]', p.planName);
//       fd.append('adults[]', p.adults);
//       fd.append('children[]', p.children);
//       fd.append('total_count[]', p.total);
//       totalGuests += toInt(p.total);

//       p.childrenAge.forEach(c => {
//         fd.append('age[]', c.age);
//         fd.append('count[]', c.count);
//       });
//     });

//     fd.append('guset_count_total', totalGuests);

//     $.ajax({
//        url: "<?php echo base_url('index.php/Leads/ajax_add_guest_count/'); ?>" + id,
//       type: "POST",
//       data: fd,
//       processData: false,
//       contentType: false,
//       dataType: "json",
//       success: res => {
//         if (res.status) {
//           $('#gusetcountModal').modal('hide');
//           reload_table();
//         }
//       },
//       error: err => {
//         console.error(err);
//         alert('Save failed');
//       }
//     });
//   }

function markInvalid(input) {
  input.classList.remove('is-valid');
  input.classList.add('is-invalid');
}

function markValid(input) {
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');
}

function clearState(input) {
  input.classList.remove('is-invalid', 'is-valid');
}

// function toInt(v) {
//   const n = parseInt(v, 10);
//   return isNaN(n) ? 0 : n;
// }

function toInt(v){ var n = parseInt(v,10); return isNaN(n)?0:n; }

function tipEl(input){
  var wrap = input.closest('.field-wrap');
  return wrap ? wrap.querySelector('.tip') : null;
}

function setInvalid(input, msg){
  input.classList.remove('is-valid');
  input.classList.add('is-invalid');

  var tip = tipEl(input);
  if (tip){
    tip.textContent = msg || 'Invalid';
    tip.classList.add('show');
  }

  // shake input (restart animation)
  input.classList.remove('shake');
  void input.offsetWidth;
  input.classList.add('shake');
}

function setValid(input){
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');

  var tip = tipEl(input);
  if (tip){
    tip.textContent = '';
    tip.classList.remove('show');
  }
}

function clearState(input){
  input.classList.remove('is-invalid','is-valid','shake');
  var tip = tipEl(input);
  if (tip){
    tip.textContent = '';
    tip.classList.remove('show');
  }
}

function validateChildrenExact() {
  const allowed = toInt(child.value); // children input
  let used = 0;

  childTbody.querySelectorAll('.count').forEach(c => {
    used += toInt(c.value);
  });

  // EXACT MATCH RULE
  if (allowed <= 0) {
    error.textContent = 'Children is required and must be greater than 0';
    saveBtn.disabled = true;
    return false;
  }

  if (used < allowed) {
    error.textContent = `Child breakup is incomplete (Need: ${allowed}, Given: ${used})`;
    saveBtn.disabled = true;
    return false;
  }

  if (used > allowed) {
    error.textContent = `Child count exceeded (Allowed: ${allowed})`;
    saveBtn.disabled = true;
    return false;
  }

  error.textContent = '';
  saveBtn.disabled = false;
  return true;
}

function saveGuestCount() {

  let hasError = false;

  // clear previous error messages
  document.querySelectorAll('.error').forEach(e => e.textContent = '');

  document.querySelectorAll('#inclusionTable tbody tr.pax-row').forEach(paxRow => {

    const childRow = paxRow.nextElementSibling;
    if (!childRow) return;

    const errEl = childRow.querySelector('.error');

    const adultInput = paxRow.querySelector('.adult');
    const childInput = paxRow.querySelector('.child');

    const adults = toInt(adultInput.value);
    const children = toInt(childInput.value);

    clearState(adultInput);
    clearState(childInput);

    /* ---- Adults validation ---- */
    if (adults <= 0) {
      markInvalid(adultInput);
      errEl.textContent = 'Adults is required and must be greater than 0';
      hasError = true;
      return;
    } else {
      markValid(adultInput);
    }

    /* ---- Children validation ---- */
    if (children <= 0) {
      markInvalid(childInput);
      errEl.textContent = 'Children is required and must be greater than 0';
      hasError = true;
      return;
    } else {
      markValid(childInput);
    }

    /* ---- Child breakup validation ---- */
    let used = 0;
    let childError = false;

    childRow.querySelectorAll('.child-row').forEach(r => {
      const ageInput = r.querySelector('.age');
      const countInput = r.querySelector('.count');

      clearState(ageInput);
      clearState(countInput);

      const age = toInt(ageInput.value);
      const count = toInt(countInput.value);

      if (age <= 0) {
        markInvalid(ageInput);
        childError = true;
      } else {
        markValid(ageInput);
      }

      if (count <= 0) {
        markInvalid(countInput);
        childError = true;
      } else {
        markValid(countInput);
      }

      used += count;
    });

    if (childError) {
      errEl.textContent = 'Child age and count are required';
      hasError = true;
      return;
    }

    if (used > children) {
      errEl.textContent = `Child count exceeded (Allowed: ${children})`;
      childRow.querySelectorAll('.count').forEach(c => markInvalid(c));
      hasError = true;
      return;
    }
  });

  // ⛔ stop save
  if (hasError) return;

  // ✅ proceed to AJAX
  const payload = collectPayload();
  submitGuestCount(payload);
}


// function submitGuestCount(payload) {

//   const fd = new FormData();

//   fd.append('guset_count_lead_id_fk',
//     document.getElementById('guset_count_lead_id_fk').value
//   );
//   fd.append('guset_count_package_id_fk',
//     document.getElementById('guset_count_package_id_fk').value
//   );
//   fd.append('guest_type', payload.guest_type);

//   let totalGuests = 0;

//   payload.pax.forEach(p => {
//     fd.append('pax_count_plan[]', p.planName);
//     fd.append('adults[]', p.adults);
//     fd.append('children[]', p.children);
//     fd.append('total_count[]', p.total);
//     totalGuests += parseInt(p.total, 10);

//     p.childrenAge.forEach(c => {
//       fd.append('age[]', c.age);
//       fd.append('count[]', c.count);
//     });
//   });

//   fd.append('guset_count_total', totalGuests);

//   $.ajax({
//     url: "<?php echo base_url('index.php/Leads/ajax_save_guest_count/'); ?>",
//     type: "POST",
//     data: fd,
//     processData: false,
//     contentType: false,
//     dataType: "json",
//     success: res => {
//       if (res.status) {
//         $('#gusetcountModal').modal('hide');
//         reload_table();
//       }
//     },
//     error: () => alert('Save failed')
//   });
// }

function submitGuestCount(payload) {

  const fd = new FormData();

  fd.append('guset_count_lead_id_fk', $('#guset_count_lead_id_fk').val());
  fd.append('guset_count_package_id_fk', $('#guset_count_package_id_fk').val());
  fd.append('guest_type', payload.guest_type);

  let totalGuests = 0;

  payload.pax.forEach((p, planIndex) => {

    fd.append('pax_count_plan[]', p.planName);
    fd.append('adults[]', p.adults);
    fd.append('children[]', p.children);
    fd.append('total_count[]', p.total);

    totalGuests += parseInt(p.total, 10) || 0;

    // ✅ GROUPED child breakup:
    // age[0][], count[0][] ...
    p.childrenAge.forEach((c) => {
      fd.append(`age[${planIndex}][]`, c.age);
      fd.append(`count[${planIndex}][]`, c.count);
    });

  });

  fd.append('guset_count_total', totalGuests);

  $.ajax({
    url: "<?php echo base_url('index.php/Leads/ajax_save_guest_count/'); ?>",
    type: "POST",
    data: fd,
    processData: false,
    contentType: false,
    dataType: "json",
    success: function(res){
      if(res.status){
        $('#gusetcountModal').modal('hide');
        reload_table_guest_count();
      } else {
        console.log(res);
        alert((res.errors && res.errors.length) ? res.errors.join("\n") : "Save failed");
      }
    },
    error: function(xhr){
      console.error(xhr.responseText);
      alert('Save failed (server error)');
    }
  });
  
}
window.guset_count_edit = guset_count_edit;
  window.openGuestCountModal = openGuestCountModal;
});



function setInvalid(el){
  el.classList.remove('is-valid');
  el.classList.add('is-invalid');
  el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
}
function setValid(el){
  el.classList.remove('is-invalid');
  el.classList.add('is-valid');
}
function clearState(el){
  el.classList.remove('is-invalid','is-valid','shake');
}

function validateAccRow(row){
  let ok = true;

  const status = row.querySelector('select[name="accommodation_status[]"]');
  const dest   = row.querySelector('select[name="stay_destination_id[]"]');
  const meal   = row.querySelector('select[name="meal_plan_id[]"]');
  const pax    = row.querySelector('select[name="pax_count_plan_id[]"]');

  // reset
  [status,dest,meal,pax].forEach(e => e && clearState(e));

  // status always required
  if(!status || !status.value){
    if(status) setInvalid(status);
    ok = false;
  } else setValid(status);

  // if status Required => dest/meal/pax required
  if(status && status.value === 'R'){
    if(!dest.value){ setInvalid(dest); ok = false; } else setValid(dest);
    if(!meal.value){ setInvalid(meal); ok = false; } else setValid(meal);
    if(!pax.value){ setInvalid(pax); ok = false; } else setValid(pax);
  } else {
    // not required => clear states
    [dest,meal,pax].forEach(e => e && clearState(e));
  }

  return ok;
}

function validateAllAccRows(){
  let allOk = true;
  document.querySelectorAll('#accommodationTableBody tr.acc-row').forEach(row=>{
    if(!validateAccRow(row)) allOk = false;
  });

  const btn = document.getElementById('btnSaveaccplan');
  if(btn) btn.disabled = !allOk;
  return allOk;
}


// function initAccommodationValidation() {

//   // Custom method: required if status is R in same row
//   $.validator.addMethod("requiredIfAccRequired", function(value, element) {
//     var $row = $(element).closest('tr.acc-row');
//     var status = $row.find('select[name="accommodation_status[]"]').val();
//     if (status === 'R') {
//       return $.trim(value) !== '';
//     }
//     return true; // not required if status != R
//   }, "This field is required.");

//   // Setup validate
//   $('#form3').validate({
//     ignore: [], // important for select2
//     errorClass: 'is-invalid',
//     validClass: 'is-valid',
//     errorPlacement: function(error, element){
//       // no default error text under fields; icons show status
//       // optionally: you can append tooltip text here if needed
//     },
//     highlight: function(element){
//       $(element).addClass('is-invalid').removeClass('is-valid');
//       // Select2 fix: apply class to visible container
//       if ($(element).hasClass('lst-flt-select2')) {
//         $(element).next('.select2').find('.select2-selection').addClass('is-invalid').removeClass('is-valid');
//       }
//     },
//     unhighlight: function(element){
//       $(element).removeClass('is-invalid').addClass('is-valid');
//       if ($(element).hasClass('lst-flt-select2')) {
//         $(element).next('.select2').find('.select2-selection').removeClass('is-invalid').addClass('is-valid');
//       }
//     },
//     rules: {
//       'accommodation_status[]': { required: true },
//       'stay_destination_id[]': { requiredIfAccRequired: true },
//       'meal_plan_id[]': { requiredIfAccRequired: true },
//       'pax_count_plan_id[]': { requiredIfAccRequired: true }
//     }
//   });

//   // Real-time validate on change
//   $(document).on('change', '#form3 select', function(){
//     $('#form3').valid();
//   });
// }


// ✅ IMPORTANT: make function callable from onclick in datatable
window.accomodation_plan = accomodation_plan;



$(document).on('change', '.acc-status', function(){
  const row = $(this).closest('tr.acc-row');
  const isNotReq = $(this).val() === 'N';

  const fields = row.find('select[name="stay_destination_id[]"], select[name="meal_plan_id[]"], select[name="pax_count_plan_id[]"]');

  if(isNotReq){
    fields.val('').trigger('change');
    fields.prop('disabled', true);
    row.addClass('table-secondary');
  } else {
    fields.prop('disabled', false);
    row.removeClass('table-secondary');
  }

  validateAllAccRows();
});

// realtime validation on any select change
$(document).on('change', '#accomodation_planModal select', function(){
  validateAllAccRows();
});

function initSelect2AccModal(){
  if(!$.fn.select2) return;

  $('#accomodation_planModal .lst-flt-select2').each(function(){
    if($(this).hasClass('select2-hidden-accessible')){
      $(this).select2('destroy');
    }
  });

  $('#accomodation_planModal .lst-flt-select2').select2({
    dropdownParent: $('#accomodation_planModal'),
    width: '100%'
  });
}



// $('#btnSaveaccplan').on('click', function (e) {
//     e.preventDefault();

//     $.ajax({
//         url: "<?php echo base_url('index.php/Leads/save_accommodation_plan'); ?>",
//         type: "POST",
//         data: $('#form3').serialize(),
//         dataType: "JSON",
//         success: function (res) {

//             if (res.status) {
//                 alert(res.msg);
//                 $('#accomodation_planModal').modal('hide');
//             } else {
//                 alert(res.msg);
//             }
//         },
//         error: function () {
//             alert('Failed to save accommodation plan');
//         }
//     });
// });

$('#btnSaveaccplan').off('click').on('click', function(e){
  e.preventDefault();

  if(!validateAllAccRows()){
    return;
  }

  // ✅ IMPORTANT: serialize ignores disabled fields
  // Temporarily enable disabled selects so arrays post correctly
  const disabled = $('#form3').find(':disabled');
  disabled.prop('disabled', false);

  const postData = $('#form3').serialize();

  // restore disabled state
  disabled.prop('disabled', true);

  $.ajax({
    url: "<?php echo base_url('index.php/Leads/save_accommodation_plan'); ?>",
    type: "POST",
    data: postData,
    dataType: "json",
    success: function(res){
      console.log('save_accommodation_plan response:', res);

      if(res.status){
        // alert(res.msg || 'Saved');
        reload_table_accomodation();
        $('#accomodation_planModal').modal('hide');
      }else{
        alert((res.errors && res.errors.length) ? res.errors.join("\n") : (res.msg || 'Save failed'));
      }
    },
    error: function(xhr){
      console.log('SAVE ERROR:', xhr.responseText);
      alert('Save failed (server error)');
    }
  });
});




$(document).ready(function(){
// $("select[name='related_type']").onchange(function(){
$("#lead_type1").change(function() {


if($(this).val()=="B2C")
{
// alert("oo");
$('.staff_id_fk1').show();
$('.source_id_fk').show();
$('.guest_name').show();
$('.country_id_fk').show();
$('.priority_status_id_fk').show();
$('.stage_id_fk').show();
$('.date_type').show();
$('.stage_id_fk').show();
$('#hidden5').show();
$('.agent_id_fk').hide();
$('.total_package_cost').hide();
$('.expense').hide();
$('.margin').hide();
$('.description').hide();
$('.stage_flow_description').show();
$('.whats_number').show();
$('.alternative_number').show();
}
else
{
$('.staff_id_fk1').hide();
$('.source_id_fk').hide();
$('.guest_name').hide();
$('.country_id_fk').hide();
$('.priority_status_id_fk').hide();
$('.stage_id_fk').hide();
$('.date_type').hide();
$('.stage_id_fk').hide();
$('#hidden5').hide();
$('.agent_id_fk').show();
$('.total_package_cost').show();
$('.expense').show();
$('.margin').show();
$('.description').show();
$('.stage_flow_description').hide();
$('.whats_number').hide();
$('.alternative_number').hide();
}
});  
});

$(document).ready(function () {

    function toggleStartDate() {
        let dateType = $('#date_type').val();

        if (dateType === 'WITHOUT') {
            $('#start_date1')
                .prop('disabled', true)
                .prop('required', false)
                .val('');
        } else {
            $('#start_date1')
                .prop('disabled', false)
                .prop('required', true);
        }
    }

    // On change
    $('#date_type').on('change', toggleStartDate);

    // On page load
    toggleStartDate();
});


$(document).ready(function () {

    function calculateEndDate() {
        let dateType = $('#date_type').val();
        let startDate = $('#start_date1').val();
        let duration = parseInt($('#duration').val(), 10);

        if (dateType === 'WITH' && startDate && duration > 0) {

            // Split DD/MM/YYYY
            let parts = startDate.split('/');
            let day = parseInt(parts[0], 10);
            let month = parseInt(parts[1], 10) - 1; // JS months are 0-based
            let year = parseInt(parts[2], 10);

            let date = new Date(year, month, day);

            // Add duration
            date.setDate(date.getDate() + duration);

            // Format as YYYY-MM-DD (for input[type="date"])
            let formattedDate = date.toISOString().split('T')[0];
            $('#end_date1').val(formattedDate);

        } else {
            $('#end_date1').val('');
        }
    }

    $('#start_date1, #duration, #date_type').on('change keyup', calculateEndDate);
});




// Show modal when + Add new is clicked
window.checkAddNewSource = function(select) {
    if(select.value === '+') {
        var modal = new bootstrap.Modal(document.getElementById('AddSourceModal'));
        modal.show();
        select.value = ''; // reset dropdown temporarily
    }
}

// Save source via AJAX
let sourceSaved = false;

function saveSource() {
    let form = $('#addSourceForm')[0];
    if(!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    let sourceName = $('#source_name_modal').val().trim();

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/add_source'); ?>",
        type: 'POST',
        data: { source_name: sourceName },
        dataType: 'json',
        success: function(data) {
            if(data.status === 'success') {
                sourceSaved = true; // mark saved

                // Close modal
                let modalEl = document.getElementById('AddSourceModal');
                let modal = bootstrap.Modal.getInstance(modalEl);
                modal.hide();

                // Reset form
                form.reset();
                form.classList.remove('was-validated');

                // Add new option to dropdown and select it
                let select = $('#source_id_fk1');
                let newOption = new Option(data.source_name, data.source_id, true, true);
                select.append(newOption).val(data.source_id).trigger('change');

            } else {
                alert(data.message);
            }
        },
        error: function(err) {
            console.log(err);
        }
    });
}

// Reset dropdown ONLY if modal closed without saving
var sourceModalEl = document.getElementById('AddSourceModal');
sourceModalEl.addEventListener('hidden.bs.modal', function () {
    if(!sourceSaved) {
        let select = $('#source_id_fk1');
        select.val('').trigger('change');
    }
    $('#addSourceForm')[0].reset();
    $('#addSourceForm')[0].classList.remove('was-validated');
    sourceSaved = false;
});


// Show modal when + Add new is clicked
window.checkAddNewPriority = function(select) {
    if(select.value === '+') {
        var modal = new bootstrap.Modal(document.getElementById('AddPriorityModal'));
        modal.show();
        select.value = ''; // reset dropdown temporarily
    }
}

// Save priority status via AJAX
let prioritySaved = false;

function savePriorityStatus() {
    let form = $('#addPriorityForm')[0];
    if(!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    let name = $('#priority_name_modal').val().trim();
    let color = $('#priority_color_modal').val();
    let description = $('#priority_description_modal').val().trim();

    let button_html = `<center><span class="btn btn-sm" style="background-color:${color}"><span style="color:white">${name}</span></span></center>`;

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/add_priority_status'); ?>",
        type: 'POST',
        data: {
            priority_status_name: name,
            priority_status_button: button_html,
            priority_status_description: description
        },
        dataType: 'json',
        success: function(data) {
            if(data.status === 'success') {
                prioritySaved = true;

                // Close modal
                let modalEl = document.getElementById('AddPriorityModal');
                let modal = bootstrap.Modal.getInstance(modalEl);
                modal.hide();

                // Reset form
                form.reset();
                form.classList.remove('was-validated');

                // Add new option to dropdown and select it
                let select = $('#priority_status_id_fk');
                let newOption = new Option(name, data.priority_status_id, true, true);
                select.append(newOption).val(data.priority_status_id).trigger('change');

            } else {
                alert(data.message);
            }
        },
        error: function(err) {
            console.log(err);
        }
    });
}

// Reset dropdown ONLY if modal closed without saving
var priorityModalEl = document.getElementById('AddPriorityModal');
priorityModalEl.addEventListener('hidden.bs.modal', function () {
    if(!prioritySaved) {
        let select = $('#priority_status_id_fk');
        select.val('').trigger('change');
    }
    $('#addPriorityForm')[0].reset();
    $('#addPriorityForm')[0].classList.remove('was-validated');
    prioritySaved = false;
});


// Show modal when + Add new is clicked
function checkAddNewStage(select) {
    if(select.value === '+') {
        var modal = new bootstrap.Modal(document.getElementById('AddStageModal'));
        modal.show();
        select.value = ''; // reset dropdown temporarily
    }
}

// Save stage via AJAX
let stageSaved = false;

function saveStage() {
    let form = $('#addStageForm')[0];
    if(!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    let name = $('#stage_name_modal').val().trim();
    let color = $('#stage_color_modal').val();
    let description = $('#stage_description_modal').val().trim();

    let button_html = `<center><span class="btn btn-sm" style="background-color:${color}"><span style="color:white">${name}</span></span></center>`;

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/add_stage'); ?>",
        type: "POST",
        data: {
            stages_name: name,
            stages_button: button_html,
            stages_description: description
        },
        dataType: "json",
        success: function(data) {
            if(data.status === 'success') {
                stageSaved = true; // mark that save was successful

                // Close modal
                let modalEl = document.getElementById('AddStageModal');
                let modal = bootstrap.Modal.getInstance(modalEl);
                modal.hide();

                // Reset form
                form.reset();
                form.classList.remove('was-validated');

                // Add new option to dropdown and select it
                let select = $('#stage_id_fk'); // your stage dropdown
                let newOption = new Option(name, data.stages_id, true, true);
                select.append(newOption).val(data.stages_id).trigger('change');
            } else {
                alert(data.message);
            }
        },
        error: function(err) {
            console.log(err);
        }
    });
}

// Reset dropdown ONLY if user closed without saving
// var stageModalEl = document.getElementById('AddStageModal');
// stageModalEl.addEventListener('hidden.bs.modal', function () {
//     if(!stageSaved) { // only reset if modal closed without saving
//         let select = document.getElementById('stage_id_fk');
//         select.value = "";
//         if ($(select).hasClass("select2-hidden-accessible")) {
//             $(select).val("").trigger('change');
//         }
//     }
//     // always reset form validation
//     document.getElementById('addStageForm').reset();
//     document.getElementById('addStageForm').classList.remove('was-validated');
//     stageSaved = false; // reset flag for next time
// });

///// Disable package if duration is less than 1 //////

$(document).ready(function () {

    function togglePackageDropdown() {
        var duration = parseInt($('#duration').val(), 10);

        if (isNaN(duration) || duration <= 0) {
            $('#package_id_fk')
                .val('')
                .prop('disabled', true)
                .trigger('change'); // important for Select2
        } else {
            $('#package_id_fk')
                .prop('disabled', false)
                .trigger('change');
        }
    }

    // Run on page load (edit case)
    togglePackageDropdown();

    // Run when duration changes
    $('#duration').on('input change keyup', function () {
        togglePackageDropdown();
    });

});



$(document).ready(function () {

    $('#duration').on('keyup change', function () {
        var duration = parseInt($(this).val(), 10);

        // Reset state
        $('#package_msg').addClass('d-none');

        if (isNaN(duration) || duration <= 0) {
            $('#package_id_fk')
                .html('<option value="">Please Select Packages</option>')
                .prop('disabled', true)
                .trigger('change');

            $('#package_msg')
                .removeClass('d-none')
                .text('Please enter a duration greater than 0.');

            return;
        }

        $.ajax({
            url: "<?php echo base_url('index.php/Leads/get_packages_by_duration'); ?>",
            type: 'POST',
            dataType: 'json',
            data: { duration: duration },
            success: function (response) {

                var options = '<option value="">Please Select Packages</option>';

                if (response.length > 0) {
                    $.each(response, function (i, pkg) {
                        options += '<option value="' + pkg.packages_id + '">' +
                                    pkg.packages_title +
                                   '</option>';
                    });

                    $('#package_id_fk')
                        .html(options)
                        .prop('disabled', false)
                        .trigger('change');
                } else {
                    $('#package_id_fk')
                        .html(options)
                        .prop('disabled', true)
                        .trigger('change');

                    $('#package_msg')
                        .removeClass('d-none')
                        .text('No packages available for selected duration.');
                }
            },
            error: function () {
                $('#package_msg')
                    .removeClass('d-none')
                    .text('Something went wrong. Please try again.');
            }
        });
    });

});


function openChangeStatusModal(lead_id)
{
    $('#changeStatusForm')[0].reset();
    $('#stage_id').empty();

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/getLeadStageData'); ?>",
        type: "POST",
        data: { lead_id: lead_id },
        dataType: "json",
        success: function(res)
        {
            $('#lead_id').val(lead_id);
            $('#prev_stage_id').val(res.current_stage_id);

            // 🔹 Add default option
            // $('#stage_id').append(`<option value="">Select Stage</option>`);

            // 🔹 Add "+ Add new" ONCE
            $('#stage_id').append(`<option value="+">+ Add New</option>`);

            // 🔹 Add stages
            $.each(res.stages, function(i, stage) {
                let selected = (String(stage.stages_id) === String(res.current_stage_id)) 
                                ? 'selected' 
                                : '';

                $('#stage_id').append(
                    `<option value="${stage.stages_id}" ${selected}>
                        ${stage.stages_name}
                     </option>`
                );
            });

            $('#ChangeStatusModal').modal('show');
        }
    });
}


function reload_table_status()
{
    $table.ajax.reload(null,false); //reload datatable ajax 


        swal("Leads status updated successfully", "", "success")
         $('#ChangeStatusModal').modal('hide');
    
}
function saveChangeStatus() {
    let cur_stage  = $('#stage_id').val();
    let prev_stage = $('#prev_stage_id').val();

    if (!cur_stage) {
        // Swal.fire('Required', 'Please select a stage', 'warning');
        swal("Please select a stage", "", "warning")
        return;
    }

    if (String(cur_stage) === String(prev_stage)) {
        // Swal.fire({
        //     icon: 'warning',
        //     title: 'No Change Detected',
        //     text: 'Please select a different status'
        // });
        swal("Please select a different status", "", "error")
        return;
    }

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/saveStageFlow'); ?>",
        type: "POST",
        data: $('#changeStatusForm').serialize(),
        dataType: "json",
        success: function(res) {
            if (res.status) {
                // Swal.fire('Success', 'Status changed successfully', 'success')
                //     .then(() => location.reload());
                reload_table_status();
            } else {
                Swal.fire('Error', res.message, 'error');
            }
        }
    });
}

// Show modal when + Add new is clicked

function checkAddNewStage(select) {
    if (select.value === '+') {

        stagelistingSaved = false; // reset here ✔️

        const addModal = new bootstrap.Modal(
            document.getElementById('AddStageModal'),
            { backdrop: false }
        );
        addModal.show();

        $(select).val(null).trigger('change.select2');
    }
}


$('#stage_id').select2({
    dropdownParent: $('#ChangeStatusModal'),
    width: '100%'
});



// Save stage via AJAX
let stagelistingSaved = false;

function saveStagelisting() {
    let form = $('#addStageForm')[0];

    // ✅ Validate form
    if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    let name = $('#stage_name_modal').val().trim();
    let color = $('#stage_color_modal').val();
    let description = $('#stage_description_modal').val().trim();

    let button_html = `<center><span class="btn btn-sm" style="background-color:${color}"><span style="color:white">${name}</span></span></center>`;

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/add_stage'); ?>",
        type: "POST",
        data: {
            stages_name: name,
            stages_button: button_html,
            stages_description: description
        },
        dataType: "json",
        success: function (data) {
            if (data.status === 'success') {

                // mark as successfully saved
                stagelistingSaved = true;

                // close only AddStageModal
                const modalEl = document.getElementById('AddStageModal');
                const modal = bootstrap.Modal.getInstance(modalEl);
                modal.hide();

                // reset form validation
                form.reset();
                form.classList.remove('was-validated');

                // ✅ Add new stage to ChangeStatusModal dropdown
                let $select = $('#stage_id');
                let newOption = new Option(
                    data.stages_name,
                    data.stages_id,
                    true,   // defaultSelected
                    true    // selected
                );
                $select.append(newOption).trigger('change.select2');

            } else {
                alert(data.message);
            }
        },
        error: function(err) {
            console.log(err);
        }
    });
}



// Reset dropdown ONLY if user closed without saving
var stageModalEl = document.getElementById('AddStageModal');

$('#AddStageModal').on('hidden.bs.modal', function () {
    let $select = $('#stage_id');
    let currentVal = $select.val();  // what is currently selected
    let prevVal = $('#prev_stage_id').val(); // previous stage

    // Only restore if nothing is selected
    if (!currentVal) {
        $select.val(prevVal).trigger('change.select2');
    }

    // Always reset the rest of the form
    $(this).find('form')[0].reset();
    $(this).find('form').removeClass('was-validated');
});



///// show status history //////////

function showStatusModal(lead_id) {
    let $tbody = $('#stageHistoryTable tbody');
    $tbody.empty(); // clear previous rows

    $.ajax({
        url: "<?php echo base_url('index.php/Leads/getStageHistory'); ?>",
        type: "POST",
        data: { lead_id: lead_id },
        dataType: "json",
        success: function(res) {
            if(res.status && res.history.length > 0) {
                res.history.forEach((row, index) => {

                    // 🔹 Format Date: YYYY-MM-DD → DD/MM/YYYY
                    let dateParts = row.stage_flow_created_date.split('-');
                    let formattedDate = dateParts[2] + '/' + dateParts[1] + '/' + dateParts[0];

                    // 🔹 Format Time: HH:MM:SS → 12-hour format with AM/PM
                    let timeParts = row.stage_flow_created_time.split(':');
                    let hour = parseInt(timeParts[0]);
                    let minute = timeParts[1];
                    let ampm = hour >= 12 ? 'PM' : 'AM';
                    hour = hour % 12;
                    hour = hour ? hour : 12; // convert 0 → 12
                    let formattedTime = hour + ':' + minute + ' ' + ampm;

                    let tr = `<tr>
                        <td>${index + 1}</td>
                        <td>${row.current_stage_name}</td>
                        <td>${row.prev_stage_name}</td>
                        <td>${row.stage_flow_description || '-'}</td>
                        <td>${row.stage_flow_created_username}</td>
                        <td>${formattedDate}</td>
                        <td>${formattedTime}</td>
                    </tr>`;

                    $tbody.append(tr);
                });
            } else {
                $tbody.append(`<tr><td colspan="7" class="text-center">No history found</td></tr>`);
            }

            // Show modal
            let modal = new bootstrap.Modal(document.getElementById('StageHistoryModal'));
            modal.show();
        },
        error: function(err) {
            console.log(err);
            alert('Error fetching stage history');
        }
    });
}



/// set india is selected in dropdown
$(document).ready(function () {

    let hiddenVal = $('#id').val();

    if (!hiddenVal) {   // null, empty, or undefined
        // $('#country_id_fk').val('99').trigger('change');
        //  $('[id="country_id_fk"]').val('99').trigger('change.select2');
    }

});


///////////////////////////////////////////////////**************** Quotation ***************////////////////////////////


function open_quotation(leadId) {

  // Reset the form (optional)
  var form = document.getElementById('form');
  if (form) form.reset();

  // Clear payload UI containers if you have any
  // $('.optionBlockContainer').empty();

  // Disable save until lead is loaded
  $('#btnSave').prop('disabled', true);


  // Fetch lead (gives package_id_fk)
  $.ajax({
    url: "<?php echo base_url('index.php/Leads/ajax_edit/'); ?>" + leadId,
    type: "GET",
    dataType: "JSON",
    success: function(res) {

      var packageId = res && res.package_id_fk ? res.package_id_fk : '';

      if (!packageId) {
        alert('This lead does not have a package assigned (package_id_fk is empty).');
        return;
      }
loadInclusionAndRequirementDropdownData();   // ✅ now will work (after you fixed IDs inside it)

      // ✅ set hidden ids
      $('#leads_id_hidden').val(leadId);
      $('#packages_id_hidden').val(packageId);

      // (optional) show lead info in modal header
      // $('#leadNameText').text(res.leads_name || res.leads_number || leadId);

      // Hide dropdown row in this Leads-page modal version
      $('#leadPackageRow').addClass('d-none');

      // Open modal (Bootstrap 4 vs 5 safe)
      $('#QuotationModal').modal('show');

      // Enable save
      $('#btnSave').prop('disabled', false);

      // ✅ prepare: when user clicks "Add New Option", load package options based on hidden package id
      // (we attach once)
      bindAddOptionBtnOnce();

    },
    error: function() {
      alert('Failed to load lead details.');
    }
  });
}


var __addOptionBound = false;

function bindAddOptionBtnOnce() {
  if (__addOptionBound) return;
  __addOptionBound = true;

  // bind inside modal (safer than document)
  $('#QuotationModal').on('click', '#addOptionBtn', function (e) {
    e.preventDefault();
    e.stopPropagation();

    console.log('✅ Add Option clicked');

    var packageId = $('#packages_id_hidden').val();
    console.log('packageId:', packageId);

    if (!packageId) {
      alert('Package id not found.');
      return;
    }

    // make sure container exists
    var $wrap = $('.optionBlockContainer');
    console.log('optionBlockContainer length:', $wrap.length);

    if (!$wrap.length) {
      alert('Missing .optionBlockContainer in HTML. Add it inside modal body.');
      return;
    }

    var $newOptionBlock = addNewOptionBlock(); // must return block
    console.log('new option block created:', $newOptionBlock.length);

    if (!$newOptionBlock || !$newOptionBlock.length) {
      alert('Option block was not created. Check addNewOptionBlock().');
      return;
    }

    loadPackageOptionsIntoDropdown($newOptionBlock.find('.propertyDropdown'), packageId);
  });
}


// function addNewOptionBlock() {
//   // Example container
//   var $wrap = $('.optionBlockContainer');

//   // Use your existing option block HTML builder here
//   var html = `
//     <div class="optionBlock border rounded p-3 mb-3">
//       <div class="row g-2">
//         <div class="col-md-6">
//           <label class="small fw-semibold">Package Option</label>
//           <select class="form-control propertyDropdown" name="packages_properties_common_id_fk[]">
//             <option value="">Loading...</option>
//           </select>
//         </div>
//         <div class="col-md-6">
//           <label class="small fw-semibold">Option Name</label>
//           <input type="text" class="form-control" name="quotation_options_title[]" />
//         </div>
//       </div>

//       <div class="row g-2 mt-2">
//         <div class="col-md-4">
//           <label class="small fw-semibold">Cab Amount</label>
//           <input type="number" class="form-control" name="quotation_options_cab_amount[]" />
//         </div>
//       </div>

//       <!-- your days/properties/rooms UI here -->
//     </div>
//   `;

//   $wrap.append(html);
//   return $wrap.children('.optionBlock').last();
// }

function addNewOptionBlock() {

  var $wrap = $('.optionBlockContainer');

  var html = `
    <div class="optionBlock border rounded p-3 mb-3">

      <div class="row g-2">
        <div class="col-md-6">
          <label class="small fw-semibold">Package Option</label>
          <select class="form-control propertyDropdown" name="packages_properties_common_id_fk[]">
            <option value="">Loading...</option>
          </select>
        </div>

        <div class="col-md-6">
          <label class="small fw-semibold">Option Name</label>
          <input type="text" class="form-control" name="quotation_options_title[]" />
        </div>
      </div>

      <div class="row g-2 mt-2">
        <div class="col-md-4">
          <label class="small fw-semibold">Cab Amount</label>
          <input type="number" class="form-control" name="quotation_options_cab_amount[]" />
        </div>
      </div>

      <!-- ✅ THIS WAS MISSING -->
      <div class="itineraryContainer mt-3"></div>

    </div>
  `;

  $wrap.append(html);
  return $wrap.children('.optionBlock').last();
}



// function loadPackageOptionsIntoDropdown($select, packageId) {
//   if (!$select || !$select.length) return;

//   $.ajax({
//     url: "<?php echo base_url('index.php/Leads/ajax_get_package_property_categories'); ?>",
//     type: "GET",
//     dataType: "JSON",
//     data: { package_id: packageId },
//     success: function(res) {

//       var rows = (res && res.status && res.data) ? res.data : [];
//       var html = '<option value="">Select Package Option</option>';

//       for (var i=0; i<rows.length; i++) {
//         html += '<option value="'+ rows[i].packages_properties_common_id +'">'
//              +  rows[i].packages_properties_common_category_name
//              +  '</option>';
//       }

//       $select.html(html);

//       // Select2 (if you use it)
//       if ($.fn.select2) {
//         $select.select2({
//           width: '100%',
//           placeholder: 'Select Package Option',
//           allowClear: true,
//           dropdownParent: $('#QuotationModal')
//         });
//       }
//     },
//     error: function() {
//       $select.html('<option value="">Failed to load options</option>');
//     }
//   });
// }

function loadPackageOptionsIntoDropdown($select, packageId) {
  if (!$select || !$select.length) return;

  $.ajax({
    url: "<?php echo base_url('index.php/Leads/ajax_get_package_property_categories'); ?>",
    type: "GET",
    dataType: "JSON",
    data: { package_id: packageId },
    success: function(res) {

      var rows = (res && res.status && res.data) ? res.data : [];
      var html = '<option value="">Select Package Option</option>';

      for (var i=0; i<rows.length; i++) {
        html += '<option value="'+ rows[i].packages_properties_common_id +'">'
             +  rows[i].packages_properties_common_category_name
             +  '</option>';
      }

      $select.html(html);

      // ✅ init select2 (destroy if already)
      if ($.fn.select2) {
        if ($select.hasClass('select2-hidden-accessible')) {
          $select.select2('destroy');
        }

        $select.select2({
          width: '100%',
          placeholder: 'Select Package Option',
          allowClear: true,
          dropdownParent: $('#QuotationModal')
        });
      }

      // ✅ IMPORTANT: bind change handler DIRECTLY to this select (strongest)
      $select.off('change.loadItin').on('change.loadItin', function () {
        var commonId = $(this).val();
        var optionBlock = this.closest('.optionBlock');

        console.log("✅ dropdown changed =>", { commonId, optionBlockFound: !!optionBlock });

        if (!commonId || !optionBlock) return;

        loadItinerary(optionBlock, commonId);
      });

      // ✅ also trigger change on select2 select (sometimes change doesn’t fire)
      $select.off('select2:select.loadItin').on('select2:select.loadItin', function () {
        $(this).trigger('change');
      });

      $select.off('select2:clear.loadItin').on('select2:clear.loadItin', function () {
        var optionBlock = this.closest('.optionBlock');
        if (optionBlock) {
          var c = optionBlock.querySelector('.itineraryContainer');
          if (c) c.innerHTML = '';
        }
      });
    },
    error: function() {
      $select.html('<option value="">Failed to load options</option>');
    }
  });
}

///////////////////////// from Quotation file ////////////

////***For reload the datatable  *****///

function reload_table_quotation()
{
    $table.ajax.reload(null,false); //reload datatable ajax 
    var id = $("#id").val();
    if(id)
    {  

        swal("Quotation details updated successfully", "", "success")
        // var ff = 0;
        
        // ff = "Room tariff details updated successfully";

        //  $("#vehicle_update").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    else{
        
        swal("Quotation details added successfully", "", "success")

        // var ff = 0;
        
        // ff = "Transporter details added successfully";

        //  $("#vehicle_add").val(ff);
        
         
        //  var options = {

        // 'title': '',

        // 'style': 'success',

        // 'message': ff,

        // // 'success': 'warning',
        // 'icon': 'fas fa-check',

        // };
        
        // var n1 = new notify(options); 

        // n1.show(); 

        // setTimeout(function(){ n1.hide(); }, 10000);
    }
    
    
}

////***For reload the datatable  *****///

///***For save the quotation details from adding modal form *****///



/////******** Jquery validation when save******/////////////

function showError(msg, el) {
    alert(msg);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('is-invalid');
        setTimeout(() => el.classList.remove('is-invalid'), 2000);
    }
}

function num(v) {
    const n = parseFloat(v);
    return isNaN(n) ? 0 : n;
}

function validateQuotationForm() {

    /* ================= 1. MAIN REQUIRED FIELDS ================= */
    if (!$('#quotation_date').val())
        return showError('Quotation date is required', $('#quotation_date')[0]), false;

    if (!$('#arriving_destination').val())
        return showError('Arriving destination is required', $('#arriving_destination')[0]), false;

    if (!$('#departuring_destination').val())
        return showError('Departuring destination is required', $('#departuring_destination')[0]), false;

    if (!$('#leads_id_hidden').val())
        return showError('Please select Lead', $('#leads_id_hidden')[0]), false;

    if (!$('#packages_id_hidden').val())
        return showError('Please select Package', $('#packages_id_hidden')[0]), false;


    /* ================= 2A. AT LEAST ONE OPTION BLOCK ================= */
    const optionBlocks = document.querySelectorAll('.optionBlock');
    if (!optionBlocks || optionBlocks.length === 0) {
        showError('Please add at least one Package Option', document.getElementById('packages_id_hidden'));
        return false;
    }

    // If option blocks exist but none selected
    let anySelected = false;
    optionBlocks.forEach(ob => {
        const sel = ob.querySelector('.propertyDropdown');
        if (sel && sel.value) anySelected = true;
    });

    if (!anySelected) {
        const firstSelect = optionBlocks[0]?.querySelector('.propertyDropdown');
        showError('Please select at least one Package Option from dropdown', firstSelect || document.getElementById('packages_id_hidden'));
        return false;
    }

    /* ================= OPTION BLOCKS ================= */
    let valid = true;

    document.querySelectorAll('.optionBlock').forEach(optionBlock => {

        if (!valid) return;

        /* 2. Option dropdown + title + cab amount */
        const optionSel = optionBlock.querySelector('.propertyDropdown');
        const titleEl   = optionBlock.querySelector('[name="quotation_options_title[]"]');
        const cabEl     = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');

        if (!optionSel?.value)
            return valid = false, showError('Select Package Option', optionSel);

        if (!titleEl?.value.trim())
            return valid = false, showError('Option title is required', titleEl);

        if (num(cabEl?.value) <= 0)
            return valid = false, showError('Cab amount is required', cabEl);

        /* 3. Room calculated rate must not be 0 */
        optionBlock.querySelectorAll('.autoCalcRateInput').forEach(inp => {
            if (!valid) return;
            if (num(inp.value) <= 0)
                return valid = false, showError('Room calculated rate cannot be 0.00', inp);
        });

        /* ================= DAYS / PROPERTIES / ROOMS ================= */
        optionBlock.querySelectorAll('.itineraryDayRow').forEach(dayRow => {

            if (!valid) return;

            dayRow.querySelectorAll('.propertyBlock').forEach(propertyBlock => {

                if (!valid) return;

                /* 4. Property selected */
                if (!propertyBlock.dataset.propertyId)
                    return valid = false, showError('Property not selected', propertyBlock);

                const roomRows = propertyBlock.querySelectorAll('tbody tr[data-room-id]');

                /* 6. Property opened but no rooms */
                if (roomRows.length === 0)
                    return valid = false, showError('Please add at least one room', propertyBlock);

                roomRows.forEach(roomRow => {

                    if (!valid) return;

                    /* 5. Room selected */
                    if (!roomRow.dataset.roomId)
                        return valid = false, showError('Room not selected', roomRow);
                });
            });
        });

        /* 7. Margin validation */
        const marginType  = optionBlock.querySelector('.optionMarginType');
        const marginValue = optionBlock.querySelector('.optionMarginValue');

        if (!marginType?.value || num(marginValue?.value) <= 0)
            return valid = false, showError('Margin amount/percentage is required', marginValue);
    });

    if (!valid) return false;

    /* ================= 8. PROPERTY INCLUSIONS ================= */
    document.querySelectorAll('#inclusionTable tbody tr').forEach(tr => {
        if (!valid) return;

        const daySel = tr.querySelector('.inclusionDaySelect');
        const nameEl = tr.querySelector('[name="inclusion_name[]"]');
        const amtEl  = tr.querySelector('[name="inclusion_amount[]"]');

        // row filled partially
        if (
            daySel?.value ||
            nameEl?.value.trim() ||
            num(amtEl?.value) > 0
        ) {
            if (!daySel?.value)
                return valid = false, showError('Select Day | Destination for Inclusion', daySel);

            if (!nameEl?.value.trim())
                return valid = false, showError('Inclusion name required', nameEl);

            if (num(amtEl?.value) <= 0)
                return valid = false, showError('Inclusion amount required', amtEl);
        }
    });

    if (!valid) return false;

    /* ================= 9. SPECIAL REQUIREMENTS ================= */
    document.querySelectorAll('#specialReqTable tbody tr').forEach(tr => {
        if (!valid) return;

        const daySel = tr.querySelector('.specialReqDaySelect');
        const reqSel = tr.querySelector('.specialReqSelect');
        const amtEl  = tr.querySelector('.specialReqCost');

        if (
            daySel?.value ||
            reqSel?.value ||
            num(amtEl?.value) > 0
        ) {
            if (!daySel?.value)
                return valid = false, showError('Select Day | Destination for Requirement', daySel);

            if (!reqSel?.value)
                return valid = false, showError('Select Special Requirement', reqSel);

            if (num(amtEl?.value) <= 0)
                return valid = false, showError('Requirement amount required', amtEl);
        }
    });

    return valid;
}

// function save() {

//     let url = save_method === 'add'
//         ? "<?php echo base_url();?>index.php/Quotation/ajax_add/"
//         : "<?php echo base_url();?>index.php/Quotation/ajax_update/";

//     $('#btnSave').text('saving...').attr('disabled', true);
// recalcAllOptionsBeforeSave();
// // send payload...

//     // const form = document.getElementById('form');
//     // const data = new FormData(form);

//     // ✅ ADD JSON PAYLOAD
//     // const payload = buildQuotationPayload();
//     // data.append('data', JSON.stringify(payload));
// var data = new FormData(form);
// data.append('data', JSON.stringify(buildQuotationPayload()));

//     $.ajax({
//         url: url,
//         type: "POST",
//         data: data,
//         dataType: "JSON",
//         processData: false,
//         contentType: false,
//         success: function (res) {

//             if (res.status) {
//                 $('#QuotationModal').modal('hide');
//                 reload_table();
//             } else {
//                 alert('Validation failed');
//             }

//             $('#btnSave').text('save').attr('disabled', false);
//         },
//         error: function () {
//             alert('Error saving data');
//             $('#btnSave').text('save').attr('disabled', false);
//         }
//     });
// }

function save_quote() {

    // ✅ VALIDATE FIRST
    if (!validateQuotationForm()) {
        return;
    }

    // let url = save_method === 'add'
    //     ? "<?php echo base_url();?>index.php/Quotation/ajax_add/"
    //     : "<?php echo base_url();?>index.php/Quotation/ajax_update/";

    let url = "<?php echo base_url();?>index.php/Quotation/ajax_add/";

    $('#btnSave').text('saving...').attr('disabled', true);

    // ensure latest totals
    recalcAllOptionsBeforeSave();

    const form = document.getElementById('form');
    const data = new FormData(form);

    // JSON payload
    data.append('data', JSON.stringify(buildQuotationPayload()));

    $.ajax({
        url: url,
        type: "POST",
        data: data,
        dataType: "JSON",
        processData: false,
        contentType: false,
        success: function (res) {

            if (res.status) {
                $('#QuotationModal').modal('hide');
                reload_table_quotation();
                window.location.href = "<?php echo base_url();?>index.php/Quotation";
            } else {
                alert('Validation failed on server');
            }

            $('#btnSave').text('save').attr('disabled', false);
        },
        error: function () {
            alert('Error saving data');
            $('#btnSave').text('save').attr('disabled', false);
        }
    });
}


///***For save the quotation details from adding modal form *****///

$(document).ready(function () {

  function resetInclusionBox() {
    // Keep only first row
    const $tbody = $('#inclusionTable tbody');
    $tbody.find('tr:gt(0)').remove();

    // Clear first row inputs/select
    $tbody.find('tr:eq(0) input').val('');
    $tbody.find('tr:eq(0) select').val('').trigger('change');

    // Disable first row remove btn
    $tbody.find('tr:eq(0) .removeInclusionBtn').prop('disabled', true);
  }

  function resetSpecialReqBox() {
    const $tbody = $('#specialReqTable tbody');
    $tbody.find('tr:gt(0)').remove();

    $tbody.find('tr:eq(0) input').val('');
    $tbody.find('tr:eq(0) select').val('').trigger('change');

    $tbody.find('tr:eq(0) .removeSpecialReqBtn').prop('disabled', true);
  }

  function toggleBox($checkbox, $box, resetFn) {
    if ($checkbox.is(':checked')) {
      $box.slideDown(150);

      // ✅ fill dropdowns if your data already loaded
      loadInclusionAndRequirementDropdownData();

      // ✅ re-init select2 inside newly shown box (important)
      setTimeout(function(){
        $box.find('select').each(function(){
          initSelect2(this, $(this).hasClass('specialReqSelect') ? 'Select Requirement' : 'Select Day | Date | Destination');
        });
      }, 50);

    } else {
      $box.slideUp(150, function(){
        resetFn();
      });
    }
  }

  // default state (hide both)
  $('#inclusionBox').hide();
  $('#specialReqBox').hide();

  // on load (if checked due to edit)
  toggleBox($('#quotation_property_inclusion_type'), $('#inclusionBox'), resetInclusionBox);
  toggleBox($('#quotation_special_requirement_type'), $('#specialReqBox'), resetSpecialReqBox);

  // change handlers
  $('#quotation_property_inclusion_type').on('change', function () {
    toggleBox($(this), $('#inclusionBox'), resetInclusionBox);
  });

  $('#quotation_special_requirement_type').on('change', function () {
    toggleBox($(this), $('#specialReqBox'), resetSpecialReqBox);
  });

});


/* ================= SPECIAL REQUIREMENTS ================= */



let __dayOptions = [];          // from accommodation_plan
let __specialReqOptions = [];   // from special_requirements

function formatDate(d) {
  // d is YYYY-MM-DD
  if (!d) return '';
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

/**
 * dayKey format we store in <option value="">:
 * property_day_id_fk|stay_destination_id_fk|accommodation_date
 */
function makeDayKey(row) {
  return `${row.property_day_id_fk}|${row.stay_destination_id_fk}|${row.accommodation_date}`;
}

function buildDayOptionLabel(row) {
  return `Day ${row.packages_properties_days_day || ''} | ${formatDate(row.accommodation_date)} | ${row.district_name || ''}`;
}

function initSelect2(el, placeholder = 'Select') {
    if (!el) return;

    // destroy if already initialized
    if ($(el).hasClass('select2-hidden-accessible')) {
        $(el).select2('destroy');
    }

    // If this select is inside a Bootstrap modal, attach dropdown to modal
    const $modalParent = $(el).closest('.modal');
    const opts = {
        width: '100%',
        placeholder,
        allowClear: true,
        minimumResultsForSearch: 0 // ✅ ALWAYS show search box
    };

    if ($modalParent.length) {
        opts.dropdownParent = $modalParent; // ✅ IMPORTANT for focus + search typing
    }

    $(el).select2(opts);
}

function applySpecialReqCostFromSelect(sel) {
  if (!sel) return;

  const row = sel.closest('tr');
  if (!row) return;

  const costInput = row.querySelector('.specialReqCost');
  if (!costInput) return;

  const opt = sel.options[sel.selectedIndex];
  const cost = opt ? (opt.getAttribute('data-cost') || '0') : '0';

  costInput.value = cost;
}

/* ✅ Works with Select2 */
$(document).on('select2:select', '.specialReqSelect', function () {
  applySpecialReqCostFromSelect(this);
});

$(document).on('select2:clear', '.specialReqSelect', function () {
  const row = this.closest('tr');
  const costInput = row ? row.querySelector('.specialReqCost') : null;
  if (costInput) costInput.value = '';
});

/* ✅ Fallback if Select2 not active */
document.addEventListener('change', function (e) {
  const sel = e.target.closest('.specialReqSelect');
  if (!sel) return;
  applySpecialReqCostFromSelect(sel);
});


function fillDaySelect(selectEl) {
    if (!selectEl) return;

    let html = `<option value="">Select Day | Date | Destination</option>`;
    __dayOptions.forEach(r => {
        const key = makeDayKey(r);
        html += `<option value="${key}">${buildDayOptionLabel(r)}</option>`;
    });

    selectEl.innerHTML = html;

    // ✅ Select2 init
    initSelect2(selectEl, 'Select Day | Date | Destination');
}


function fillSpecialReqSelect(selectEl) {
    if (!selectEl) return;

    let html = `<option value="">Select Requirement</option>`;
    __specialReqOptions.forEach(r => {
        html += `
            <option value="${r.special_requirements_id}"
                    data-cost="${r.special_requirements_cost || 0}">
                ${r.special_requirements_name}
            </option>`;
    });

    selectEl.innerHTML = html;

    // ✅ Select2 init
    initSelect2(selectEl, 'Select Requirement');

    // if something already selected, apply its cost
applySpecialReqCostFromSelect(selectEl);

}


/* ================= LOAD DROPDOWNS (call on package/lead change) ================= */

function loadInclusionAndRequirementDropdownData() {
  const leadId = document.getElementById('leads_id_hidden')?.value || '';
  const packageId = document.getElementById('packages_id_hidden')?.value || '';

  // Fill existing rows
document.querySelectorAll('.inclusionDaySelect').forEach(el => {
    fillDaySelect(el);
});

document.querySelectorAll('.specialReqDaySelect').forEach(el => {
    fillDaySelect(el);
});

document.querySelectorAll('.specialReqSelect').forEach(el => {
    fillSpecialReqSelect(el);
});


  if (!leadId || !packageId) return;

  const urlDays =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_accommodation_day_options` +
    `?lead_id=${encodeURIComponent(leadId)}&package_id=${encodeURIComponent(packageId)}`;

  const urlReq =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_special_requirements`;

  Promise.all([
    fetch(urlDays).then(r => r.json()),
    fetch(urlReq).then(r => r.json())
  ])
  .then(([daysRes, reqRes]) => {
    __dayOptions = (daysRes && daysRes.status && Array.isArray(daysRes.data)) ? daysRes.data : [];
    __specialReqOptions = (reqRes && reqRes.status && Array.isArray(reqRes.data)) ? reqRes.data : [];

    // Fill existing rows selects
    document.querySelectorAll('.inclusionDaySelect').forEach(fillDaySelect);
    document.querySelectorAll('.specialReqDaySelect').forEach(fillDaySelect);
    document.querySelectorAll('.specialReqSelect').forEach(fillSpecialReqSelect);
  })
  .catch(err => console.error(err));

  recalcAllInclusionSpecialTotals();

}

// Call it when lead/package changes:
// document.getElementById('packages_id_fk')?.addEventListener('change', loadInclusionAndRequirementDropdownData);
// document.getElementById('leads_id')?.addEventListener('change', loadInclusionAndRequirementDropdownData);

/* ================= ROW TEMPLATES ================= */

function createInclusionRow() {
  return `
  <tr>
    <td>
      <select class="form-select form-select-sm inclusionDaySelect" name="inclusion_day_key[]"></select>
    </td>
    <td>
      <input type="text" class="form-control form-control-sm"
             name="inclusion_name[]" placeholder="Inclusion name">
    </td>
    <td>
      <input type="number" class="form-control form-control-sm"
             name="inclusion_amount[]" placeholder="Amount">
    </td>
    <td class="text-center">
      <button type="button" class="btn btn-sm btn-danger removeInclusionBtn">
        <i class="bi bi-trash"></i>
      </button>
    </td>
  </tr>`;
}

function createSpecialReqRow() {
  return `
  <tr>
    <td>
      <select class="form-select form-select-sm specialReqDaySelect" name="specialreq_day_key[]"></select>
    </td>
    <td>
      <select class="form-select form-select-sm specialReqSelect" name="quotation_special_requirements_id_fk[]"></select>
    </td>
    <td>
      <input type="number" class="form-control form-control-sm specialReqCost"
             name="special_requirements_cost[]" placeholder="Amount">
    </td>
    <td class="text-center">
      <button type="button" class="btn btn-sm btn-danger removeSpecialReqBtn">
        <i class="bi bi-trash"></i>
      </button>
    </td>
  </tr>`;
}

/* ================= ADD/REMOVE ROWS ================= */

// document.getElementById('addInclusionBtn').addEventListener('click', function (e) {
//     e.preventDefault();

//     const tbody = document.querySelector('#inclusionTable tbody');
//     tbody.insertAdjacentHTML('beforeend', createInclusionRow());

//     const row = tbody.lastElementChild;

//     fillDaySelect(row.querySelector('.inclusionDaySelect'));
// });

document.getElementById('addInclusionBtn').addEventListener('click', function (e) {
  e.preventDefault();

  const tbody = document.querySelector('#inclusionTable tbody');
  tbody.insertAdjacentHTML('beforeend', createInclusionRow());

  const row = tbody.lastElementChild;
  fillDaySelect(row.querySelector('.inclusionDaySelect'));

  recalcInclusionTotal();
});


// document.addEventListener('click', function (e) {
//   if (e.target.closest('.removeInclusionBtn')) {
//     e.target.closest('tr').remove();
//   }
// });

document.addEventListener('click', function (e) {
  if (e.target.closest('.removeInclusionBtn')) {
    e.target.closest('tr').remove();
    recalcInclusionTotal();
  }
});


// document.getElementById('addSpecialReqBtn').addEventListener('click', function (e) {
//     e.preventDefault();

//     const tbody = document.querySelector('#specialReqTable tbody');
//     tbody.insertAdjacentHTML('beforeend', createSpecialReqRow());

//     const row = tbody.lastElementChild;

//     fillDaySelect(row.querySelector('.specialReqDaySelect'));
//     fillSpecialReqSelect(row.querySelector('.specialReqSelect'));
// });

document.getElementById('addSpecialReqBtn').addEventListener('click', function (e) {
  e.preventDefault();

  const tbody = document.querySelector('#specialReqTable tbody');
  tbody.insertAdjacentHTML('beforeend', createSpecialReqRow());

  const row = tbody.lastElementChild;
  fillDaySelect(row.querySelector('.specialReqDaySelect'));
  fillSpecialReqSelect(row.querySelector('.specialReqSelect'));

  recalcSpecialReqTotal();
});


// document.addEventListener('click', function (e) {
//   if (e.target.closest('.removeSpecialReqBtn')) {
//     e.target.closest('tr').remove();
//   }
// });

document.addEventListener('click', function (e) {
  if (e.target.closest('.removeSpecialReqBtn')) {
    e.target.closest('tr').remove();
    recalcSpecialReqTotal();
  }
});


/* ================= AUTO-FILL COST WHEN SELECT REQUIREMENT ================= */

// document.addEventListener('change', function(e) {
//   const sel = e.target.closest('.specialReqSelect');
//   if (!sel) return;

//   const row = sel.closest('tr');
//   const costInput = row.querySelector('.specialReqCost');
//   const opt = sel.options[sel.selectedIndex];

//   const cost = opt?.dataset?.cost ?? '';
//   if (costInput) costInput.value = cost;
// });

// ✅ Works with normal select + select2
document.addEventListener('change', function (e) {
  const sel = e.target.closest('.specialReqSelect');
  if (!sel) return;

  const row = sel.closest('tr');
  const costInput = row?.querySelector('.specialReqCost');
  if (!costInput) return;

  // read selected option data-cost
  const opt = sel.options[sel.selectedIndex];
  const cost = opt && opt.dataset ? (opt.dataset.cost || '0') : '0';

  costInput.value = cost;

  // ✅ update total instantly
  recalcSpecialReqTotal();
});


function num(v) {
  const n = parseFloat(v);
  return isNaN(n) ? 0 : n;
}

function money(n) {
  return num(n).toFixed(2);
}

/* ✅ Recalculate inclusion total */
function recalcInclusionTotal() {
  let total = 0;
  document.querySelectorAll('#inclusionTable tbody [name="inclusion_amount[]"]').forEach(inp => {
    total += num(inp.value);
  });

  const txt = document.getElementById('totalInclusionAmountText');
  const hid = document.getElementById('totalInclusionAmountInput');
  if (txt) txt.textContent = money(total);
  if (hid) hid.value = money(total);

  return total;
}

/* ✅ Recalculate special requirements total */
function recalcSpecialReqTotal() {
  let total = 0;
  document.querySelectorAll('#specialReqTable tbody [name="special_requirements_cost[]"]').forEach(inp => {
    total += num(inp.value);
  });

  const txt = document.getElementById('totalSpecialReqAmountText');
  const hid = document.getElementById('totalSpecialReqAmountInput');
  if (txt) txt.textContent = money(total);
  if (hid) hid.value = money(total);

  return total;
}

/* ✅ Recalculate both (use after add/remove/load) */
function recalcAllInclusionSpecialTotals() {
  recalcInclusionTotal();
  recalcSpecialReqTotal();
}

/* Live update on typing amount fields */
document.addEventListener('input', function (e) {
  if (e.target.matches('#inclusionTable tbody [name="inclusion_amount[]"]')) {
    recalcInclusionTotal();
  }
  if (e.target.matches('#specialReqTable tbody [name="special_requirements_cost[]"]')) {
    recalcSpecialReqTotal();
  }
});

let optionCount = 0;



/* ================= LOAD ITINERARY ON OPTION SELECT ================= */
$(document).on('select2:select', '.propertyDropdown', function () {
  $(this).trigger('change'); // force normal change handler
});

// document.addEventListener('change', (e) => {

//     const dropdown = e.target.closest('.propertyDropdown');
//     if (!dropdown) return;

//     const optionBlock = dropdown.closest('.optionBlock');
//     if (!optionBlock) return;

//     const commonId = dropdown.value;
//     if (!commonId) return;

//     loadItinerary(optionBlock, commonId);
// });

// document.addEventListener('change', (e) => {

//   const dropdown = e.target.closest('.propertyDropdown');
//   if (!dropdown) return;

//   const optionBlock = dropdown.closest('.optionBlock');
//   if (!optionBlock) return;

//   const commonId = dropdown.value;

//   console.log("Package option selected:", commonId);
//   console.log("Lead:", $('#leads_id_hidden').val(), "Package:", $('#packages_id_hidden').val());

//   if (!commonId) return;

//   loadItinerary(optionBlock, commonId);
// });

/* ================= REMOVE OPTION ================= */

document.addEventListener('click', (e) => {
    const btn = e.target.closest('.removeOptionBtn');
    if (!btn) return;

    btn.closest('.optionBlock')?.remove();
    reIndexOptions();
});

/* ================= HELPERS ================= */

function reIndexOptions() {
    optionCount = 0;
    document.querySelectorAll('.optionBlock').forEach((block) => {
        optionCount++;
        block.querySelector('.optionTitle').innerText = `Option ${optionCount}`;
        block.dataset.optionIndex = optionCount;

        const removeBtn = block.querySelector('.removeOptionBtn');
        optionCount === 1
            ? removeBtn.classList.add('d-none')
            : removeBtn.classList.remove('d-none');
    });
}

/* ================= FETCH PROPERTY OPTIONS ================= */

// function fetchPropertyCategories(dropdown) {

//     const packageId = packageSelect.value;
//     if (!packageId) return;

//     dropdown.innerHTML = '<option>Loading...</option>';

//     fetch(`<?php echo base_url(); ?>index.php/Quotation/get_property_categories_by_package?package_id=${packageId}`)
//         .then(res => res.json())
//         .then(res => {
//             dropdown.innerHTML = '<option value="">Select package option</option>';
//             if (!res.status) return;

//             res.data.forEach(item => {
//                 const opt = document.createElement('option');
//                 opt.value = item.packages_properties_common_id;
//                 opt.textContent = item.packages_properties_common_category_name;
//                 dropdown.appendChild(opt);
//             });
//         });
// }

/* ================= LOAD FULL ITINERARY ================= */
function loadItinerary(optionBlock, commonId) {

    const container = optionBlock.querySelector('.itineraryContainer');
    if (!container) return;

    // ✅ Your select id is leads_id (from your HTML)
    const leadId = document.getElementById('leads_id_hidden')?.value || '';
    const packageId = document.getElementById('packages_id_hidden')?.value || '';

    // ✅ Debug (check in browser console)
    console.log('loadItinerary params =>', { leadId, packageId, commonId });

    if (!commonId || !leadId || !packageId) {
        container.innerHTML = `
            <p class="text-danger mb-0">
                Missing params: 
                commonId=${commonId || 'EMPTY'},
                leadId=${leadId || 'EMPTY'},
                packageId=${packageId || 'EMPTY'}.
                Please select Lead + Package + Package Option.
            </p>`;
        return;
    }

    container.innerHTML = '<p>Loading itinerary...</p>';

    const url =
        `<?php echo base_url(); ?>index.php/Quotation/get_package_full_itinerary` +
        `?packages_properties_common_id=${encodeURIComponent(commonId)}` +
        `&lead_id=${encodeURIComponent(leadId)}` +
        `&package_id=${encodeURIComponent(packageId)}`;

    fetch(url)
        .then(async (r) => {
            // ✅ read as text first to avoid JSON.parse crash
            const text = await r.text();
            console.log('API raw response:', text);

            if (!text || text.trim() === '') {
                throw new Error('Empty response from server');
            }

            try {
                return JSON.parse(text);
            } catch (err) {
                throw new Error('Response is not valid JSON. Check API raw response in console.');
            }
        })
        .then(res => {

            if (!res.status || !Array.isArray(res.data) || res.data.length === 0) {
                container.innerHTML = `<p class="text-warning mb-0">No accommodation days found for this lead/package.</p>`;
                return;
            }

            let html = `
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Day | Date</th>
                            <th>Stay Destination</th>
                            <th>Properties & Rooms</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            res.data.forEach(day => {

                let propertiesHTML = '';

                (day.properties || []).forEach(property => {

                    let roomsHTML = '';

                    (property.rooms || []).forEach(room => {
                        roomsHTML += `
                            <tr data-room-id="${room.properties_room_category_id || ''}" data-packages-room-id="${room.packages_properties_rooms_id || 0}"
      data-day-id="${day.packages_properties_days_id || 0}">
                                <td class="roomName">
                                    ${room.properties_room_category_name || ''}
                                    <input type="hidden" name="packages_properties_rooms_id_fk[]" value="${room.packages_properties_rooms_id || 0}">
                                    <input type="hidden" name="quotation_properties_rooms_id_fk[]" value="${room.properties_room_category_id || 0}">
                                </td>
                                <td><span class="autoCalcRateText">0.00</span><!-- Hidden input for saving to DB -->
    <input type="hidden"
           name="total_room_cost[][]"
           class="autoCalcRateInput"
           value="0.00"></td>
                                <td class="text-center">
                                    <button type="button"
        class="btn btn-sm btn-warning me-1 editRoomBtn"
        data-lead-id="${leadId}"
        data-property-day-id="${day.packages_properties_days_id}"
        data-stay-destination-id="${day.packages_properties_days_destination_id_fk}"
        data-property-id="${property.properties_id}"
        data-room-category-id="${room.properties_room_category_id}">
    <i class="bi bi-pencil"></i>
</button>

                                    <button type="button" class="btn btn-sm btn-danger removeRoomBtn">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    });

                    propertiesHTML += `
                        <div class="propertyBlock mt-3"
                             data-property-id="${property.properties_id || ''}"
                             data-packages-property-id="${property.packages_properties_id || 0}">
                            <h6 class="fw-bold text-primary propertyTitle">
                                Property: ${property.properties_name || ''}
                            </h6>

                            <input type="hidden" name="packages_properties_id_fk[]" value="${property.packages_properties_id || 0}">
                            <input type="hidden" name="properties_id_fk[]" value="${property.properties_id || 0}">

                            <table class="table table-sm table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Room Name</th>
                                        <th>Calculated Rate</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>${roomsHTML}</tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-center">
                                            <button type="button" class="btn btn-sm btn-success addRoomBtn">
                                                <i class="bi bi-plus-circle"></i> Add New Room
                                            </button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    `;
                });

                html += `
                    <tr class="itineraryDayRow">
                        <td>
                            <strong>Day ${day.packages_properties_days_day || ''}</strong>
                            <input type="hidden" name="packages_properties_days_id_fk[]" value="${day.packages_properties_days_id || 0}">
                            <input type="hidden" name="quotation_properties_days_day[]" value="${day.packages_properties_days_day || ''}">
                        </td>

                        <td>
                            ${day.district_name || ''}
                            <input type="hidden" name="quotation_properties_days_destination_id_fk[]" value="${day.packages_properties_days_destination_id_fk || 0}">
                        </td>

                        <td>
                            <div class="propertiesContainer">${propertiesHTML}</div>

                            <div class="propertySelector d-none mt-2">
                                <select class="form-select form-select-sm propertySelectDropdown">
                                    <option value="">Select Property</option>
                                </select>
                            </div>

                            <div class="text-center mt-2">
                                <button type="button" class="btn btn-sm btn-primary addPropertyBtn">
                                    <i class="bi bi-plus-square"></i> Add Property
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            html += `</tbody></table><!-- ================= OPTION TOTAL SUMMARY ================= -->
<div class="option-total-box border rounded p-3 mt-4 bg-light">

  <div class="row g-3 align-items-end">

    <!-- Total Cost -->
    <div class="col-md-4">
      <label class="form-label fw-semibold">Total Cost</label>
      <div class="fw-bold text-primary fs-5">
        ₹ <span class="optionTotalCostText">0.00</span>
      </div>
      <input type="hidden" class="optionTotalCostInput" name="option_total_cost[]">
    </div>

    <!-- Margin -->
    <div class="col-md-4">
      <label class="form-label fw-semibold">Margin</label>
      <div class="d-flex gap-2">
        <select class="form-select form-select-sm optionMarginType">
          <option value="amount">Amount</option>
          <option value="percent">Percentage (%)</option>
        </select>

        <input type="number"
               class="form-control form-control-sm optionMarginValue"
               placeholder="Enter margin">
      </div>
    </div>

    <!-- Total Quote Rate -->
    <div class="col-md-4 text-end">
      <label class="form-label fw-semibold">Total Quote Rate</label>
      <div class="fw-bold text-primary fs-4">
        ₹ <span class="optionQuoteTotalText">0.00</span>
      </div>
      <input type="hidden" class="optionQuoteTotalInput" name="option_quote_total[]">
    </div>

  </div>
</div>
</div>`;
            container.innerHTML = html;
        })
        .catch(err => {
            console.error(err);
            container.innerHTML = `<p class="text-danger mb-0">${err.message}</p>`;
        });
}



/* ================= TEMPLATE ================= */

function getOptionTemplate(index) {
    return `
    <div class="optionBlock border p-3 mb-4" data-option-index="${index}">
        <h2 class="optionTitle mb-3">Option ${index}</h2>

        <div class="row mb-3">
            <div class="col-md-3">
                <label>Select package option</label>
                <select name=packages_properties_common_id_fk[] class="form-select form-select-sm propertyDropdown">
                    <option value="">Select package option</option>
                </select>
            </div>

            <div class="col-md-3">
                <label>Name of the option</label>
                <input type="text" name=quotation_options_title[] class="form-control">
            </div>

            <div class="col-md-3 d-flex align-items-end gap-2">
                <div class="w-100">
                    <label>Cab amount</label>
                    <input type="number" name=quotation_options_cab_amount[] class="form-control">
                </div>

                <button class="btn btn-danger removeOptionBtn ${index === 1 ? 'd-none' : ''}">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        </div>

        <div class="itineraryContainer"></div>
    </div>
    `;
}



////////////********** *************///////////

document.addEventListener('click', function (e) {

    const btn = e.target.closest('.addPropertyBtn');
    if (!btn) return;

    const td = btn.closest('td');
    const selector = td.querySelector('.propertySelector');
    const dropdown = selector.querySelector('.propertySelectDropdown');

    selector.classList.remove('d-none');

    if (dropdown.dataset.loaded === '1') return;

    dropdown.innerHTML = '<option>Loading...</option>';

    fetch(`<?php echo base_url(); ?>index.php/Quotation/get_properties`)
        .then(r => r.json())
        .then(r => {
            dropdown.innerHTML = '<option value="">Select Property</option>';
            r.data.forEach(p => {
                dropdown.innerHTML += `
                    <option value="${p.properties_id}">
                        ${p.properties_name}
                    </option>`;
            });
            dropdown.dataset.loaded = '1';
        });
});


document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('propertySelectDropdown')) return;

    const dropdown = e.target;
    const propertyId = dropdown.value;
    if (!propertyId) return;

    const td = dropdown.closest('td');
    const propertiesContainer = td.querySelector('.propertiesContainer');

    // 🔴 VALIDATION: SAME DAY DUPLICATE PROPERTY
    const exists = [...propertiesContainer.querySelectorAll('.propertyBlock')]
        .some(block => block.dataset.propertyId === propertyId);

    if (exists) {
        alert('This property is already added for this day.');
        dropdown.value = '';
        return;
    }

    const propertyName = dropdown.options[dropdown.selectedIndex].text;

    propertiesContainer.insertAdjacentHTML('beforeend', `
        <div class="propertyBlock mt-3" data-property-id="${propertyId}">
            
            <h6 class="fw-bold text-primary">
                Property: ${propertyName}
            </h6>

            <!-- ✅ HIDDEN FIELDS (IMPORTANT) -->
            <input type="hidden" name="properties_id_fk[]" value="${propertyId}">
            <input type="hidden" name="packages_properties_id_fk[]" value="0">

            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>Room Name</th>
                        <th>Rate</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-center">
                            <button class="btn btn-sm btn-success addRoomBtn">
                                <i class="bi bi-plus-circle"></i> Add Room
                            </button>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    `);

    dropdown.value = '';
    dropdown.closest('.propertySelector').classList.add('d-none');
});

document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('propertySelectDropdown')) return;

    const dropdown = e.target;
    const propertyId = dropdown.value;
    if (!propertyId) return;

    const td = dropdown.closest('td');
    const propertiesContainer = td.querySelector('.propertiesContainer');

    let exists = false;

    propertiesContainer.querySelectorAll('.propertyBlock').forEach(block => {
        if (block.dataset.propertyId === propertyId) {
            exists = true;
        }
    });

    if (exists) {
        alert('This property is already added for this day.');
        dropdown.value = '';
        return;
    }

    // ✅ continue adding property if not duplicate
});


function getRoomRowTemplate(propertyId, rooms) {
  let options = `<option value="">Select Room</option>`;
  rooms.forEach(r => {
    options += `<option value="${r.properties_room_category_id}">
      ${r.properties_room_category_name}
    </option>`;
  });

  return `
    <tr>
      <td>
        <select class="form-select form-select-sm roomSelect">${options}</select>
        <input type="hidden" name="packages_properties_rooms_id_fk[]" class="pkgRoomInput">
        <input type="hidden" name="quotation_properties_rooms_id_fk[]" class="roomInput">
      </td>
      <td class="roomRate"><span class="autoCalcRateText">0.00</span><!-- Hidden input for saving to DB -->
    <input type="hidden"
           name="total_room_cost[][]"
           class="autoCalcRateInput"
           value="0.00"></td>
      <td class="text-center">
        <button type="button"
                class="btn btn-sm btn-warning me-1 editRoomBtn"
                data-lead-id=""
                data-property-id="${propertyId}"
                data-room-category-id="">
          <i class="bi bi-pencil"></i>
        </button>
        <button type="button" class="btn btn-sm btn-danger removeRoomBtn">
          <i class="bi bi-trash"></i>
        </button>
      </td>
    </tr>
  `;
}

document.addEventListener('change', function (e) {
  if (!e.target.classList.contains('roomSelect')) return;

  const select = e.target;
  const roomId = select.value;
  if (!roomId) return;

  const row = select.closest('tr');
  const propertyBlock = select.closest('.propertyBlock');

  const leadId = document.getElementById('leads_id_hidden').value || '';
  const propertyId = propertyBlock?.dataset.propertyId || '';

  // set hidden inputs
  row.querySelector('.roomInput').value = roomId;
  row.querySelector('.pkgRoomInput').value = '0'; // since it's new manual add, no package_room_id

  // set edit button dataset
  const editBtn = row.querySelector('.editRoomBtn');
  if (editBtn) {
    editBtn.dataset.leadId = leadId;
    editBtn.dataset.propertyId = propertyId;
    editBtn.dataset.roomCategoryId = roomId;
  }

  // mark for validation
  row.dataset.roomId = roomId;
});


document.addEventListener('change', function (e) {

    if (!e.target.classList.contains('roomSelect')) return;

    const select = e.target;
    const row = select.closest('tr');
    const propertyBlock = select.closest('.propertyBlock');

    const roomId = select.value;
    if (!roomId) return;

    let duplicate = false;

    // check preloaded rooms
    propertyBlock.querySelectorAll('tr[data-room-id]').forEach(tr => {
        if (tr.dataset.roomId === roomId) duplicate = true;
    });

    // check newly added rooms
    propertyBlock.querySelectorAll('.roomSelect').forEach(other => {
        if (other !== select && other.value === roomId) duplicate = true;
    });

    if (duplicate) {
        alert('Room already selected');
        select.value = '';
        return;
    }

    const selectedOption = select.options[select.selectedIndex];

    // ✅ CRITICAL: store IDs
    row.dataset.roomId = roomId;
    row.dataset.packagesRoomId = selectedOption.dataset.packageRoomId;

    row.querySelector('.roomInput').value = roomId;
    row.querySelector('.pkgRoomInput').value =
        selectedOption.dataset.packageRoomId;
});

document.addEventListener('click', function (e) {

    const btn = e.target.closest('.addRoomBtn');
    if (!btn) return;

    const propertyBlock = btn.closest('.propertyBlock');
    const tbody = propertyBlock.querySelector('tbody');
    const propertyId = propertyBlock.dataset.propertyId;

    fetch(`<?php echo base_url(); ?>index.php/Quotation/get_rooms?properties_id=${propertyId}`)
        .then(res => res.json())
        .then(res => {
            if (!res.status || !res.data.length) return;

            tbody.insertAdjacentHTML(
                'beforeend',
                getRoomRowTemplate(propertyId, res.data)
            );
        });
});


document.addEventListener('click', function (e) {

    const btn = e.target.closest('.removeRoomBtn');
    if (!btn) return;

    btn.closest('tr').remove();
});

function parseDayDestValue(val) {
  // "dayId|stayDestId|date"
  const parts = (val || '').split('|');
  return {
    packages_properties_days_id_fk: parts[0] ? parseInt(parts[0], 10) : 0,
    stay_destination_id_fk: parts[1] ? parseInt(parts[1], 10) : 0,
    accommodation_date: parts[2] || ''
  };
}


function buildQuotationPayload() {

    const payload = { options: [], inclusions: [], special_requirements: [] };

    // Loop through each option block
    document.querySelectorAll('.optionBlock').forEach(optionBlock => {

        const option = {
            packages_properties_common_id_fk:
                optionBlock.querySelector('.propertyDropdown')?.value || '',
            title:
                optionBlock.querySelector('[name="quotation_options_title[]"]')?.value || '',
            cab_amount:
                optionBlock.querySelector('[name="quotation_options_cab_amount[]"]')?.value || '',
            
            // ✅ NEW: save exactly what UI calculated
            quotation_options_total_cost:
                optionBlock.querySelector('.optionTotalCostInput')?.value || '0',

            // store 'percent' or 'amount' (same as your UI)
            quotation_options_margin_type:
                optionBlock.querySelector('.optionMarginType')?.value || 'amount',

            quotation_options_margin_value:
                optionBlock.querySelector('.optionMarginValue')?.value || '0',

            quotation_options_total_quote_rate:
            optionBlock.querySelector('.optionQuoteTotalInput')?.value || '0',
            days: []
        };

        // Loop only actual day rows in itinerary table (skip room/property rows)
        optionBlock.querySelectorAll('.itineraryContainer tbody > tr').forEach(dayRow => {

            // Only process rows that contain day inputs
            const dayIdInput = dayRow.querySelector('[name="packages_properties_days_id_fk[]"]');
            if (!dayIdInput) return; // skip non-day rows

            const day = {
                packages_properties_days_id_fk: dayIdInput.value,
                day: dayRow.querySelector('[name="quotation_properties_days_day[]"]')?.value || '',
                destination_id: dayRow.querySelector('[name="quotation_properties_days_destination_id_fk[]"]')?.value || '',
                properties: []
            };

            // Loop properties within this day
            const propertiesContainer = dayRow.querySelector('.propertiesContainer');
            if (propertiesContainer) {
                propertiesContainer.querySelectorAll('.propertyBlock').forEach(propertyBlock => {

                    const property = {
                        packages_properties_id_fk: propertyBlock.dataset.packagesPropertyId || 0,
                        properties_id_fk: propertyBlock.dataset.propertyId || 0,
                        rooms: []
                    };

                    
                    // Loop rooms within this property
                    propertyBlock.querySelectorAll('tbody tr').forEach(roomRow => {
                        if (!roomRow.dataset.roomId) return;

                        //READ TOTAL ROOM COST from the row (you must have this hidden input in the row)
            const totalRoomCost =
              roomRow.querySelector('input.autoCalcRateInput')?.value ||
              roomRow.querySelector('[name="total_room_cost[]"]')?.value ||
              '0';
                        property.rooms.push({
                            packages_properties_rooms_id_fk: roomRow.dataset.packagesRoomId || 0,
                            quotation_properties_rooms_id_fk: roomRow.dataset.roomId,
                             // ✅ NEW FIELD (will go to DB later)
              total_room_cost: totalRoomCost
                        });
                    });

                    day.properties.push(property);
                });
            }

            option.days.push(day);
        });

        payload.options.push(option);
    });


        // ================= INCLUSIONS =================
    payload.inclusions = [];
    document.querySelectorAll('#inclusionTable tbody tr').forEach(tr => {
      const dayKey = tr.querySelector('[name="inclusion_day_key[]"]')?.value || '';
      const name = tr.querySelector('[name="inclusion_name[]"]')?.value || '';
      const amount = tr.querySelector('[name="inclusion_amount[]"]')?.value || '';

      if (!dayKey || !name) return;

      payload.inclusions.push({ dayKey, name, amount });
    });

    // ================= SPECIAL REQUIREMENTS =================
    payload.special_requirements = [];
    document.querySelectorAll('#specialReqTable tbody tr').forEach(tr => {
      const dayKey = tr.querySelector('[name="specialreq_day_key[]"]')?.value || '';
      const reqId = tr.querySelector('[name="quotation_special_requirements_id_fk[]"]')?.value || '';
      const cost = tr.querySelector('[name="special_requirements_cost[]"]')?.value || '';

      if (!dayKey || !reqId) return;

      payload.special_requirements.push({
        dayKey,
        quotation_special_requirements_id_fk: reqId,
        cost
      });
    });

    return payload;
}

    function recalcAllOptionsBeforeSave() {
  document.querySelectorAll('.optionBlock').forEach(ob => recalcOptionTotals(ob));
}


////////////********** *************///////////


function setHtmlSafe(selector, html) {
    const el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}

function setTextSafe(selector, text) {
    const el = document.querySelector(selector);
    if (el) el.textContent = text;
}

/* ================= EDIT ROOM BUTTON (ENQUIRY ONLY) ================= */
/* helpers (keep yours) */
/* ================= SAFE HELPERS ================= */
function setHtmlSafe(selector, html) {
    const el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}
function setTextSafe(selector, text) {
    const el = document.querySelector(selector);
    if (el) el.textContent = text;
}


/***********************
 *  POLICY AGE HELPERS
 ***********************/
function toInt(v, def = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}

function inRange(age, from, to) {
  if (!Number.isFinite(age)) return false;
  if (!Number.isFinite(from) || !Number.isFinite(to)) return false;
  return age >= from && age <= to;
}

function normalizeYesNo(v) {
  const s = String(v ?? '').trim().toLowerCase();
  return (s === 'y' || s === 'yes' || s === '1' || s === 'true');
}

/**
 * Build room policy age ranges string:
 * Baby 2-3 YR | Child 4-14 YR OR Baby - | Child -
 */
function getRoomPolicyAgeText(room) {
  const babyType = normalizeYesNo(room.properties_room_category_complimentary_guest_between_type);
  const babyFrom = toInt(room.properties_room_category_complimentary_guest_between_from_year, 0);
  const babyTo   = toInt(room.properties_room_category_complimentary_guest_between_to_year, 0);

  const childType = normalizeYesNo(room.properties_room_category_child_rate_applied_guest_between_type);
  const childFrom = toInt(room.properties_room_category_child_rate_applied_guest_from_year, 0);
  const childTo   = toInt(room.properties_room_category_child_rate_applied_guest_to_year, 0);

  const babyTxt  = (babyType && babyFrom > 0 && babyTo > 0) ? `Baby ${babyFrom}-${babyTo} YR` : `Baby -`;
  const childTxt = (childType && childFrom > 0 && childTo > 0) ? `Child ${childFrom}-${childTo} YR` : `Child -`;

  return `${babyTxt} | ${childTxt}`;
}

/***********************
 *  APPLIED PLAN (AGE BASED)
 *  Turns enquiry children ages into: adult/child/baby counts
 ***********************/
function computeAppliedCountsFromAges(room, enquiryPlan, childAges) {
  // enquiryPlan: { adults, children } from guset_count_details
  // childAges: [{age, count}, ...] from child_age_break_up

  const welcomesAll = normalizeYesNo(room.properties_room_category_welcomes_child_all_ages);
  const restrictUnder = toInt(room.properties_room_category_admission_restricted_guests_under_age, 0);

  const compType = normalizeYesNo(room.properties_room_category_complimentary_guest_between_type);
  const compFrom = toInt(room.properties_room_category_complimentary_guest_between_from_year, 0);
  const compTo   = toInt(room.properties_room_category_complimentary_guest_between_to_year, 0);

  const childType = normalizeYesNo(room.properties_room_category_child_rate_applied_guest_between_type);
  const childFrom = toInt(room.properties_room_category_child_rate_applied_guest_from_year, 0);
  const childTo   = toInt(room.properties_room_category_child_rate_applied_guest_to_year, 0);

  const adultOver = toInt(room.properties_room_category_adult_rate_applied_guest_over, 0);

  let adults = toInt(enquiryPlan.adults, 0);
  let children = 0;
  let baby = 0;

  let hasUnderRestrictedChild = false;

  // If you didn’t store ages, fall back to enquiryPlan.children
  const ageRows = Array.isArray(childAges) && childAges.length
    ? childAges
    : (toInt(enquiryPlan.children, 0) ? [{ age: null, count: toInt(enquiryPlan.children, 0) }] : []);

  ageRows.forEach(row => {
    const age = row.age === null ? null : toInt(row.age, NaN);
    const cnt = toInt(row.count, 0);
    if (cnt <= 0) return;

    // If no age info => treat as "child" unless rule #1 forces adult
    if (age === null || !Number.isFinite(age)) {
      // Rule 1: adultOver == 0 AND welcomesAll==Y AND restrictUnder==0 => child becomes adult
      if (adultOver === 0 && welcomesAll && (!restrictUnder || restrictUnder === 0)) {
        adults += cnt;
      } else {
        children += cnt;
      }
      return;
    }

    // Rule 2: restricted age -> convert to adult and flag warning
    if (!welcomesAll && restrictUnder > 0 && age < restrictUnder) {
      adults += cnt;
      hasUnderRestrictedChild = true;
      return;
    }

    // Rule 3: complimentary range => baby
    if (compType && compFrom > 0 && compTo > 0 && inRange(age, compFrom, compTo)) {
      baby += cnt;
      return;
    }

    // Rule 4: child rate range => child
    if (childType && childFrom > 0 && childTo > 0 && inRange(age, childFrom, childTo)) {
      children += cnt;
      return;
    }

    // Adult rule by age
    if (adultOver > 0 && age >= adultOver) {
      adults += cnt;
      return;
    }

    // Rule 1 again (welcomes + adultOver==0)
    if (adultOver === 0 && welcomesAll && (!restrictUnder || restrictUnder === 0)) {
      adults += cnt;
      return;
    }

    // default => child
    children += cnt;
  });

  return {
    applied: { adults, children, baby },
    warnings: {
      restrictUnder,
      hasUnderRestrictedChild
    }
  };
}

/***********************
 *  CORE ALLOCATOR
 *  Uses policy db/eb/sb like your examples
 *
 *  Interpretation:
 *  - db = number of adults allowed per room WITHOUT extra bed
 *  - eb = extra adult capacity per room (extra beds)
 *  - sb = sharing-bed capacity per room for baby/child
 ***********************/
function autoAllocate(policy, applied) {
  const db = toInt(policy.db, 0);
  const eb = toInt(policy.eb, 0);
  const sb = toInt(policy.sb, 0);

  let adults = toInt(applied.adults, 0);
  let children = toInt(applied.children, 0);
  let baby = toInt(applied.baby, 0);

  // outputs
  const out = {
    eligible: true,
    // pax-wise
    pax: {
      adult: { db: 0, eb: 0, sb: 0, sgl: 0 },
      child: { db: 0, eb: 0, sb: 0, sgl: 0 },
      baby:  { db: 0, eb: 0, sb: 0, sgl: 0 },
    },
    // rooming plan inputs (counts only)
    plan: {
      rooms_units: 0,
      extra_bed_adult: 0,
      child_sharing_bed: 0,
      single_occupancy: 0
    },
    // messages under pax box
    notes: {
      surplus: { db: 0, eb: 0, sb: 0 },
      excess:  { eb: 0 },
      alerts: []
    }
  };

  // ======= Scenario 1: all zero => not eligible
  if (db === 0 && eb === 0 && sb === 0) {
    out.eligible = false;
    out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB count.');
    return out;
  }

  // ======= Adult-only invalid: db=0 sb>0 eb=0
  if (adults > 0 && children === 0 && baby === 0 && db === 0 && eb === 0 && sb > 0) {
    out.eligible = false;
    out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB count.');
    return out;
  }

  // ======= Adult-only: 1 adult special SGL rules
  if (adults === 1 && children === 0 && baby === 0) {

    // scenario 2: db>=1 eb=0 => SGL 1
    if (db >= 1 && eb === 0) {
      out.pax.adult.sgl = 1;
      out.plan.single_occupancy = 1;
      out.plan.rooms_units = 1;
      return out;
    }

    // scenario 3: db=0 eb>=1 => SGL 1 and EB 1
    if (db === 0 && eb >= 1) {
      out.pax.adult.sgl = 1;
      out.pax.adult.eb = 1;
      out.plan.single_occupancy = 1;
      out.plan.extra_bed_adult = 1;
      out.plan.rooms_units = 1;
      out.notes.excess.eb = 1; // "Excess Bed Utilization: EB:1"
      return out;
    }

    // scenario 4: db=0 sb>=1 eb=0 already handled invalid above
  }

  // ======= General Adult allocation (your examples 5-14 etc.)
  // If db == 0 and adults > 0, only EB can host adults (rare but you used it)
  // We'll treat room base capacity = db + eb. If db=0, capacity = eb.
  const capAdultPerRoom = db + eb;

  if (adults > 0) {

    // If cap is 0 but adults exist => not eligible
    if (capAdultPerRoom <= 0) {
      out.eligible = false;
      out.notes.alerts.push('This room is not eligible for booking this lead. Please update DB/EB policy.');
      return out;
    }

    // rooms needed
    const rooms = Math.ceil(adults / capAdultPerRoom);

    // DB utilization means: rooms count (like your examples)
    // For db=1 -> adult DB becomes adults because rooms = adults when cap=1
    // For db=2 -> adult DB becomes rooms (e.g. 8 adults => rooms 4)
    // BUT you display "Adult DB" as number of rooms (units). That matches your examples.
    out.pax.adult.db = rooms; // number of rooms
    out.plan.rooms_units = rooms;

    // base beds available for adults inside rooms = rooms * db
    const baseBedSlots = rooms * db;

    // extra adults beyond base => EB used
    let needExtra = Math.max(0, adults - baseBedSlots);

    // EB capacity total
    const ebCap = rooms * eb;

    // clamp
    if (needExtra > ebCap) {
      // should not happen if rooms computed from capAdultPerRoom,
      // but keep safe
      needExtra = ebCap;
      out.notes.alerts.push('Not enough EB capacity for this enquiry.');
    }

    out.pax.adult.eb = needExtra;
    out.plan.extra_bed_adult = needExtra;

    // Surplus EB (when eb policy exists and not fully used)
    if (eb > 0) {
      out.notes.surplus.eb = Math.max(0, ebCap - needExtra);
    }

    // Special: if db=0 and adults hosted only by EB => mark EB “excess”
    if (db === 0 && needExtra > 0) {
      out.notes.excess.eb = needExtra;
    }

    // Special: if adults==1 and db>=1 but eb>0, still your rule says SGL
    // We already handled adults===1 earlier, but keep safe
    if (adults === 1) {
      out.pax.adult.db = 0;
      out.pax.adult.eb = (db === 0 ? 1 : 0);
      out.pax.adult.sgl = 1;
      out.plan.rooms_units = 1;
      out.plan.single_occupancy = 1;
    }
  }

  // ======= Child/Baby allocation into SB (per room)
  // Your later scenarios use SB for baby/child “sharing bed”.
  // We allocate sharing beds across rooms calculated above.
  const roomsCount = Math.max(1, out.plan.rooms_units || 0);
  const sbCapTotal = roomsCount * sb;
  const needSB = children + baby;

  const useSB = Math.min(sbCapTotal, needSB);
  out.plan.child_sharing_bed = useSB;

  // split SB usage: prefer baby first, then child (common)
  const babySB = Math.min(baby, useSB);
  const childSB = Math.max(0, useSB - babySB);

  out.pax.baby.sb = babySB;
  out.pax.child.sb = childSB;

  // Surplus SB
  if (sb > 0) out.notes.surplus.sb = Math.max(0, sbCapTotal - useSB);

  // If there are remaining child/baby not placed
  const remain = needSB - useSB;
  if (remain > 0) {
    out.notes.alerts.push('Not enough SB capacity for child/baby. Please adjust rooming manually.');
  }

  // Surplus DB (when db per room > what is required per room, like your db=4 example)
  // In your example: adults=9, db=4 => rooms=3, baseBedSlots=12, unused base beds = 3
  // You show "Surplus Bed Available: DB:3"
  const unusedBaseBeds = Math.max(0, (roomsCount * db) - adults);
  out.notes.surplus.db = unusedBaseBeds;

  return out;
}

/***********************
 *  APPLY ALLOCATION TO MODAL UI
 ***********************/
function applyAllocationToModal(allocation) {
  // reset message areas if you have them
  setTextSafe('#paxNoteSurplus', '');
  setTextSafe('#paxNoteExcess', '');
  setTextSafe('#paxNoteAlert', '');

  // pax-wise spans
  setTextSafe('[data-role="adult-db"]', allocation.pax.adult.db);
  setTextSafe('[data-role="adult-eb"]', allocation.pax.adult.eb);
  setTextSafe('[data-role="adult-sb"]', allocation.pax.adult.sb);
  setTextSafe('[data-role="adult-sgl"]', allocation.pax.adult.sgl);

  setTextSafe('[data-role="child-db"]', allocation.pax.child.db);
  setTextSafe('[data-role="child-eb"]', allocation.pax.child.eb);
  setTextSafe('[data-role="child-sb"]', allocation.pax.child.sb);
  setTextSafe('[data-role="child-sgl"]', allocation.pax.child.sgl);

  setTextSafe('[data-role="baby-db"]', allocation.pax.baby.db);
  setTextSafe('[data-role="baby-eb"]', allocation.pax.baby.eb);
  setTextSafe('[data-role="baby-sb"]', allocation.pax.baby.sb);
  setTextSafe('[data-role="baby-sgl"]', allocation.pax.baby.sgl);

  // rooming plan input fields (Auto)
  // Use your modal input names/ids; adjust selectors if different.
  const autoRooms = document.querySelector('[name="auto_room_member_count"]');
  const autoEB    = document.querySelector('[name="auto_extra_bed_adult_count"]');
  const autoSB    = document.querySelector('[name="auto_child_sharing_bed_count"]');
  const autoSGL   = document.querySelector('[name="auto_single_occupancy_count"]');

  if (autoRooms) autoRooms.value = allocation.plan.rooms_units;
  if (autoEB)    autoEB.value    = allocation.plan.extra_bed_adult;
  if (autoSB)    autoSB.value    = allocation.plan.child_sharing_bed;
  if (autoSGL)   autoSGL.value   = allocation.plan.single_occupancy;

  // rooming plan input fields (Manual) default same as auto
  const manRooms = document.querySelector('[name="manual_count"]');
  const manEB    = document.querySelector('[name="manual_extra_bed_adult_count"]');
  const manSB    = document.querySelector('[name="manual_child_sharing_bed_count"]');
  const manSGL   = document.querySelector('[name="manual_single_occupancy_count"]');

  if (manRooms) manRooms.value = allocation.plan.rooms_units;
  if (manEB)    manEB.value    = allocation.plan.extra_bed_adult;
  if (manSB)    manSB.value    = allocation.plan.child_sharing_bed;
  if (manSGL)   manSGL.value   = allocation.plan.single_occupancy;

  // notes
  const surplusParts = [];
  if (allocation.notes.surplus.db > 0) surplusParts.push(`DB:${allocation.notes.surplus.db}`);
  if (allocation.notes.surplus.eb > 0) surplusParts.push(`EB:${allocation.notes.surplus.eb}`);
  if (allocation.notes.surplus.sb > 0) surplusParts.push(`SB:${allocation.notes.surplus.sb}`);

  if (surplusParts.length) {
    setTextSafe('#paxNoteSurplus', `Surplus Bed Available: ${surplusParts.join(' ')}`);
  }

  if (allocation.notes.excess.eb > 0) {
    setTextSafe('#paxNoteExcess', `Excess Bed Utilization: EB:${allocation.notes.excess.eb}`);
  }

  if (allocation.notes.alerts.length) {
    setTextSafe('#paxNoteAlert', allocation.notes.alerts.join(' | '));
  }
}


/* ================= EDIT ROOM BUTTON (FULL) ================= */
function setHtmlSafe(selector, html) {
    var el = document.querySelector(selector);
    if (el) el.innerHTML = html;
}
function setTextSafe(selector, text) {
    var el = document.querySelector(selector);
    if (el) el.textContent = (text === undefined || text === null) ? '' : String(text);
}
function setTextSafeIn(modalEl, selector, text) {
    if (!modalEl) return;
    var el = modalEl.querySelector(selector);
    if (el) el.textContent = (text === undefined || text === null) ? '' : String(text);
}
function setHtmlSafeIn(modalEl, selector, html) {
    if (!modalEl) return;
    var el = modalEl.querySelector(selector);
    if (el) el.innerHTML = html || '';
}

document.addEventListener('click', function (e) {

    var btn = e.target.closest('.editRoomBtn');
    if (!btn) return;

    var leadId         = btn.dataset.leadId || '';
    var propertyId     = btn.dataset.propertyId || '';
    var roomCategoryId = btn.dataset.roomCategoryId || '';
    var propertyDayId  = btn.dataset.propertyDayId || '';
    var stayDestId     = btn.dataset.stayDestinationId || '';

    if (!leadId || !propertyId || !roomCategoryId || !propertyDayId || !stayDestId) {
        alert('Missing lead/property/room/day/destination details');
        console.log({ leadId: leadId, propertyId: propertyId, roomCategoryId: roomCategoryId, propertyDayId: propertyDayId, stayDestId: stayDestId });
        return;
    }

    var modalEl = document.getElementById('roompricingandguestallocationModal');
    if (!modalEl) {
        alert('Modal not found in page');
        return;
    }

    // store last clicked button row for UI update after save
window.__lastRoomEditBtn = btn;

// day row (itinerary day row)
const dayRow = btn.closest('.itineraryDayRow'); 
const dayId = dayRow?.querySelector('[name="packages_properties_days_id_fk[]"]')?.value || '';

// room row id (quotation_properties_rooms_id_fk)
// you already store room row id in hidden input inside the room row:
const roomTr = btn.closest('tr');
const qpRoomId = roomTr?.querySelector('[name="packages_properties_rooms_id_fk[]"]')?.value || '';

document.getElementById('modal_packages_properties_days_id_fk').value = dayId;
document.getElementById('modal_quotation_properties_rooms_id_fk').value = qpRoomId;

    /* ================= RESET MODAL ================= */
    setTextSafeIn(modalEl, '#modalTotalRate', '0');
    setTextSafeIn(modalEl, '#modalLeadInfo', 'Loading...');
    setTextSafeIn(modalEl, '#modalRoomInfo', 'Loading...');
    setTextSafeIn(modalEl, '[data-role="room-policy"]', 'Loading...');
    setTextSafeIn(modalEl, '[data-role="meal-plan"]', '-');

    // Room policy age line (Baby/Child range)
    setTextSafeIn(modalEl, '[data-role="room-policy-ages"]', 'Baby - | Child -');

    // ✅ In Enquiry reset (Adult + Child only)
    setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
    setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
    setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', '-');

    // ✅ Applied reset (Adult + Child + Baby + meal)
    setTextSafeIn(modalEl, '[data-role="applied-adult"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-child"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-baby"]', '0');
    setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
    setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', '');
    setHtmlSafeIn(modalEl, '#appliedMealWarningWrap', '');

    // ✅ reset pax-wise bed utilization spans
    var spans = modalEl.querySelectorAll('[data-role^="adult-"],[data-role^="child-"],[data-role^="baby-"]');
    for (var i = 0; i < spans.length; i++) spans[i].textContent = '0';

    // ✅ hidden fields
    var modalLead = document.getElementById('modal_lead_id');
    var modalProp = document.getElementById('modal_property_id');
    var modalRoom = document.getElementById('modal_room_category_id');
    if (modalLead) modalLead.value = leadId;
    if (modalProp) modalProp.value = propertyId;
    if (modalRoom) modalRoom.value = roomCategoryId;

    // ✅ open modal first
    // bootstrap.Modal.getOrCreateInstance(modalEl).show();
//     $('#roompricingandguestallocationModal').modal({
//   backdrop: 'static',
//   keyboard: false,
//   show: true
// });
$('#roompricingandguestallocationModal').modal('show'); // show bootstrap modal

    /* ================= API URLS ================= */
    var urlPolicy =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_room_policy_details` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    var urlEnquiry =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_in_enquiry_context` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_day_id=${encodeURIComponent(propertyDayId)}` +
        `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    var urlApplied =
        `<?php echo base_url(); ?>index.php/Quotation/ajax_get_applied_plan_context` +
        `?lead_id=${encodeURIComponent(leadId)}` +
        `&property_day_id=${encodeURIComponent(propertyDayId)}` +
        `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
        `&property_id=${encodeURIComponent(propertyId)}` +
        `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

    /* ================= LOAD ALL ================= */
    Promise.all([
        fetch(urlPolicy).then(function (r) { return r.json(); }),
        fetch(urlEnquiry).then(function (r) { return r.json(); }),
        fetch(urlApplied).then(function (r) { return r.json(); })
    ])
    .then(function (responses) {

        var policyRes = responses[0];
        var enquiryRes = responses[1];
        var appliedRes = responses[2];

        /* ================= POLICY UI ================= */
        var policy = { db: 0, eb: 0, sb: 0 };

        if (policyRes && policyRes.status) {

            var lead = (policyRes.data && policyRes.data.lead) ? policyRes.data.lead : {};
            var property = (policyRes.data && policyRes.data.property) ? policyRes.data.property : {};
            var room = (policyRes.data && policyRes.data.room) ? policyRes.data.room : {};

            var db  = parseInt(room.properties_room_category_number_of_adults_allowed, 10);
            var eb  = parseInt(room.properties_room_category_extra_bed_mattress_allowed_in_room, 10);
            var sb  = parseInt(room.properties_room_category_children_allowed_on_bed_sharing_basis, 10);
            var inv = room.properties_room_category_inventory;

            if (isNaN(db)) db = 0;
            if (isNaN(eb)) eb = 0;
            if (isNaN(sb)) sb = 0;
            if (inv === undefined || inv === null) inv = 0;

            policy = { db: db, eb: eb, sb: sb };

            setTextSafeIn(modalEl, '#modalLeadInfo', 'Lead No: ' + (lead.leads_number || '-'));

            setHtmlSafeIn(
                modalEl,
                '#modalRoomInfo',
                (property.properties_name || '-') + '<br>' +
                (room.properties_room_category_name || '-') + '<br>' +
                'DB:' + db + ' | EB:' + eb + ' | SB:' + sb + ' | Inventory:' + inv
            );

            setTextSafeIn(modalEl, '[data-role="room-policy"]', 'DB:' + db + ' | EB:' + eb + ' | SB:' + sb + ' | Inventory:' + inv);

            // Room default meal plan name
            setTextSafeIn(modalEl, '[data-role="meal-plan"]', room.meal_plan_name || '-');

            // Baby/Child age range text from backend (if you return it)
            var agesTxt = (policyRes.data && policyRes.data.policy_ages_text) ? policyRes.data.policy_ages_text : '';
            setTextSafeIn(modalEl, '[data-role="room-policy-ages"]', agesTxt ? agesTxt : 'Baby - | Child -');
        }

        /* ================= IN ENQUIRY UI ================= */
        if (enquiryRes && enquiryRes.status) {

            var eqData = enquiryRes.data ? enquiryRes.data : {};
            var eqPlan = eqData.plan ? eqData.plan : null;

            setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', eqData.meal_plan_name || '-');

            if (eqPlan) {
                setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', (eqPlan.adults !== undefined && eqPlan.adults !== null) ? eqPlan.adults : 0);
                setTextSafeIn(modalEl, '[data-role="enquiry-child"]', (eqPlan.children !== undefined && eqPlan.children !== null) ? eqPlan.children : 0);
            } else {
                setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
                setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
            }

        } else {
            setTextSafeIn(modalEl, '[data-role="enquiry-adult"]', '0');
            setTextSafeIn(modalEl, '[data-role="enquiry-child"]', '0');
            setTextSafeIn(modalEl, '[data-role="enquiry-meal"]', '-');
        }

        /* ================= APPLIED UI ================= */
        var appliedPlan = { adults: 0, children: 0, baby: 0 };

        setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
        setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', '');
        setHtmlSafeIn(modalEl, '#appliedMealWarningWrap', '');

        if (appliedRes && appliedRes.status) {

            var apData = appliedRes.data ? appliedRes.data : {};

            // Applied meal name
            setTextSafeIn(modalEl, '[data-role="applied-meal"]', apData.meal_plan_name || '-');

            // mismatch icon (ONLY for applied meal)data-bs-placement="top"
            if (parseInt(apData.meal_plan_mismatch, 10) === 1) {

                setHtmlSafeIn(modalEl, '#mealMismatchIconWrap', (
                    '<span class="ms-2 text-warning" ' +
                    'data-bs-toggle="tooltip" data-placement="top" ' +
                    'title="Room\'s default meal plan is overridden by the enquiry meal plan">' +
                    '<i class="bi bi-exclamation-triangle-fill"></i>' +
                    '</span>'
                ));

                var wrap = modalEl.querySelector('#mealMismatchIconWrap');
                var tipEl = wrap ? wrap.querySelector('[data-bs-toggle="tooltip"]') : null;
                // if (tipEl) new bootstrap.Tooltip(tipEl);
                if (tipEl) $(tipEl).tooltip();
            }

            // EP room-only warning: room default meal plan id = 2
            if (parseInt(apData.room_is_ep_room_only, 10) === 1) {
                setHtmlSafeIn(modalEl, '#appliedMealWarningWrap',
                    '<div class="text-danger mt-2"><small>' +
                    'Meal rates not found. Update rates or enter manually in the supplement cost field.' +
                    '</small></div>'
                );
            }

            // Applied counts computed in backend (adult/child/baby)
            if (apData.applied) {
                appliedPlan.adults = parseInt(apData.applied.adults, 10); if (isNaN(appliedPlan.adults)) appliedPlan.adults = 0;
                appliedPlan.children = parseInt(apData.applied.children, 10); if (isNaN(appliedPlan.children)) appliedPlan.children = 0;
                appliedPlan.baby = parseInt(apData.applied.baby, 10); if (isNaN(appliedPlan.baby)) appliedPlan.baby = 0;
            }

            setTextSafeIn(modalEl, '[data-role="applied-adult"]', appliedPlan.adults);
            setTextSafeIn(modalEl, '[data-role="applied-child"]', appliedPlan.children);
            setTextSafeIn(modalEl, '[data-role="applied-baby"]', appliedPlan.baby);

        } else {
            setTextSafeIn(modalEl, '[data-role="applied-adult"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-child"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-baby"]', '0');
            setTextSafeIn(modalEl, '[data-role="applied-meal"]', '-');
        }

        /* ================= AUTO ALLOCATION ================= */
        if (typeof autoAllocateBeds === 'function' && typeof applyAutoAllocationToModal === 'function') {
            var allocation = autoAllocateBeds(policy, appliedPlan);
            applyAutoAllocationToModal(allocation);

            // 1) copy auto -> manual so manual starts same
            syncAutoToManualCountsAndRates();

           // 2) calculate amounts + totals for both
           refreshAllAmountsAndTotals();

        }

        const urlTariff =
    `<?php echo base_url(); ?>index.php/Quotation/ajax_get_tariff_by_context` +
    `?lead_id=${encodeURIComponent(leadId)}` +
    `&property_day_id=${encodeURIComponent(propertyDayId)}` +
    `&stay_destination_id=${encodeURIComponent(stayDestId)}` +
    `&property_id=${encodeURIComponent(propertyId)}` +
    `&room_category_id=${encodeURIComponent(roomCategoryId)}`;

fetch(urlTariff)
  .then(r => r.json())
  .then(tariffRes => {
      applyTariffRatesToModal(tariffRes);
      calcTotalFromAuto(); // optional
  })
  .catch(err => console.error('Tariff API error', err));


    })
    .catch(function (err) {
        console.error(err);
        alert('Error loading modal data');
    });

});





/* ================= Auto Allocation ================= */
function autoAllocateBeds(policy, applied) {

    const roomDB = Number(policy.db || 0);
    const roomEB = Number(policy.eb || 0);
    const roomSB = Number(policy.sb || 0);

    let adults = Number(applied.adults || 0);
    let children = Number(applied.children || 0);
    let baby = Number(applied.baby || 0);

    const dbCap = roomDB > 0 ? roomDB : 2;

    // ===== Adults -> Rooms/DB/EB =====
    let rooms = Math.ceil(adults / dbCap);
    if (rooms < 1 && adults > 0) rooms = 1;

    let adultsInDB = Math.min(adults, rooms * dbCap);
    let remainingAdults = adults - adultsInDB;

    let adultsInEB = 0;

    if (remainingAdults > 0 && roomEB > 0) {
        const ebCapacityTotal = rooms * roomEB;
        adultsInEB = Math.min(remainingAdults, ebCapacityTotal);
        remainingAdults -= adultsInEB;
    }

    while (remainingAdults > 0) {
        rooms += 1;

        const takeDB = Math.min(dbCap, remainingAdults);
        adultsInDB += takeDB;
        remainingAdults -= takeDB;

        if (roomEB > 0 && remainingAdults > 0) {
            const takeEB = Math.min(roomEB, remainingAdults);
            adultsInEB += takeEB;
            remainingAdults -= takeEB;
        }
    }

    // SGL (approx): if remainder is 1 adult in last room
    let remDB = adults % dbCap;
    let adultSGLRooms = (dbCap > 1 && remDB === 1) ? 1 : 0;

    // ===== Children/Baby -> SB =====
    let sbCapacityTotal = rooms * roomSB;

    let childInSB = Math.min(children, sbCapacityTotal);
    let remainingChildren = children - childInSB;

    let babyInSB = Math.min(baby, Math.max(0, sbCapacityTotal - childInSB));
    let remainingBaby = baby - babyInSB;

    let extraChildRooms = 0;

    while ((remainingChildren + remainingBaby) > 0) {

        if (roomSB <= 0) break;

        extraChildRooms += 1;

        const takeChild = Math.min(roomSB, remainingChildren);
        remainingChildren -= takeChild;

        const freeSB = roomSB - takeChild;
        const takeBaby = Math.min(freeSB, remainingBaby);
        remainingBaby -= takeBaby;
    }

    return {
        totalRooms: rooms + extraChildRooms,
        adult: { db: Math.max(0, adults - adultsInEB), eb: adultsInEB, sb: 0, sgl: adultSGLRooms },
        child: { db: 0, eb: 0, sb: (children - remainingChildren), sgl: 0 },
        baby: { db: 0, eb: 0, sb: (baby - remainingBaby), sgl: 0 },
        warnings: { unallocatedChildren: remainingChildren, unallocatedBaby: remainingBaby }
    };
}

function setValSafe(selector, val) {
    const el = document.querySelector(selector);
    if (el) el.value = (val ?? 0);
}

function applyAutoAllocationToModal(result) {

    // ---------------------------
    // AUTO ROOMING PLAN INPUTS
    // ---------------------------
    setValSafe('#roompricingandguestallocationModal [name="auto_room_member_count"]', result.totalRooms ?? 0);

    // If your autoAllocateBeds also calculates these, use them.
    // If not, they will become 0 (safe).
    setValSafe('#roompricingandguestallocationModal [name="auto_extra_bed_adult_count"]', result.adult?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_extra_bed_child_count"]', result.child?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_child_sharing_bed_count"]', result.child?.sb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_single_occupancy_count"]', result.adult?.sgl ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="auto_supplment_cost_count"]', 0); // later

    // ---------------------------
    // ✅ MANUAL DEFAULTS = SAME AS AUTO
    // ---------------------------
    setValSafe('#roompricingandguestallocationModal [name="manual_count"]', result.totalRooms ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_extra_bed_adult_count"]', result.adult?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_extra_bed_child_count"]', result.child?.eb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_child_sharing_bed_count"]', result.child?.sb ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_single_occupancy_count"]', result.adult?.sgl ?? 0);
    setValSafe('#roompricingandguestallocationModal [name="manual_supplment_cost_count"]', 0); // later

    // ---------------------------
    // PAX-WISE BED UTILIZATION
    // ---------------------------
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-db"]',  result.adult?.db  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-eb"]',  result.adult?.eb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-sb"]',  result.adult?.sb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="adult-sgl"]', result.adult?.sgl ?? 0);

    setTextSafe('#roompricingandguestallocationModal [data-role="child-db"]',  result.child?.db  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-eb"]',  result.child?.eb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-sb"]',  result.child?.sb  ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="child-sgl"]', result.child?.sgl ?? 0);

    setTextSafe('#roompricingandguestallocationModal [data-role="baby-db"]',   result.baby?.db   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-eb"]',   result.baby?.eb   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-sb"]',   result.baby?.sb   ?? 0);
    setTextSafe('#roompricingandguestallocationModal [data-role="baby-sgl"]',  result.baby?.sgl  ?? 0);

    // ---------------------------
    // WARNINGS (optional)
    // ---------------------------
    if (result.warnings && (result.warnings.unallocatedChildren > 0 || result.warnings.unallocatedBaby > 0)) {
        console.warn('Unallocated pax due to policy limits:', result.warnings);
    }
}

function setInputSafe(selector, val) {
    const el = document.querySelector(selector);
    if (el) el.value = (val === undefined || val === null) ? '' : val;
}

function applyTariffRatesToModal(tariffRes) {

    if (!tariffRes || !tariffRes.status) return;

    const d = tariffRes.data || {};
    const rates = d.rates || {};

    // ✅ Rooms | Units RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_room_member_rate"]', rates.room_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_rate"]', rates.room_rate || 0);

    // ✅ Extra Bed Adult RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_extra_bed_adult_rate"]', rates.adult_eb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_extra_bed_adult_rate"]', rates.adult_eb_rate || 0);

    // ✅ Extra Bed Child RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_extra_bed_child_rate"]', rates.child_eb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_extra_bed_child_rate"]', rates.child_eb_rate || 0);

    // ✅ Child Sharing Bed RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_child_sharing_bed_rate"]', rates.child_sb_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_child_sharing_bed_rate"]', rates.child_sb_rate || 0);

    // ✅ Single Occupancy RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_single_occupancy_rate"]', rates.sgl_rate || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_single_occupancy_rate"]', rates.sgl_rate || 0);

    // ✅ Supplement Cost COUNT = NA (Auto + Manual)
    const supCountAuto = document.querySelector('#roompricingandguestallocationModal [name="auto_supplment_cost_count"]');
    const supCountMan  = document.querySelector('#roompricingandguestallocationModal [name="manual_supplment_cost_count"]');
    if (supCountAuto) { supCountAuto.value = 'NA'; supCountAuto.setAttribute('readonly','readonly'); }
    if (supCountMan)  { supCountMan.value  = 'NA'; supCountMan.setAttribute('readonly','readonly'); }

    // ✅ Supplement Cost RATE (Auto + Manual)
    setInputSafe('#roompricingandguestallocationModal [name="auto_supplment_cost"]', d.supplement_amount || 0);
    setInputSafe('#roompricingandguestallocationModal [name="manual_supplment_cost"]', d.supplement_amount || 0);
}

function calcTotalFromAuto() {

    const num = (sel) => parseFloat(document.querySelector(sel)?.value || 0) || 0;

    const roomsCount = num('#roompricingandguestallocationModal [name="auto_room_member_count"]');
    const roomsRate  = num('#roompricingandguestallocationModal [name="auto_room_member_rate"]');

    const ebAcount = num('#roompricingandguestallocationModal [name="auto_extra_bed_adult_count"]');
    const ebArate  = num('#roompricingandguestallocationModal [name="auto_extra_bed_adult_rate"]');

    const ebCcount = num('#roompricingandguestallocationModal [name="auto_extra_bed_child_count"]');
    const ebCrate  = num('#roompricingandguestallocationModal [name="auto_extra_bed_child_rate"]');

    const sbCount = num('#roompricingandguestallocationModal [name="auto_child_sharing_bed_count"]');
    const sbRate  = num('#roompricingandguestallocationModal [name="auto_child_sharing_bed_rate"]');

    const sglCount = num('#roompricingandguestallocationModal [name="auto_single_occupancy_count"]');
    const sglRate  = num('#roompricingandguestallocationModal [name="auto_single_occupancy_rate"]');

    const supplement = num('#roompricingandguestallocationModal [name="auto_supplment_cost"]');

    const total =
        (roomsCount * roomsRate) +
        (ebAcount * ebArate) +
        (ebCcount * ebCrate) +
        (sbCount * sbRate) +
        (sglCount * sglRate) +
        supplement;

    setTextSafe('#modalTotalRate', total.toFixed(2));
}

/* ================= RATE + AMOUNT CALC HELPERS ================= */

function toNumber(val) {
  if (val === null || val === undefined) return 0;
  val = ('' + val).replace(/,/g, '').trim();
  if (val === '' || val.toUpperCase() === 'NA') return 0;
  const n = parseFloat(val);
  return isNaN(n) ? 0 : n;
}

function money(val) {
  // you can format if you want. Keeping simple:
  const n = toNumber(val);
  return (Math.round(n * 100) / 100).toFixed(2);
}

function getPlanInput(plan, line, field) {
  return document.querySelector(
    `#roompricingandguestallocationModal [data-plan="${plan}"][data-line="${line}"][data-field="${field}"]`
  );
}

function setAmount(plan, line, amount) {
  const span = document.querySelector(
    `#roompricingandguestallocationModal [data-role="amount-${plan}-${line}"]`
  );
  if (span) span.textContent = money(amount);

  const hidden = document.querySelector(
    `#roompricingandguestallocationModal [data-save="${plan}"][data-line="${line}"][data-save-field="amount"]`
  );
  if (hidden) hidden.value = money(amount);
}

function calcLineAmount(plan, line) {
  const countEl = getPlanInput(plan, line, 'count');
  const rateEl  = getPlanInput(plan, line, 'rate');

  const rate = toNumber(rateEl ? rateEl.value : 0);

  // Supplement: amount = rate only (count is NA)
  if (line === 'supplement') {
    setAmount(plan, line, rate);
    return rate;
  }

  const count = toNumber(countEl ? countEl.value : 0);
  const amt = count * rate;
  setAmount(plan, line, amt);
  return amt;
}

function calcTotal(plan) {
  const lines = ['rooms', 'eb_adult', 'eb_child', 'sb_child', 'sgl', 'supplement'];
  let total = 0;

  lines.forEach(line => {
    total += calcLineAmount(plan, line);
  });

  // total html + hidden
  const totalSpan = document.querySelector(`#roompricingandguestallocationModal [data-role="total-${plan}"]`);
  if (totalSpan) totalSpan.textContent = money(total);

  const totalHidden = document.getElementById(`${plan}_total_rate`);
  if (totalHidden) totalHidden.value = money(total);

  return total;
}

/* Copy Auto -> Manual counts/rates so manual starts same as auto */
function syncAutoToManualCountsAndRates() {
  const lines = ['rooms', 'eb_adult', 'eb_child', 'sb_child', 'sgl', 'supplement'];

  lines.forEach(line => {
    const aCount = getPlanInput('auto', line, 'count');
    const aRate  = getPlanInput('auto', line, 'rate');
    const mCount = getPlanInput('manual', line, 'count');
    const mRate  = getPlanInput('manual', line, 'rate');

    // manual should start same values (only if inputs exist)
    if (mCount && aCount) mCount.value = aCount.value;
    if (mRate && aRate) mRate.value = aRate.value;
  });
}

/* Call this whenever modal opens or whenever auto allocation/rates loaded */
function refreshAllAmountsAndTotals() {
  // Auto
  calcTotal('auto');
  // Manual
  calcTotal('manual');
}

/* Manual live update when user edits count/rate */
document.addEventListener('input', function (e) {
  const el = e.target;
  if (!el.closest('#roompricingandguestallocationModal')) return;

  const plan = el.dataset.plan;
  const line = el.dataset.line;

  if (plan !== 'manual') return; // only manual updates by user input
  if (!line) return;

  // update only that line and total
  calcLineAmount('manual', line);
  calcTotal('manual');
});

const roomModalEl = document.getElementById('roompricingandguestallocationModal');

if (roomModalEl) {
  roomModalEl.addEventListener('shown.bs.modal', function () {
    // Wait 1 tick so DOM values are painted
    setTimeout(() => {
      refreshAllAmountsAndTotals();
    }, 0);
  });
}

document.getElementById('btnSave1')?.addEventListener('click', function () {

    const dayId   = document.getElementById('modal_packages_properties_days_id_fk')?.value || '';
    const roomRow = document.getElementById('modal_quotation_properties_rooms_id_fk')?.value || '';

    if (!dayId || !roomRow) {
        console.log({ dayId, roomRow });
        return alert('Missing Day ID or Room Row ID');
    }

    const fd = new FormData();
    fd.append('packages_properties_days_id_fk', dayId);
    fd.append('quotation_properties_rooms_id_fk', roomRow);

    const spanNum = (sel) => (document.querySelector(sel)?.textContent || '0').trim();
    const inputVal = (sel, def='0') => (document.querySelector(sel)?.value ?? def);

    // pax wise
    fd.append('pax_wise_bed_adult_db_count', spanNum('[data-role="adult-db"]'));
    fd.append('pax_wise_bed_adult_eb_count', spanNum('[data-role="adult-eb"]'));
    fd.append('pax_wise_bed_adult_sgl_count', spanNum('[data-role="adult-sb"]'));

    fd.append('pax_wise_bed_child_db_count', spanNum('[data-role="child-db"]'));
    fd.append('pax_wise_bed_child_eb_count', spanNum('[data-role="child-eb"]'));
    fd.append('pax_wise_bed_child_sb_count', spanNum('[data-role="child-sb"]'));

    fd.append('pax_wise_bed_baby_db_count', spanNum('[data-role="baby-db"]'));
    fd.append('pax_wise_bed_baby_eb_count', spanNum('[data-role="baby-eb"]'));
    fd.append('pax_wise_bed_baby_sb_count', spanNum('[data-role="baby-sb"]'));

    // Auto inputs
    fd.append('room_unit_auto_count', inputVal('[name="auto_room_member_count"]'));
    fd.append('room_unit_auto_rate', inputVal('[name="auto_room_member_rate"]'));
    fd.append('room_unit_auto_total_rate', (document.querySelector('[data-role="amount-auto-rooms"]')?.textContent || '0'));

    fd.append('extra_bed_adult_auto_count', inputVal('[name="auto_extra_bed_adult_count"]'));
    fd.append('extra_bed_adult_auto_rate', inputVal('[name="auto_extra_bed_adult_rate"]'));
    fd.append('extra_bed_adult_auto_total_rate', (document.querySelector('[data-role="amount-auto-eb_adult"]')?.textContent || '0'));

    fd.append('extra_bed_child_auto_count', inputVal('[name="auto_extra_bed_child_count"]'));
    fd.append('extra_bed_child_auto_rate', inputVal('[name="auto_extra_bed_child_rate"]'));
    fd.append('extra_bed_child_auto_total_rate', (document.querySelector('[data-role="amount-auto-eb_child"]')?.textContent || '0'));

    fd.append('child_sharing_bed_auto_count', inputVal('[name="auto_child_sharing_bed_count"]'));
    fd.append('child_sharing_bed_auto_rate', inputVal('[name="auto_child_sharing_bed_rate"]'));
    fd.append('child_sharing_bed_auto_total_rate', (document.querySelector('[data-role="amount-auto-sb_child"]')?.textContent || '0'));

    fd.append('single_occupancy_auto_count', inputVal('[name="auto_single_occupancy_count"]'));
    fd.append('single_occupancy_auto_rate', inputVal('[name="auto_single_occupancy_rate"]'));
    fd.append('single_occupancy_auto_total_rate', (document.querySelector('[data-role="amount-auto-sgl"]')?.textContent || '0'));

    fd.append('supplyment_auto_cost', inputVal('[name="auto_supplment_cost"]'));
    fd.append('supplyment_auto_total_cost', (document.querySelector('[data-role="amount-auto-supplement"]')?.textContent || '0'));

    // Manual inputs
    fd.append('room_unit_manual_count', inputVal('[name="manual_count"]'));
    fd.append('room_unit_manual_rate', inputVal('[name="manual_rate"]'));
    fd.append('room_unit_manual_total_rate', (document.querySelector('[data-role="amount-manual-rooms"]')?.textContent || '0'));

    fd.append('extra_bed_adult_manual_count', inputVal('[name="manual_extra_bed_adult_count"]'));
    fd.append('extra_bed_adult_manual_rate', inputVal('[name="manual_extra_bed_adult_rate"]'));
    fd.append('extra_bed_adult_manual_total_rate', (document.querySelector('[data-role="amount-manual-eb_adult"]')?.textContent || '0'));

    fd.append('extra_bed_child_manual_count', inputVal('[name="manual_extra_bed_child_count"]'));
    fd.append('extra_bed_child_manual_rate', inputVal('[name="manual_extra_bed_child_rate"]'));
    fd.append('extra_bed_child_manual_total_rate', (document.querySelector('[data-role="amount-manual-eb_child"]')?.textContent || '0'));

    fd.append('child_sharing_bed_manual_count', inputVal('[name="manual_child_sharing_bed_count"]'));
    fd.append('child_sharing_bed_manual_rate', inputVal('[name="manual_child_sharing_bed_rate"]'));
    fd.append('child_sharing_bed_manual_total_rate', (document.querySelector('[data-role="amount-manual-sb_child"]')?.textContent || '0'));

    fd.append('single_occupancy_manual_count', inputVal('[name="manual_single_occupancy_count"]'));
    fd.append('single_occupancy_manual_rate', inputVal('[name="manual_single_occupancy_rate"]'));
    fd.append('single_occupancy_manual_total_rate', (document.querySelector('[data-role="amount-manual-sgl"]')?.textContent || '0'));

    fd.append('supplyment_manual_cost', inputVal('[name="manual_supplment_cost"]'));
    fd.append('supplyment_manual_total_cost', (document.querySelector('[data-role="amount-manual-supplement"]')?.textContent || '0'));

    // totals
    fd.append('auto_total_rate', (document.querySelector('[data-role="total-auto"]')?.textContent || '0'));
    fd.append('manual_total_rate', (document.querySelector('[data-role="total-manual"]')?.textContent || '0'));

    fetch(`<?php echo base_url(); ?>index.php/Quotation/ajax_add_quotation_room_tariff_details`, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        if (!res.status) {
            alert(res.message || 'Save failed');
            return;
        }

        // ✅ Update Auto Calculated Rate in the row of the clicked edit button
        const autoTotal = parseFloat(res.auto_total_rate || 0).toFixed(2);


        // if (window.__lastRoomEditBtn) {
        //     const tr = window.__lastRoomEditBtn.closest('tr');
        //     const rateText  = tr?.querySelector('.autoCalcRateText');
        //     const rateInput = tr?.querySelector('.autoCalcRateInput');

        //     const autoTotal = parseFloat(res.auto_total_rate || 0).toFixed(2);

        //     if (rateText)  rateText.textContent = autoTotal;
        //     if (rateInput) rateInput.value = autoTotal;
        // }

//         if (window.__lastRoomEditBtn) {
//             const tr = window.__lastRoomEditBtn.closest('tr');
//             const rateText  = tr?.querySelector('.autoCalcRateText');
//             const rateInput = tr?.querySelector('.autoCalcRateInput');

//             // res should return both totals from backend
//             const manualTotal = parseFloat(res.manual_total_rate || 0) || 0;
//             const autoTotal   = parseFloat(res.auto_total_rate || 0) || 0;

//             // ✅ priority: manual > auto
//             const finalTotal = (manualTotal > 0 ? manualTotal : autoTotal).toFixed(2);

//             if (rateText)  rateText.textContent = finalTotal;
//             if (rateInput) rateInput.value = finalTotal;

//             // refreshQuoteSummaryTotals();

//             const optionBlock = window.__lastRoomEditBtn.closest('.optionBlock');
// if (optionBlock) {
//   recalcOptionTotals(optionBlock);
// }


//         }

        if (window.__lastRoomEditBtn) {
  const tr = window.__lastRoomEditBtn.closest('tr');
  const rateText  = tr?.querySelector('.autoCalcRateText');
  const rateInput = tr?.querySelector('.autoCalcRateInput');

  // ✅ IMPORTANT: use MANUAL total if you want manual to be final
  const manualTotal = num(document.querySelector('#manual_total_rate')?.value || 0);
  const finalTotal  = manualTotal > 0 ? manualTotal : num(document.querySelector('#auto_total_rate')?.value || 0);

  const val = finalTotal.toFixed(2);

  if (rateText)  rateText.textContent = val;
  if (rateInput) rateInput.value = val;

  // ✅ NOW recalc the totals for this option block
  const optionBlock = window.__lastRoomEditBtn.closest('.optionBlock');
  if (optionBlock) recalcOptionTotals(optionBlock);
}


        // close modal
        const modalEl = document.getElementById('roompricingandguestallocationModal');
        bootstrap.Modal.getInstance(modalEl)?.hide();
    })
    .catch(err => {
        console.error(err);
        alert('Server error');
    });

});



/* ================= READ VALUES ================= */

/**
 * If you have multiple optionBlocks, we calculate totals using the ACTIVE option.
 * ACTIVE = the optionBlock that user is working on (has selected package option)
 * If you want "highest room among ALL options", change getActiveOptionBlock().
 */
function getActiveOptionBlock() {
  // Best-effort: choose first visible optionBlock
  const blocks = Array.from(document.querySelectorAll('.optionBlock'));
  if (!blocks.length) return null;

  // If you mark active one with class, prefer that:
  const active = document.querySelector('.optionBlock.active');
  if (active) return active;

  // Otherwise take first:
  return blocks[0];
}

function getCabCost() {
  const optionBlock = getActiveOptionBlock();
  if (!optionBlock) return 0;

  const cabEl = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');
  return toNumber(cabEl ? cabEl.value : 0);
}

function getHighestRoomRate() {
  const optionBlock = getActiveOptionBlock();
  if (!optionBlock) return 0;

  let maxRate = 0;

  // Room rows have hidden input .autoCalcRateInput (your plan)
  optionBlock.querySelectorAll('.autoCalcRateInput').forEach(inp => {
    const v = toNumber(inp.value);
    if (v > maxRate) maxRate = v;
  });

  // If you don't have inputs in some rows, also try text
  optionBlock.querySelectorAll('.autoCalcRateText').forEach(span => {
    const v = toNumber(span.textContent);
    if (v > maxRate) maxRate = v;
  });

  return maxRate;
}

function getInclusionTotal() {
  let total = 0;
  document.querySelectorAll('[name="inclusion_amount[]"]').forEach(inp => {
    total += toNumber(inp.value);
  });
  return total;
}

function getSpecialReqTotal() {
  let total = 0;
  document.querySelectorAll('[name="special_requirements_cost[]"], .specialReqCost').forEach(inp => {
    total += toNumber(inp.value);
  });
  return total;
}

function getMarginAmount(totalCost) {
  const type = document.getElementById('marginType')?.value || 'amount';
  const value = toNumber(document.getElementById('marginValue')?.value);

  if (type === 'percent') {
    return (totalCost * value) / 100;
  }
  return value;
}

/* ================= MAIN CALC ================= */

function refreshQuoteSummaryTotals() {
  const cab = getCabCost();
  const highestRoom = getHighestRoomRate();
  const inclusionTotal = getInclusionTotal();
  const specialReqTotal = getSpecialReqTotal();

  const totalCost = cab + highestRoom + inclusionTotal + specialReqTotal;
  const marginAmount = getMarginAmount(totalCost);
  const totalQuote = totalCost + marginAmount;

  // UI text
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = money(val);
  };

  setText('cabCostText', cab);
  setText('highestRoomText', highestRoom);
  setText('inclusionTotalText', inclusionTotal);
  setText('specialReqTotalText', specialReqTotal);
  setText('marginAmountText', marginAmount);

  setText('totalCostText', totalCost);
  setText('totalQuoteText', totalQuote);

  // Hidden inputs for save
  const totalCostInp = document.getElementById('total_cost');
  const marginInp = document.getElementById('margin_amount');
  const totalQuoteInp = document.getElementById('total_quote_rate');

  if (totalCostInp) totalCostInp.value = money(totalCost);
  if (marginInp) marginInp.value = money(marginAmount);
  if (totalQuoteInp) totalQuoteInp.value = money(totalQuote);
}

/* ================= LIVE UPDATES ================= */

// Any typing in Cab / Inclusion / Special Req should recalc
document.addEventListener('input', function (e) {
  const t = e.target;

  if (
    t.matches('[name="quotation_options_cab_amount[]"]') ||
    t.matches('[name="inclusion_amount[]"]') ||
    t.matches('[name="special_requirements_cost[]"]') ||
    t.closest('.specialReqCost') ||
    t.id === 'marginValue'
  ) {
    refreshQuoteSummaryTotals();
  }
});

// Margin type change
document.addEventListener('change', function (e) {
  const t = e.target;
  if (t && t.id === 'marginType') refreshQuoteSummaryTotals();
});


/* ===== GLOBAL HELPERS ===== */
function num(v) {
  const n = parseFloat(v);
  return isNaN(n) ? 0 : n;
}

/* Highest room auto-calculated rate per day (sum of max per day) */
function calculateHighestRoomRatePerDay(optionBlock) {
  const dayMax = {}; // {dayId: maxRate}

  optionBlock.querySelectorAll('.autoCalcRateInput').forEach(input => {
    const tr = input.closest('tr');
    const dayId = tr?.getAttribute('data-day-id');
    if (!dayId) return;

    const rate = num(input.value);

    if (dayMax[dayId] === undefined || rate > dayMax[dayId]) {
      dayMax[dayId] = rate;
    }
  });

  return Object.values(dayMax).reduce((a, b) => a + b, 0);
}


function recalcOptionTotals(optionBlock) {
  if (!optionBlock) return;

  const cabInput = optionBlock.querySelector('[name="quotation_options_cab_amount[]"]');
  const cabAmount = num(cabInput?.value);

  const roomsTotal = calculateHighestRoomRatePerDay(optionBlock);
  const totalCost = cabAmount + roomsTotal;

  const costText  = optionBlock.querySelector('.optionTotalCostText');
  const costInput = optionBlock.querySelector('.optionTotalCostInput');
  if (costText)  costText.textContent = totalCost.toFixed(2);
  if (costInput) costInput.value = totalCost.toFixed(2);

  const marginTypeEl  = optionBlock.querySelector('.optionMarginType');
  const marginValueEl = optionBlock.querySelector('.optionMarginValue');

  const marginType  = marginTypeEl ? marginTypeEl.value : 'amount';
  const marginValue = num(marginValueEl?.value);

  let marginAmount = 0;
  if (marginType === 'percent') marginAmount = (totalCost * marginValue) / 100;
  else marginAmount = marginValue;

  const quoteTotal = totalCost + marginAmount;

  const quoteText  = optionBlock.querySelector('.optionQuoteTotalText');
  const quoteInput = optionBlock.querySelector('.optionQuoteTotalInput');
  if (quoteText)  quoteText.textContent = quoteTotal.toFixed(2);
  if (quoteInput) quoteInput.value = quoteTotal.toFixed(2);
}

/* ===== LIVE RECALC TRIGGERS ===== */
document.addEventListener('input', function (e) {
  // cab amount
  if (e.target.name === 'quotation_options_cab_amount[]') {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }

  // margin value
  if (e.target.classList.contains('optionMarginValue')) {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }
});

document.addEventListener('change', function (e) {
  // margin type
  if (e.target.classList.contains('optionMarginType')) {
    const optionBlock = e.target.closest('.optionBlock');
    recalcOptionTotals(optionBlock);
  }
});
</script>